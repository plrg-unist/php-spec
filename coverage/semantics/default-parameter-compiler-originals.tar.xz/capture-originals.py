from pathlib import Path
import sys,json,subprocess,shutil,hashlib
R=Path(__file__).resolve().parent; C=R.parent.parent
sys.path.insert(0,str(R/'tests/semantics'));import static_types as types
H=C/'.tools/compiler5-default-originals/.tools/send-kind-originals-hvami040';O=R/'.tools/default-originals899';O.mkdir()
modules=[str(R/p) for p in json.loads((R/'spec/semantics/modules.json').read_text())]
rows=[]
for old in sorted(H.iterdir()):
 if not (old/'source.php').exists():continue
 d=O/old.name;d.mkdir();shutil.copy2(old/'source.php',d/'source.php');shutil.copy2(old/'checked.json',d/'checked.json');shutil.copy2(old/'parsed.json',d/'parsed.json')
 text=(old/'compiler-state.watsup').read_text();(d/'compiler-state.watsup').write_text(text)
 for name,cmd in [('lint',[str(types.PHP),'-n',*types.FLAGS,'-l',str(d/'source.php')]),('compiler',[str(R/'tests/semantics/_build/default/numeric_runner.exe'),*modules,str(d/'compiler-state.watsup')])]:
  (d/(name+'.command.json')).write_text(json.dumps(cmd)+'\n')
  r=subprocess.run(cmd,capture_output=True,env=types.ENV,timeout=60)
  (d/(name+'.stdout')).write_bytes(r.stdout);(d/(name+'.stderr')).write_bytes(r.stderr);(d/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode})+'\n')
  assert r.returncode in ([0,255] if name=='lint' else [0]),(d,name,r.stderr)
 rows.append({'name':old.name,'source_sha256':hashlib.sha256((d/'source.php').read_bytes()).hexdigest()});print(old.name,flush=True)
(O/'manifest.json').write_text(json.dumps({'baseline':json.loads((R/'baseline-inputs.json').read_text())['fingerprint'],'cases':rows},indent=2)+'\n')
