from pathlib import Path
import hashlib,io,json,tarfile,stat
R=Path(__file__).resolve().parent;C=R.parent.parent
m=json.loads((R/'final-inputs.json').read_text());b=json.loads((R/'baseline-inputs.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(digest(R/p)==h and stat.S_IMODE((R/p).stat().st_mode)==m['modes'][p] for p,h in m['files'].items())
files={p:R/p for p in m['files']}
for p,h in b['files'].items():
 if m['files'].get(p)!=h:
  assert digest(C/p)==h;files['baseline899/'+p]=C/p
for p in ['archive-compiler.py','capture-corrected-originals.py','first-archive-report.json','original-profile-correction.json','capture-originals.py','check-default-compiler.py','prepare-compiler.py','freeze-compiler.py','focused-regression.py','baseline-inputs.json','final-inputs.json','compiler-delta.json','semantics-reference-inputs.json','fingerprint-label-correction.json','signature-step-bridge.json','docs/semantics/DEFAULT-PARAMETER-COMPILER.md']:
 files[p]=R/p
for p in (R/'coverage/semantics').glob('*.json'):
 if p.name in ['default-parameter-compiler.json','function-compiler.json','constant-context.json','user-constant-compiler.json','magic-constants-compiler.json']:files[str(p.relative_to(R))]=p
for p in (R/'.tools').rglob('*'):
 if p.is_file() and '__pycache__' not in p.parts:files[str(p.relative_to(R))]=p
for p,h in json.loads((R/'semantics-reference-inputs.json').read_text())['references'].items():assert digest(R/p)==h;files[p]=R/p
tools={p:digest(f) for p,f in files.items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p in tools:files.pop(p)
hashes={p:digest(f) for p,f in files.items()};out=R/'coverage/semantics/default-parameter-compiler-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'tools':tools,'candidate':m,'baseline':b},indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
 for p,f in sorted(files.items()):
  h=hashes[p];info=t.gettarinfo(str(f),arcname=p)
  if h in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;t.addfile(info)
  else:
   seen[h]=p
   with f.open('rb') as stream:t.addfile(info,stream)
with tarfile.open(out,'r:xz') as t:
 for p,h in hashes.items():assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==h,p
report={'scope':'Frozen compiler90 source/default adapter, pending atomic runtime91 acceptance; no default runtime/cache admission or full callable/core closure.','archive':str(out.relative_to(R)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'tools':tools,'candidate':m['fingerprint'],'baseline':b['fingerprint'],'map_label_bridge':'fingerprint-label-correction.json records exact902 hashes/modes unchanged when correcting the digest algorithm; historical raw labels retained.','originals':{'current899_compiler39':'.tools/default-originals899-corrected','nonpaired_first39':'.tools/default-originals899 (compiler/native filenames differed; never exact paired originals; see original-profile-correction.json)','first_archive':'first-archive-report.json and .tools/first-archive-8276a966.tar.xz retain immutable initial8276 artifact','current899_additional8':'.tools/additional-originals899','historical_skipped12':'Retained by accepted3452d7d4; source identities replayed in57 current compiler cases.','historical_signature17':'signature-step-bridge.json: exact tested helper prototype bytes, no duplicate357-helper campaign.'},'gates':{'defaults':{'raw':'.tools/default_parameter_compiler-regression-ce1alp7c','phases':54,'pending':3,'descriptors':51},'named':{'raw':'.tools/function_compiler-regression-cpp5zab9','phases':41,'pending':5,'descriptors':37},'sharedconstant':{'raw':'.tools/constant_context-regression-nhm9ndkl','observations':42,'boundaries':5},'userconstant':{'raw':'.tools/user_constant_compiler-regression-49hj7l3n','phases':45,'pending':10},'magic':{'raw':'.tools/magic_constants_compiler-regression-mjnfp0je','sources':48}},'failures':['.tools/first-load','.tools/second-load','.tools/default-compiler-ddy5kt17','.tools/direct-constant-context-build-failure'],'transport':'Native/SpecTec subprocess byte streams, statuses, commands and decoded worker requests/responses retained; focused wrappers also assert worker closure. These are decoded JSON records, not exact wire frames or separately captured worker stderr. Independent protocol review owns those gates.','build':'No compiler/runtime runner rebuild performed; copied binary hashes verified by focused wrapper. Private direct Opam build attempt failed before testing and remains a tool failure.'}
(R/'coverage/semantics/default-parameter-compiler-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['sha256','bytes','paths','candidate']},indent=2));assert all(digest(R/p)==h for p,h in m['files'].items())
