from pathlib import Path
import sys,json,subprocess,tempfile
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import static_types as types,source_context as context,source_compiler as compiler
O=Path(tempfile.mkdtemp(prefix='default-compiler-',dir=R/'.tools'));print(O,flush=True)
mods=[str(R/p) for p in json.loads((R/'spec/semantics/modules.json').read_text())];cases=[]
pending={'callable':'first-class callable constant initializer','closure':'closure constant initializer','object':'object constant initializer'}
for d in sorted((R/'.tools/default-originals899').iterdir()):
 if not d.is_dir():continue
 checked=json.loads((d/'checked.json').read_text());native=subprocess.CompletedProcess([],json.loads((d/'lint.status.json').read_text())['exit_status'],(d/'lint.stdout').read_bytes(),(d/'lint.stderr').read_bytes());events=context.events(native)
 body=f'  -- if P = $ppstart(91, {checked["fixture"]}, {types.byte_expr(str(d/"source.php"))})\n'
 if d.name in pending:body+='  -- if P.COMPLETION = PPCABRUPT (UNSUPPORTED '+json.dumps(pending[d.name])+')\n'
 else:
  body+='  -- if $pptrace(P) = '+context.expected_events(events,d/'source.php')+'\n'
  if native.returncode==0:body+='  -- if P.COMPLETION = PPCNORMAL\n'
 n=len(cases);cases.append(f'dec $case{n}() : bool\ndef $case{n}() = true\n'+body)
 f=O/(d.name+'.watsup');f.write_text(compiler.PREFIX+f'dec $main() : ppstate\ndef $main() = $ppstart(91, {checked["fixture"]}, {types.byte_expr(str(d/"source.php"))})\n')
f=O/'aggregate.watsup';f.write_text(compiler.PREFIX+'\n'.join(cases)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(cases))))
cmd=[str(R/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(f)];(O/'command.json').write_text(json.dumps(cmd));r=subprocess.run(cmd,capture_output=True,env=types.ENV,timeout=120);(O/'stdout').write_bytes(r.stdout);(O/'stderr').write_bytes(r.stderr);(O/'status.json').write_text(json.dumps({'exit_status':r.returncode}));print(r.returncode,r.stdout.decode(),r.stderr.decode());assert r.returncode==0 and r.stdout==b'true\n'
