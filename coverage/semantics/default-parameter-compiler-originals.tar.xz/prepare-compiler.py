from pathlib import Path
import shutil,json
R=Path(__file__).resolve().parent;C=R.parent.parent;S=R/'spec/semantics'
shutil.copy2(C/'.tools/compiler5-default-parameters/spec/semantics/17-signatures.watsup',S/'17-signatures.watsup')
def edit(name,f):
 p=S/name;p.write_text(f(p.read_text()))
edit('45-constant-context.watsup',lambda s:s.replace('syntax pfstate = { CLASSFACTS','syntax pfstate = { DEFAULT bool, CLASSFACTS').replace('= { CLASSFACTS eps, CONSTANT','= { DEFAULT false, CLASSFACTS eps, CONSTANT').replace('dec $pfnamed(pfstate','dec $pffoldname(pfstate, pnreference) : pvalue?\ndec $pfnamed(pfstate').replace('$pfremember(F, pcpath, $pnfold(pnreference), z)','$pfremember(F, pcpath, $pffoldname(F, pnreference), z)').replace('def $pfnamed(F, pcpath, PNUNSUPPORTED text, z)', 'def $pffoldname(F, pnreference) = $pnfold(pnreference)\n  -- if ~F.DEFAULT\ndef $pffoldname(F, pnreference) = $special_constant($pnfoldname(pnreference))\n  -- if F.DEFAULT\ndef $pfnamed(F, pcpath, PNUNSUPPORTED text, z)'))
edit('46-source-compiler.watsup',lambda s:s.replace('$pnfold(pnreference)','$pffoldname(P.FOLD, pnreference)'))
edit('30-storage.watsup',lambda s:s.replace('syntax pfunction = {','syntax pdefaultkind = PDSTORED | PDDEFERRED\nsyntax pdefault = { INDEX nat, ORIGIN porigin, KIND pdefaultkind }\nsyntax pfunction = { DEFAULTS pdefault*, '))
edit('78-function-compiler.watsup',lambda s:s.replace('{ ORIGIN PORIGIN P.FOLD.SOURCE.ID pcpath, NAME ptbytes, SIGNATURE pssignature,','{ DEFAULTS $ppfunction_defaults(P_body, pcpath, pssignature.PARAMETERS, 0), ORIGIN PORIGIN P.FOLD.SOURCE.ID pcpath, NAME ptbytes, SIGNATURE pssignature,').replace(' /\\ psparam.DEFAULT = PSNONE /\\ $ppplain_params',' /\\ $ppplain_params').replace('$ppfunction_signature(P_name, pcpath, $ptjoin(P.ENV.NAMESPACE, $base64(text)), statement*, metadata, $pscompile(phpType16, phpType18, b, $ppfunction_context(P_name, $ptjoin(P.ENV.NAMESPACE, $base64(text)))))','$ppdefaults_begin(P_name, pcpath, $ptjoin(P.ENV.NAMESPACE, $base64(text)), statement*, metadata, phpType16, phpType18, b)').replace('$effect_below(pfunction.BODY, pcpath) \\/ $ppinner(pfunction_tail*, pcpath)','$ppfunction_contains(pfunction, pcpath) \\/ $ppinner(pfunction_tail*, pcpath)'))
old=(C/'.tools/compiler5-default-compiler/spec/semantics/88-parameter-defaults.watsup').read_text()
# Reuse the accepted user-constant validator rather than the abandoned duplicate.
a=old.index('def $ppdefault_validate');b=old.index('def $ppdefault_kind')
old=old[:a]+old[b:]
old='\n'.join(line for line in old.split('\n') if not any(line.startswith('dec $'+x) for x in ['ppdefault_validate','ppdefault_node','ppdefault_children','ppdefault_allowed','ppdefault_shape']))
old=old.replace('$ppdefault_validate(', '$ppconstant_validate(')
old=old.replace('[.FOLD = P.FOLD[.DEFAULT = true]]','[.FOLD = P.FOLD[.DEFAULT = true][.CONSTANT = true]]')
old=old.replace('[.DEFAULT = false][.VALUE = eps]','[.DEFAULT = false][.CONSTANT = false][.VALUE = eps]')
old=old.replace('PCINDEX |pscontinuation.SIGNATURE.PARAMETERS|','PCINDEX n_index').replace('  -- if pcpath_default = pcpath ++ [PCFIELD 3, PCINDEX n_index, PCFIELD 6]','  -- if n_index = |pscontinuation.SIGNATURE.PARAMETERS|\n  -- if pcpath_default = $ppdefault_path(pcpath, n_index)')
old=old.replace('(DEFAULT n (PORIGIN P.FOLD.SOURCE.ID pcpath_default) $ppdefault_descriptor(P, pcpath_default))','{ INDEX n, ORIGIN PORIGIN P.FOLD.SOURCE.ID pcpath_default, KIND $ppdefault_descriptor(P, pcpath_default) }').replace('= STORED','= PDSTORED').replace('= DEFERRED','= PDDEFERRED')
old+='''
;; A function owns compiled parameter roots even when normalization removes an
;; optional receive. Nested functions must not leak those roots into their parent.
dec $ppdefault_path(pcpath, nat) : pcpath
def $ppdefault_path(pcpath, n) = pcpath ++ [PCFIELD 3, PCINDEX n, PCFIELD 6]
dec $ppfunction_contains(pfunction, pcpath) : bool
def $ppfunction_contains(pfunction, pcpath) = ($effect_below(pfunction.BODY, pcpath) \\/ $effect_below(pcpath_decl ++ [PCFIELD 3], pcpath))
  -- if pfunction.ORIGIN = PORIGIN n pcpath_decl
'''
(S/'90-parameter-defaults.watsup').write_text(old)
p=S/'modules.json';v=json.loads(p.read_text());v.append('spec/semantics/90-parameter-defaults.watsup');p.write_text(json.dumps(v,indent=2)+'\n')
