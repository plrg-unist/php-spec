from pathlib import Path
import json,hashlib,stat,sys
R=Path(__file__).resolve().parent;j=json.loads((R/'baseline-inputs.json').read_text());names=set(j['files'])|{'spec/semantics/90-parameter-defaults.watsup','tests/semantics/default_parameter_compiler.py','tests/semantics/default_parameter_cases.json'}
files={p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in sorted(names)};modes={p:stat.S_IMODE((R/p).stat().st_mode) for p in sorted(names)}
sys.path.insert(0,str(R/'tests'));import validate
fingerprint=validate.implementation_fingerprint();assert fingerprint['files']==len(files)
report={'fingerprint':fingerprint,'files':files,'modes':modes,'baseline':j['fingerprint'],'scope':'Frozen compiler90 candidate;30 only agreed descriptor declaration,32/84/runtime91 guard pending atomic pair.'};(R/'final-inputs.json').write_text(json.dumps(report,indent=2)+'\n')
delta={p:{'before':j['files'].get(p),'after':files[p]} for p in files if j['files'].get(p)!=files[p]};(R/'compiler-delta.json').write_text(json.dumps(delta,indent=2)+'\n');print(fingerprint,len(delta))
