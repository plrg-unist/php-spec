from pathlib import Path
import sys,json,subprocess,shutil,hashlib,stat
R=Path(__file__).resolve().parent;C=R.parent.parent
sys.path.insert(0,str(C/'tests/semantics'));import static_types as types
m=json.loads((R/'baseline-inputs.json').read_text())
def same():return all(hashlib.sha256((C/p).read_bytes()).hexdigest()==h and stat.S_IMODE((C/p).stat().st_mode)==m['modes'][p] for p,h in m['files'].items())
assert same();H=R/'.tools/default-originals899';O=R/'.tools/default-originals899-corrected';O.mkdir()
modules=[str(C/p) for p in json.loads((C/'spec/semantics/modules.json').read_text())];rows=[]
for old in sorted(H.iterdir()):
 if not (old/'source.php').exists():continue
 d=O/old.name;d.mkdir()
 for name in ['source.php','checked.json','parsed.json']:shutil.copy2(old/name,d/name)
 checked=json.loads((d/'checked.json').read_text());w=d/'compiler-state.watsup';w.write_text(f'dec $main() : ppstate\ndef $main() = $ppstart(91, {checked["fixture"]}, {types.byte_expr(str(d/"source.php"))})\n')
 for name,cmd in [('lint',[str(types.PHP),'-n',*types.FLAGS,'-l',str(d/'source.php')]),('compiler',[str(C/'tests/semantics/_build/default/numeric_runner.exe'),*modules,str(w)])]:
  (d/(name+'.command.json')).write_text(json.dumps(cmd)+'\n');r=subprocess.run(cmd,capture_output=True,env=types.ENV,timeout=60);(d/(name+'.stdout')).write_bytes(r.stdout);(d/(name+'.stderr')).write_bytes(r.stderr);(d/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode})+'\n');assert r.returncode in ([0,255] if name=='lint' else [0]),(d,name,r.stderr)
 rows.append({'name':old.name,'source_sha256':hashlib.sha256((d/'source.php').read_bytes()).hexdigest(),'source_file':str(d/'source.php')})
assert same();(O/'manifest.json').write_text(json.dumps({'baseline':m['fingerprint'],'cases':rows,'same_native_and_compiler_file':True},indent=2)+'\n')
(R/'original-profile-correction.json').write_text(json.dumps({'first_archive_sha256':'8276a966b36571dc8356e74d0e4c086b6d0c2129afd95d7400868e778a966189','first_archive':'first-archive-report.json','nonpaired_attempt':'.tools/default-originals899','reason':'Compiler fixture retained historical filename; fresh native lint used copied filename. Source bytes same but request profiles differ; not an exact paired original.','corrected_paired_originals':'.tools/default-originals899-corrected','cases':39,'baseline':m['fingerprint'],'passing57_gate':'Already generated matching filenames; unaffected.'},indent=2)+'\n');print('39 corrected same-file baseline899 originals; input closure unchanged')
