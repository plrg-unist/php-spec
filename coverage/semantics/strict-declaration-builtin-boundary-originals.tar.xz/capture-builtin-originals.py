from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-parameter-defaults';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
cases={
 'strict-strlen-int':b'<?php declare(strict_types=1);echo strlen(1);',
 'strict-strlen-null':b'<?php declare(strict_types=1);echo strlen(null);',
 'strict-strlen-string':b'<?php declare(strict_types=1);echo strlen("12");',
 'strict-inarray-constant-int':b'<?php declare(strict_types=1);echo in_array(1,[1],1);',
 'strict-inarray-variable-int':b'<?php declare(strict_types=1);$x=1;echo in_array(1,[1],$x);',
 'weak-strlen-int':b'<?php echo strlen(1);',
 'weak-inarray-variable-int':b'<?php $x=1;echo in_array(1,[1],$x);'
}
(R/'builtin-cases.json').write_text(json.dumps({n:s.decode() for n,s in cases.items()},indent=2)+'\n')
scope.main(cases,'strict-builtin-originals',Path(scope.__file__))
