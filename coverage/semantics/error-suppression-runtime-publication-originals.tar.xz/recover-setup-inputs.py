from pathlib import Path
import json,hashlib,shutil,stat
R=Path(__file__).resolve().parent;B=R.parent/'runtime7-suppression-integration';base=json.loads((B/'inputs.json').read_text());records=[]
for suffix in ['nz3yhg2q','zxips930','6zwzyc2j']:
 raw=R/'.tools'/('suppression-reporting-'+suffix);old=json.loads((raw/'inputs.json').read_text());D=R.parent/('runtime7-suppression-reporting-'+suffix);D.mkdir(exist_ok=True);names=set(base['files'])-{'tests/semantics/error_suppression_protocol.py'}
 for n in sorted(names):
  src=B/n
  if n=='tests/semantics/suppression_reporting.py':src=raw/'original-inputs'/n
  p=D/n;p.parent.mkdir(parents=True,exist_ok=True)
  if not p.exists():shutil.copy2(src,p)
  if n=='Makefile':p.write_text(p.read_text().replace('tests/semantics/error_suppression_protocol.py','tests/semantics/suppression_protocol.py'))
 files={n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in sorted(names)};digest=hashlib.sha256()
 for path in sorted(map(Path,files)):
  n=str(path);digest.update(n.encode()+b'\0');digest.update(bytes.fromhex(files[n]))
 assert digest.hexdigest()==old['fingerprint']['sha256'],(suffix,digest.hexdigest(),old['fingerprint'])
 modes={n:stat.S_IMODE((D/n).stat().st_mode) for n in names};j={'fingerprint':old['fingerprint'],'files':files,'modes':modes,'derivation':'Recovered from integration951 by removing the not-yet-copied protocol, restoring its prior Makefile target, and using exact raw-copied failed reporting producer. Recomputed full950 fingerprint equals the original recorded fingerprint; no semantic result relabelled.'};(D/'inputs.json').write_text(json.dumps(j,indent=2)+'\n');records.append({'snapshot':str(D),'fingerprint':j['fingerprint'],'original':str(raw)});print(suffix,'exact950 match')
(R/'reporting-setup-snapshots.json').write_text(json.dumps(records,indent=2)+'\n')
