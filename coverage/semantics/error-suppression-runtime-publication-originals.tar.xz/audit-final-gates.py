from pathlib import Path
import base64,hashlib,json,stat,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import function_scope as fs
final=json.loads((R/'final-inputs.json').read_text());assert fs.q.t.syntax_validation.implementation_fingerprint()==final['fingerprint'];audit=[]
selection=[(R.parent/'runtime7-suppression-integration',n) for n in ['suppression','suppression-reporting','error-suppression-protocol','suppression-state','suppression-compiler','reference-returns']]+[(R.parent/'runtime7-suppression-final','reference-return-demand')]
for B,name in selection:
 manifest=json.loads((B/'inputs.json').read_text());assert all(hashlib.sha256((B/n).read_bytes()).hexdigest()==h and stat.S_IMODE((B/n).stat().st_mode)==manifest['modes'][n] for n,h in manifest['files'].items());changed=[n for n,h in manifest['files'].items() if final['files'][n]!=h];assert changed in [[],['tests/semantics/reference_return_demand.py']];j=json.loads((B/'coverage/semantics'/f'{name}.json').read_text());assert j['result']=='pass';assert j.get('fingerprint',manifest['fingerprint'])==manifest['fingerprint'];d=Path(j['raw']);d=d if d.is_absolute() else B/d
 for n,h in j.get('inputs',j.get('direct_inputs',{})).items():assert hashlib.sha256((B/n).read_bytes()).hexdigest()==h,(name,n)
 source_rows=[row for row in j.get('records',[]) if 'native' in row and 'request' in row]
 source_rows += [json.loads(p.read_text()) for p in d.rglob('original.json')]
 for row in source_rows:
  request=row['request'];p=Path(row.get('context',base64.b64decode(request['file']).decode()));assert p.read_bytes()==base64.b64decode(row['source_base64']);native=row['native'];assert (p.parent/'native.stdout').read_bytes()==base64.b64decode(native['stdout']);assert (p.parent/'native.stderr').read_bytes()==base64.b64decode(native['stderr']);assert json.loads((p.parent/'native.status.json').read_text())=={'status':'exit','exit_status':native['exit_status']};entries=[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in request['env']];assert (p.parent/'request.input').read_bytes()==fs.q.packet(int(request['seconds']),request['microseconds'],entries)
 workers=[];runners=[]
 for p in sorted(d.rglob('close.json')):
  w=p.parent;s=json.loads(p.read_text());assert s=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (w/'stderr').read_bytes() and not (w/'trailing.stdout').read_bytes();req=sorted(w.glob('*.request'),key=lambda p:int(p.stem));res=sorted(w.glob('*.response'),key=lambda p:int(p.stem));assert [p.stem for p in req]==[str(i) for i in range(len(req))];assert [p.stem for p in res]==[p.stem for p in req]
  for p in res:assert p.read_bytes().endswith(b'\n') and fs.q.t.wire.loads(p.read_text())['ok']
  workers.append({'path':str(w),'responses':len(res),'closure':s})
 for p in sorted(d.rglob('*.command.json')):
  cmd=json.loads(p.read_text())
  if Path(cmd[0]).name!='numeric_runner.exe':continue
  prefix=p.name.removesuffix('.command.json');s=json.loads(p.with_name(prefix+'.status.json').read_text());assert s['status']=='exit' and s['exit_status']==0;assert p.with_name(prefix+'.stdout').read_bytes()==b'true\n' and not p.with_name(prefix+'.stderr').read_bytes();runners.append(str(p))
 audit.append({'gate':name,'identity':manifest['fingerprint'],'report':str(B/'coverage/semantics'/f'{name}.json'),'raw':str(d),'native_profiles':len(source_rows),'workers':workers,'runners':runners})
result={'result':'pass','fingerprint':final['fingerprint'],'gates':audit,'native_profiles':sum(x['native_profiles'] for x in audit),'worker_closures':sum(len(x['workers']) for x in audit),'responses':sum(w['responses'] for x in audit for w in x['workers']),'standalone_runner_closures':sum(len(x['runners']) for x in audit)};(R/'final-gate-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='gates'})
