from pathlib import Path
import hashlib,json,stat,tarfile,io
R=Path(__file__).resolve().parent;P=R.parent.parent;D=R/'publication/coverage/semantics';D.mkdir(parents=True,exist_ok=True);files={}
def add(path,name):
 assert path.is_file(),path
 assert name not in files or files[name]==path,(name,path)
 files[name]=path
snapshots=[('baseline942',P/'.tools/runtime7-return-statefix3',P/'.tools/runtime7-return-statefix3/inputs.json'),('first944',P/'.tools/runtime7-suppression-first',P/'.tools/runtime7-suppression-first/inputs.json'),('guarded944',P/'.tools/runtime7-suppression-guarded',P/'.tools/runtime7-suppression-guarded/inputs.json'),('integration951',P/'.tools/runtime7-suppression-integration',P/'.tools/runtime7-suppression-integration/inputs.json'),('final951',R,R/'final-inputs.json')]
for row in json.loads((R/'reporting-setup-snapshots.json').read_text()):
 root=Path(row['snapshot']);snapshots.append((root.name,root,root/'inputs.json'))
for label,root,mp in snapshots:
 j=json.loads(mp.read_text());assert len(j['files'])==j['fingerprint']['files'];add(mp,'snapshots/'+label+'/INPUTS.json')
 for n,h in j['files'].items():
  p=root/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h,(label,n);assert stat.S_IMODE(p.stat().st_mode)==j['modes'][n],(label,n);add(p,'snapshots/'+label+'/'+n)
roots=[]
for root in [R,P/'.tools/runtime7-suppression-integration',P/'.tools/runtime7-suppression-final']:
 roots += [d for d in (root/'.tools').iterdir() if d.is_dir()]
 roots += [root/'final-gates'] if (root/'final-gates').exists() else []
 for p in root.iterdir():
  if p.is_file() and p.suffix in ('.py','.json','.md','.watsup','.stdout','.stderr'):add(p,'preparation/'+str(p.relative_to(P)))
 for p in (root/'coverage/semantics').glob('*.json'):add(p,'reports/'+str(p.relative_to(P)))
for root in roots:
 for p in root.rglob('*'):
  if p.is_file():add(p,'raw/'+str(p.relative_to(P)))
for n in ['Zend/zend_compile.c','Zend/zend_vm_def.h','Zend/zend_execute.c','Zend/zend_errors.h','Zend/zend_globals.h','Zend/zend_builtin_functions.c','main/main.c']:add(P/'vendor/php-src'/n,'pinned-source/'+n)
manifest={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for n,p in sorted(files.items())};meta={'scope':'Complete exact942 baseline, early944 and guarded944, integration951/final951, and three failed primitive reporter950 preparations recovered to their exact original recorded fingerprints. Author original/full-request/source/demand/phase/state/regression history and raw setup failures are retained. Compiler and reviewer archives separately preserve their original observations and mutations. Setup failures and Unsupported never count as agreement.','files':manifest};payload=(json.dumps(meta,indent=2)+'\n').encode();target=D/'error-suppression-runtime-originals.tar.xz';assert not target.exists()
seen={}
with tarfile.open(target,'w:xz',preset=6) as t:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(payload);info.mode=0o644;t.addfile(info,io.BytesIO(payload))
 for name,p in sorted(files.items()):
  entry=manifest[name];info=tarfile.TarInfo(name);info.mode=entry['mode'];key=(entry['sha256'],entry['mode'])
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];t.addfile(info)
  else:
   raw=p.read_bytes();info.size=len(raw);t.addfile(info,io.BytesIO(raw));seen[key]=name
a={'archive':'coverage/semantics/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'payload_files':len(files),'members':len(files)+1,'manifest_sha256':hashlib.sha256(payload).hexdigest(),'snapshots':{label:json.loads(mp.read_text())['fingerprint'] for label,root,mp in snapshots},'scope':meta['scope'],'compiler_archive':'coverage/semantics/suppression-compiler-originals.tar.xz'};(D/'error-suppression-runtime-originals.json').write_text(json.dumps(a,indent=2)+'\n');print(a,flush=True)
