from pathlib import Path
import tarfile,json,hashlib
R=Path(__file__).resolve().parent;D=R/'publication/coverage/semantics';j=json.loads((D/'error-suppression-runtime-originals.json').read_text());p=D/Path(j['archive']).name;assert hashlib.sha256(p.read_bytes()).hexdigest()==j['sha256'];seen={};regular=links=0
with tarfile.open(p,'r:xz') as t:
 for member in t:
  if member.name=='MANIFEST.json':
   raw=t.extractfile(member).read();assert hashlib.sha256(raw).hexdigest()==j['manifest_sha256'];manifest=json.loads(raw)['files'];continue
  assert member.name not in seen and member.name in manifest;want=manifest[member.name];assert member.mode==want['mode'];assert not member.name.startswith('/') and '..' not in Path(member.name).parts
  if member.islnk():
   assert member.linkname in seen;got=seen[member.linkname];links+=1
  else:
   assert member.isfile();raw=t.extractfile(member).read();got=(hashlib.sha256(raw).hexdigest(),len(raw),member.mode);regular+=1
  assert got==(want['sha256'],want['bytes'],want['mode']),member.name;seen[member.name]=got
assert len(seen)==len(manifest)==j['payload_files'];out={'result':'pass','sha256':j['sha256'],'payload_files':len(seen),'regular_files':regular,'hardlinks':links,'scope':'Every regular payload hashed; each earlier-target content+mode hardlink verified against its manifest entry, with exact member set and no escaping paths.'};(R/'author-archive-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
