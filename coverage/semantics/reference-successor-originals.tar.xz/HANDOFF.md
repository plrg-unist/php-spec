# Runtime successor: positional reference parameters

Private preparation only. Finish and accept firstcalls before publishing this
stage. Build the successor from the then-accepted candidate, preserving its latest
runtime/integrity fixes and standalone builtin prerequisites. Do not copy the
older runtime modules or binaries from this compiler snapshot over them.

## Frozen inputs and delta

Candidate: `.tools/compiler5-reference-parameters`. Its `final-inputs.json` binds
869 files; SHA256 `d71ccb944c6189b7895dc0f0260b00336de13155f81a320ad702621ded9889fe`.
Baseline866 is `02f6029fc4f1b80f13d39c9b000949bd15eee6144770202f5891262ac34871b7`.
`reference-delta.json` has exact before/after hashes and `reference-delta.patch`
contains these five paths:

- `spec/semantics/46-source-compiler.watsup`
- `spec/semantics/78-function-compiler.watsup`
- `tests/semantics/function_reference_compiler.py`
- `tests/semantics/function_reference_cases.json`
- `docs/semantics/REFERENCE-PARAMETER-PREPARATION.md`

Author archive: candidate-relative
`coverage/semantics/reference-parameter-preparation-originals.tar.xz`, SHA256
`3cc3c691795ab36a51b6577d753c27943aca15075aa7b88dc1af4d2d8a53a6cc`:
2,521 exact payloads, 1,052,104 bytes. Its JSON report binds five actual tools;
binary payloads are not embedded. Exact old46/78 are retained for reconstruction.
Author gate passes48 compiler phases and16 descriptor/header assertions. Review8
accepted the interface and independently audited every archive payload/tool hash,
ordered48 phase rows and aggregate raw result; no independent execution replay or
runtime-reference agreement is claimed. See `.tools/review8-reference-preparation-audit.json`.

## Consumer contract

Scope is untyped positional reference parameters with value returns. Module17's
`psparam.BYREF` stays authoritative. Compiler78 selects `PPW` per parameter only
for variable actuals of finalized earlier declarations; surplus positions are
by value. Forward/self/namespace-fallback fetches retain `PPF`/`CODEARG`, except
the existing ordinary-CV `PPR` fast path. Literal/expression actuals, whole GLOBALS
and direct call results stay `PPR`. Module46 compiles a call used as a writable
dimension base in `PPR`, while its dimension remains `PPW`.

`CODEARG` means deferred compiler fetch, not reference passing. Current80 selects
the function origin before arguments and carries it through `CALL_ARGS` /
`CALL_SEND`. Their index is zero-based; compiler flag lookup and diagnostics use
one-based positions. Runtime must consult that selected signature before fetch
and preserve actual reference identity through pending sends, frame entry and
return. Extend the existing location/acquisition helpers in37 and reference/root
ownership in39; do not turn every operand into `KNOWN pvalue`. Current80 only
sends values, rejects reference parameters in `$plain_parameters`, and binds by
value. Current85's deferred append rule is by-value behavior requiring a selected
reference branch; preserve its prefix/key effects. Update public integrity checks
alongside any new tasks/operands and their ownership traversal.

## Originals and diagnostics

Candidate raw batches `.tools/protocol-originals-37j9iq8a` (38) and
`.tools/extra-originals-23ebaobc` (10) retain native lint/execution bytes, checked
ASTs and complete old compiler/runtime states. Extra originals use immutable
broad866 tools/modules. Worker records are decoded JSON, not exact wire. Prior114
protocol originals remain independently retained in archive52d02a43.

| Actual argument | Measured behavior |
| --- | --- |
| literal, whole GLOBALS, measured pre/post increment and assignments | Compiles; `Error` saying argument could not be passed by reference |
| value-returning call | `Notice: Only variables should be passed by reference`; body runs using a temporary reference |
| known-reference literal-array dimension | Static temporary-write error |
| known-reference call-result dimension | Accepted; captured body writes3 |
| forward-reference literal-array dimension | Lint0; runtime Error: Cannot use temporary expression in write context |
| `$this` without object context | Fetch Error before reference-send error |
| multiline literal actual | Reference-send Error at argument line2, separately from outer call line1 |

The earlier-effect controls print `first` then fail sending argument2, without
evaluating the later argument. Keep notice/effect order and caller-only traces
for errors before callee entry. The supplemental forward literal-array-dimension original is retained in
`.tools/compiler5-reference-successor/.tools/reference-successor-originals-36ywdi7m`
with exact native bytes and old866 full states; it differs in phase from the
known-target static error. Multiline Notice placement still needs a consumer probe.

## Required pairing and publication

Use actual source calls for direct/computed/global/superglobal cells, append and
nested dimensions, mixed/surplus parameters, recursion, repeated calls, same-cell
parameters, local rebinding, later-argument rebinding, copied arrays and embedded
references. At suspension cuts check pending-send roots, temporary references,
caller/callee aliases, saved-frame/global-table ownership, trace parameter values,
and cleanup after argument errors, too-few entry, body errors, return and foreach
unwinding. Test public resume with corrupted target/index/descriptor/reference
identity, not only explicit helper calls. Preserve originals before repairs.

Run focused compiler/reference and source/state gates with exact copied tools and
the13-reference preflight. Pair code, admission tests and integrity atomically;
retire the old named-compiler reference-parameter pending control only then.
Unsupported, timeouts and tool errors never count as agreement. Never push.

Defaults/types are a separate later milestone: design and12 additional originals
are in `.tools/compiler5-default-stage-design`, archive
`3ecb2a50bdc18ea8fb780d0f25cb712289aa47658d52e1c6faa96a421ffa2b4c`.
Do not bundle defaults, types, variadics, named/unpacked arguments, reference
returns, closures or dynamic callables here. Full core remains169 constructors /
306 obligations with only oracle identity closed; final all-source/full-syntax
and fresh network-isolated offline gates remain mandatory.
