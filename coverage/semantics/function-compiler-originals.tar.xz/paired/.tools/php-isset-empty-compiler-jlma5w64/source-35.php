<?php echo isset(
1
);