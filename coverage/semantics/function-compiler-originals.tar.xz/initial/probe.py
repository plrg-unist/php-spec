from pathlib import Path
import sys,json,base64,subprocess,tempfile
r=Path(__file__).resolve().parent;canonical=r.parents[1]
sys.path.insert(0,str(r/'tests/semantics'));import static_types as types
cases={
'ordinary':b'<?php echo f(3); function f($n) { $x=$n+1; return $x; }',
'recursive':b'<?php function f($n) { if ($n) return $n*f($n-1); return 1; } echo f(4);',
'nested':b'<?php function f($a) { function g($b) {$z=1;return $b;} $x=2;return g($a); } echo f(3);',
'cv':b'<?php $before=1; function f($arg) { $local=1; $_GET; ${"_SERVER"|""}; $name="_GET"; $$name; return $arg; } $after=2;',
'magic':b'<?php namespace N; function f(){echo __FUNCTION__,__METHOD__,__NAMESPACE__,__CLASS__;} f();',
'header':b'<?php $http_response_header=1;function f(){echo $http_response_header;} echo $http_response_header;',
'header-reverse':b'<?php function f(){$http_response_header=1;} echo $http_response_header;',
'dead-break':b'<?php while(false){ function f(){break;} }',
'dead-body':b'<?php if(false){ function f(){[,$x];} }',
'return':b'<?php $a=[1,2];foreach($a as &$x){foreach($a as &$y){echo $x,$y;return 7;}} echo "bad";',
'global':b'<?php $a=2;function f(){global $a;$a++;return $a;}echo f(),$a;',
'duplicate':b'<?php function f(){} function F(){}',
'dup-badbody':b'<?php function f(){} function F(){break;}',
'conditional':b'<?php if(true){function f(){return 3;}}echo f();',
'block':b'<?php echo f();{function f(){return 3;}}',
'import':b'<?php namespace N;use function A as f;function f(){}',
'import-after':b'<?php namespace N;function f(){} use function A as f;',
'signature':b'<?php function f($a,$a){}',
'bare-return':b'<?php function f(){return;} f();',
'function-globals':b'<?php function f(){global $GLOBALS;}',
}
out=r/'originals';out.mkdir(exist_ok=True)
frontend=types.Worker([str(types.PHP),'-n',*types.FLAGS,'-d','extension='+str(r/'.tools/php-file.so'),str(r/'frontend/worker.php')]);adapter=types.Worker([str(r/'_build/default/adapter/main.exe'),str(r)])
records=[]
try:
 for name,source in cases.items():
  file=out/(name+'.php');file.write_bytes(source)
  parsed=frontend.request({'op':'parse','source':base64.b64encode(source).decode()})
  checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True}) if parsed['accepted'] else None
  native=subprocess.run([str(types.PHP),'-n',*types.FLAGS,str(file)],capture_output=True,timeout=10)
  lint=subprocess.run([str(types.PHP),'-n',*types.FLAGS,'-l',str(file)],capture_output=True,timeout=10)
  record={'name':name,'source':base64.b64encode(source).decode(),'parsed':parsed,'checked':checked,'native':{'exit':native.returncode,'stdout':base64.b64encode(native.stdout).decode(),'stderr':base64.b64encode(native.stderr).decode()},'lint':{'exit':lint.returncode,'stdout':base64.b64encode(lint.stdout).decode(),'stderr':base64.b64encode(lint.stderr).decode()}}
  (out/(name+'-before-compiler.json')).write_text(json.dumps(record,indent=2)+'\n')
  if checked:
   fixture=out/(name+'.watsup');fixture.write_text('dec $main() : ppstate\ndef $main() = $ppstart(91, '+checked['fixture']+', '+types.byte_expr(str(file))+')\n')
   oldspecs=[canonical/p for p in json.loads((canonical/'spec/semantics/modules.json').read_text())]
   original=subprocess.run([str(r/'tests/semantics/_build/default/numeric_runner.exe'),*map(str,oldspecs),str(fixture)],capture_output=True,text=True,timeout=30)
   record['original_compiler']={'exit':original.returncode,'stdout':original.stdout,'stderr':original.stderr}
  records.append(record);(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,record['lint']['exit'])
finally:frontend.close();adapter.close()
