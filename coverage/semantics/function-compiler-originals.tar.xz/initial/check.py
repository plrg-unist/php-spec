from pathlib import Path
import json,subprocess,tempfile,shutil
r=Path(__file__).resolve().parent
out=Path(tempfile.mkdtemp(prefix='check-',dir=r))
specs=[r/p for p in json.loads((r/'spec/semantics/modules.json').read_text())]
fixture=r/'smoke.watsup'
if not fixture.exists():fixture.write_text('dec $main() : bool\ndef $main() = true\n')
command=[str(r/'tests/semantics/_build/default/numeric_runner.exe'),*map(str,specs),str(fixture)]
for p in specs+[fixture]:
 q=out/p.relative_to(r);q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
try:
 result=subprocess.run(command,capture_output=True,text=True,timeout=120,cwd=r)
 record={'command':command,'exit':result.returncode,'stdout':result.stdout,'stderr':result.stderr}
except subprocess.TimeoutExpired as e:record={'command':command,'error':'timeout','stdout':str(e.stdout),'stderr':str(e.stderr)}
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
print(out, {k:(v[:2000] if isinstance(v,str) else v) for k,v in record.items() if k!='command'})
