from pathlib import Path
import sys,json,base64,subprocess,tempfile
r=Path(__file__).resolve().parent;canonical=r.parents[1]
sys.path.insert(0,str(r/'tests/semantics'));import static_types as types
cases={
'void-return':b'<?php function f():void{return 1;}',
'never-return':b'<?php function f():never{return;}',
'default-invalid':b'<?php function f($a=[[]=>1]){}',
'byref-return':b'<?php function &f(){return 1;}',
'param-default':b'<?php function f($a=1){}',
'param-type':b'<?php function f(int $a){}',
'variadic':b'<?php function f(...$a){}',
'import-assert':b'<?php use function A as assert;function assert(){}',
'import-autoload':b'<?php use function A as __autoload;function __autoload(){}',
'assert':b'<?php function assert(){}',
'autoload':b'<?php function __autoload(){}',
'namespace-case':b'<?php namespace N;function F(){}use function A as f;',
'header-param':b'<?php function f($http_response_header){echo $http_response_header;}',
'global-header':b'<?php function f(){global $http_response_header;echo $http_response_header;}',
'global-this':b'<?php function f(){global $this;}',
'global-name-effects':b'<?php function f(){global ${($x="a")};return $x;}',
'multiline-body-hole':b'<?php\nfunction f($x)\n{\n [ ,$x];\n}',
'multiline-return':b'<?php\nfunction f() {\n return\n [ ,$x];\n}',
'nested-seen':b'<?php namespace N;function f(){function g(){}}use function A as g;',
'builtin-redeclare':b'<?php function strlen(){}',
}

out=r/'originals2';out.mkdir(exist_ok=True)
frontend=types.Worker([str(types.PHP),'-n',*types.FLAGS,'-d','extension='+str(r/'.tools/php-file.so'),str(r/'frontend/worker.php')]);adapter=types.Worker([str(r/'_build/default/adapter/main.exe'),str(r)])
records=[]
try:
 for name,source in cases.items():
  file=out/(name+'.php');file.write_bytes(source)
  parsed=frontend.request({'op':'parse','source':base64.b64encode(source).decode()})
  checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True}) if parsed['accepted'] else None
  native=subprocess.run([str(types.PHP),'-n',*types.FLAGS,str(file)],capture_output=True,timeout=10)
  lint=subprocess.run([str(types.PHP),'-n',*types.FLAGS,'-l',str(file)],capture_output=True,timeout=10)
  record={'name':name,'source':base64.b64encode(source).decode(),'parsed':parsed,'checked':checked,'native':{'exit':native.returncode,'stdout':base64.b64encode(native.stdout).decode(),'stderr':base64.b64encode(native.stderr).decode()},'lint':{'exit':lint.returncode,'stdout':base64.b64encode(lint.stdout).decode(),'stderr':base64.b64encode(lint.stderr).decode()}}
  (out/(name+'-before-compiler.json')).write_text(json.dumps(record,indent=2)+'\n')
  if checked:
   fixture=out/(name+'.watsup');fixture.write_text('dec $main() : ppstate\ndef $main() = $ppstart(91, '+checked['fixture']+', '+types.byte_expr(str(file))+')\n')
   oldspecs=[canonical/p for p in json.loads((canonical/'spec/semantics/modules.json').read_text())]
   original=subprocess.run([str(r/'tests/semantics/_build/default/numeric_runner.exe'),*map(str,oldspecs),str(fixture)],capture_output=True,text=True,timeout=30)
   record['original_compiler']={'exit':original.returncode,'stdout':original.stdout,'stderr':original.stderr}
  if checked:
   candidate=subprocess.run([str(r/'tests/semantics/_build/default/numeric_runner.exe'),*[str(r/p) for p in json.loads((r/'spec/semantics/modules.json').read_text())],str(fixture)],capture_output=True,text=True,timeout=30)
   record['candidate_compiler']={'exit':candidate.returncode,'stdout':candidate.stdout,'stderr':candidate.stderr}
  records.append(record);(out/'records.json').write_text(json.dumps(records,indent=2)+'\n');print(name,record['lint']['exit'])
finally:frontend.close();adapter.close()
