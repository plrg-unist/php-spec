from pathlib import Path
import sys,json,subprocess,tempfile,base64
r=Path(__file__).resolve().parent
sys.path.insert(0,str(r/'tests/semantics'));import source_compiler as compiler,static_types as types,source_context as context
records=json.loads((r/'originals/records.json').read_text());extra=json.loads((r/'originals2/records.json').read_text());excluded={'void-return','never-return','default-invalid','byref-return','param-default','param-type','variadic'};records += [dict(x,origin='originals2') for x in extra if x['name'] not in excluded];declarations=[]
for i,x in enumerate(records):
 if not x['checked']:continue
 native=x['lint'];run=subprocess.CompletedProcess([],native['exit'],base64.b64decode(native['stdout']),base64.b64decode(native['stderr']))
 events=context.events(run);file=r/x.get('origin','originals')/(x['name']+'.php')
 body=f'dec $case{i}() : bool\ndef $case{i}() = true\n  -- if P = $ppstart(91, {x["checked"]["fixture"]}, {types.byte_expr(str(file))})\n  -- if $pptrace(P) = '+context.expected_events(events,file)+'\n'+('  -- if P.COMPLETION = PPCNORMAL\n' if native['exit']==0 else '')
 declarations.append(body)
(r/'smoke.watsup').write_text(compiler.PREFIX+'\n'.join(declarations)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i,x in enumerate(records) if x['checked']))
