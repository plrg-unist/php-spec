from pathlib import Path
import json,hashlib,stat,base64,sys
R=Path.cwd();K=R/'.tools/runtime7-suppression-integration';sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
sys.path.insert(0,str(K/'frontend'));import wire
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((K/'inputs.json').read_text())
for p,h in m['files'].items():assert sha(K/p)==h and stat.S_IMODE((K/p).stat().st_mode)==m['modes'][p]
names=['suppression-compiler','suppression','reference-return-demand','suppression-state','reference-returns','suppression-reporting','error-suppression-protocol']
identities={m['fingerprint']['sha256']:m}
responses=closures=runners=natives=0;gates=[]
for name in names:
 p=K/'coverage/semantics'/f'{name}.json';d=json.loads(p.read_text());assert d['result']=='pass';raw=Path(d['raw']);raw=raw if raw.is_absolute() else K/raw
 if 'fingerprint' in d:assert d['fingerprint']==identities[d['fingerprint']['sha256']]['fingerprint']
 for rel,h in d.get('direct_inputs',d.get('inputs',{})).items():
  assert sha(K/rel)==h,(name,rel)
  if rel.startswith('vendor/php-src/'):assert sha(R/rel)==h,(name,rel)
 count=0
 for close in raw.rglob('close.json'):
  w=close.parent;assert json.loads(close.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0}
  assert not (w/'stderr').read_bytes() and not (w/'trailing.stdout').read_bytes()
  requests=list(w.glob('*.request'));assert len(requests)==len(list(w.glob('*.response')))
  for n in range(len(requests)):
   wire.loads((w/f'{n}.request').read_text());assert wire.loads((w/f'{n}.response').read_text())['ok']
  responses+=len(requests);count+=len(requests);closures+=1
 for command in raw.rglob('*.command.json'):
  cmd=json.loads(command.read_text())
  if not cmd or Path(cmd[0]).name!='numeric_runner.exe':continue
  prefix=command.name[:-len('.command.json')];parent=command.parent
  assert json.loads((parent/(prefix+'.status.json')).read_text())=={'status':'exit','exit_status':0}
  assert (parent/(prefix+'.stdout')).read_bytes().strip()==b'true' and not (parent/(prefix+'.stderr')).read_bytes()
  runners+=1
 for row in d.get('records',[]):
  if 'native' not in row:continue
  request=row['request'];context=base64.b64decode(request['file']).decode();directory=Path(context).parent
  assert Path(context).read_bytes()==base64.b64decode(row['source_base64'])
  native=row['native'];assert (directory/'native.stdout').read_bytes()==base64.b64decode(native['stdout']) and (directory/'native.stderr').read_bytes()==base64.b64decode(native['stderr'])
  assert json.loads((directory/'native.status.json').read_text())=={'status':'exit','exit_status':native['exit_status']}
  actual=row['actual'];assert actual['status'] in ('normal','php_error','static_rejection') and all(actual[k]==native[k] for k in ['stdout','stderr','exit_status'])
  packet=q.packet(int(request['seconds']),request['microseconds'],[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in request['env']])
  assert (directory/'request.input').read_bytes()==packet
  natives+=1
 gates.append({'name':name,'report':str(p),'sha256':sha(p),'raw':str(raw),'responses':count})
result={'result':'pass','fingerprint':m['fingerprint'],'gates':gates,'responses':responses,'clean_closures':closures,'standalone_true_closures':runners,'source_native_agreements':natives,'scope':'All951/ff8d semantic bytes/modes and direct gate inputs; complete packets/clean workers and standalone true runners. Native source/status/provider packets for source26+state2+reference-return31, with demand19/38, compiler17/131, primitive37 and protocol23/489 separately identified; overlapping counts. Final c650 demand-print correction is separately bridged.'}
finalroot=R/'.tools/runtime7-suppression-final';fp=finalroot/'coverage/semantics/reference-return-demand.json';fd=json.loads(fp.read_text());fr=Path(fd['raw']);fn=fc=0
for close in fr.rglob('close.json'):
 w=close.parent;assert json.loads(close.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0};assert not(w/'stderr').read_bytes() and not(w/'trailing.stdout').read_bytes()
 for i in range(len(list(w.glob('*.request')))):wire.loads((w/f'{i}.request').read_text());assert wire.loads((w/f'{i}.response').read_text())['ok'];fn+=1
 fc+=1
result['final_demand']={'result':'pass','report':str(fp),'sha256':sha(fp),'fingerprint':fd['fingerprint'],'records':len(fd['records']),'assertions':fd['assertions'],'responses':fn,'clean_closures':fc,'raw':str(fr),'scope':'Fresh corrected final print producer; priorff8d fixture/report pass followed by stale print KeyError remains distinct.'}
(R/'.tools/review10-suppression-author-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
