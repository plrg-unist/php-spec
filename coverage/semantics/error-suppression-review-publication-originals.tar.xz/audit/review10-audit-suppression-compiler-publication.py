from pathlib import Path
import hashlib,json,stat
R=Path.cwd();D=R/'.tools/compiler7-suppression';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=json.loads((R/'coverage/semantics/suppression-compiler-pairing.json').read_text());c=p['compiler_manifest'];f=json.loads((R/'.tools/review10-suppression-final/inputs.json').read_text());assert p['final_manifest']==f and p['final']==f['fingerprint'] and p['compiler']==c['fingerprint']
assert set(p['unchanged'])=={n for n,h in c['files'].items() if f['files'].get(n)==h};assert len(p['unchanged'])==942
assert set(p['changed'])=={n for n,h in c['files'].items() if f['files'].get(n)!=h};assert len(p['changed'])==4
assert set(p['added'])==set(f['files'])-set(c['files']) and len(p['added'])==5;assert not p['modes_changed']
for n,v in p['owned_files'].items():assert v=={'sha256':c['files'][n],'mode':c['modes'][n]}=={'sha256':f['files'][n],'mode':f['modes'][n]};assert sha(R/n)==v['sha256'] and stat.S_IMODE((R/n).stat().st_mode)==v['mode']
paths={}
for n in ['SUPPRESSION-COMPILER.md','suppression-compiler-originals.json','suppression-compiler-originals.tar.xz','suppression-compiler-pairing.json']:
 path=('docs/semantics/' if n.endswith('.md') else 'coverage/semantics/')+n;source=D/'publication'/n;assert sha(R/path)==sha(source) and stat.S_IMODE((R/path).stat().st_mode)==stat.S_IMODE(source.stat().st_mode);paths[path]={'sha256':sha(source),'mode':stat.S_IMODE(source.stat().st_mode)}
assert p['paired_code_commit']=='14003331'
out={'result':'pass','code_commit':'14003331','compiler_commit':'601b496d','compiler':c['fingerprint'],'final':f['fingerprint'],'files':paths,'owned_paths':4,'unchanged':942,'changed':4,'added':5,'mode_changes':0,'scope':'Exact full946/951 byte and mode bridge independently derived. Old58 phase identity retained; final951 owns only fresh17/131 plus paired runtime review.'};(R/'.tools/review10-suppression-compiler-publication-audit.json').write_text(json.dumps(out,indent=2));print(out)
