from pathlib import Path
import hashlib,json,tarfile
R=Path.cwd();D=R/'.tools/runtime7-suppression-candidate/publication/coverage/semantics';report=json.loads((D/'error-suppression-runtime-originals.json').read_text());a=D/'error-suppression-runtime-originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==report['sha256']
verified={};snapshots={};sizes={}
with tarfile.open(a,mode='r|xz') as t:
 for z in t:
  if z.name=='MANIFEST.json':
   b=t.extractfile(z).read();assert sha(b)==report['manifest_sha256'];m=json.loads(b)
   wanted={m['files'][f'snapshots/{label}/INPUTS.json']['sha256']:label for label in report['snapshots']};continue
  if z.islnk():h=verified[z.linkname];length=sizes[z.linkname]
  else:
   b=t.extractfile(z).read();h=sha(b);length=len(b)
   if h in wanted:snapshots[wanted[h]]=json.loads(b)
  assert m['files'][z.name]=={'sha256':h,'bytes':length,'mode':z.mode},z.name
  verified[z.name]=h;sizes[z.name]=length
assert set(verified)==set(m['files']) and len(verified)==report['payload_files']
for label,fp in report['snapshots'].items():
 snapshot=snapshots[label];assert snapshot['fingerprint']==fp
 for p,h in snapshot['files'].items():
  key=f'snapshots/{label}/'+p;assert verified[key]==h and m['files'][key]['mode']==snapshot['modes'][p]
final=json.loads((R/'.tools/review10-suppression-final/inputs.json').read_text());assert snapshots['final951']['files']==final['files'] and snapshots['final951']['modes']==final['modes']
baseline=json.loads((R/'.tools/review10-return-final/inputs.json').read_text());assert snapshots['baseline942']['files']==baseline['files'] and snapshots['baseline942']['modes']==baseline['modes']
for p,h in verified.items():
 if p.startswith('pinned-source/'):assert h==sha((R/'vendor/php-src'/p.removeprefix('pinned-source/')).read_bytes())
result={'result':'pass','archive_sha256':report['sha256'],'payload_paths':len(verified),'snapshots':report['snapshots'],'binary_payloads':'Actual retained bytes, hashes and modes verified in each full snapshot.','pinned_sources':sum(p.startswith('pinned-source/') for p in verified),'scope':'Every author archive payload/hardlink/hash/length/mode and all eight complete manifests. Independently held baseline942 and final951 files/modes match, with actual binary payloads and pinned C sources. First944, guarded944, three failed950 reporter preparations, semantic951/ff8d and final951/c650 preserve exact identities.'}
(R/'.tools/review10-suppression-runtime-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(report['sha256'],len(verified),'pass')
