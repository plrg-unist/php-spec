from pathlib import Path
import hashlib,json,tarfile
R=Path.cwd();D=R/'.tools/runtime7-acquire-candidate/publication/coverage/semantics';report=json.loads((D/'call-reference-runtime-originals.json').read_text());a=D/'call-reference-runtime-originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==report['sha256']
verified={};snapshots={};sizes={}
with tarfile.open(a,mode='r|xz') as t:
 for z in t:
  if z.name=='MANIFEST.json':
   b=t.extractfile(z).read();assert sha(b)==report['manifest_sha256'];m=json.loads(b)
   wanted={m['files'][f'snapshots/{label}/INPUTS.json']['sha256']:label for label in report['snapshots']};continue
  if z.islnk():h=verified[z.linkname];length=sizes[z.linkname]
  else:
   b=t.extractfile(z).read();h=sha(b);length=len(b)
   if h in wanted:snapshots[wanted[h]]=json.loads(b)
  assert m['files'][z.name]=={'sha256':h,'bytes':length,'mode':z.mode},z.name
  verified[z.name]=h;sizes[z.name]=length
assert set(verified)==set(m['files']) and len(verified)==report['payload_files']
for label,fp in report['snapshots'].items():
 snapshot=snapshots[label];assert snapshot['fingerprint']==fp
 for p,h in snapshot['files'].items():
  key=f'snapshots/{label}/'+p;assert verified[key]==h and m['files'][key]['mode']==snapshot['modes'][p]
final=json.loads((R/'.tools/review10-reference-final/inputs.json').read_text());assert snapshots['final933']['files']==final['files'] and snapshots['final933']['modes']==final['modes']
baseline=json.loads((R/'.tools/review10-types-canonical/inputs.json').read_text());assert snapshots['baseline926']['files']==baseline['files'] and snapshots['baseline926']['modes']==baseline['modes']
for p,h in verified.items():
 if p.startswith('pinned-source/'):assert h==sha((R/'vendor/php-src'/p.removeprefix('pinned-source/')).read_bytes())
result={'result':'pass','archive_sha256':report['sha256'],'payload_paths':len(verified),'snapshots':report['snapshots'],'binary_payloads':'Actual retained bytes, hashes and modes verified in each full snapshot.','pinned_sources':5,'scope':'Every compact author archive payload/hardlink/hash/length/mode and all four complete manifests. Exact independently held baseline926 and final933 files/modes match; five authoritative pinned C sources match. Original redundant packaging remains separate, with no semantic identity relabeling.'}
(R/'.tools/review10-reference-runtime-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(report['sha256'],len(verified),'pass')
