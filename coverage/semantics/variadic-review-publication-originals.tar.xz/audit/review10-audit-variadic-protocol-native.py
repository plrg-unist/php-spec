from pathlib import Path
import base64,json,sys
R=Path.cwd();K=R/'.tools/runtime7-variadic-final';sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
D=K/'.tools/review10-variadic-protocol-gkwtjum9';o=json.load(open(D/'original.json'));s=json.load(open(D/'state.json'));actual=q.cli.observe(s['state'],o['context']);assert actual['status']=='php_error'
assert Path(o['context']).read_bytes()==base64.b64decode(o['source_base64'])
for k in ['stdout','stderr','exit_status']:assert actual[k]==o['native'][k]
for k in ['stdout','stderr']:assert (D/('native.'+k)).read_bytes()==base64.b64decode(o['native'][k])
assert json.load(open(D/'native.status.json'))['exit_status']==o['native']['exit_status']
r=o['request'];entries=[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in r['env']];assert (D/'request.input').read_bytes()==q.packet(int(r['seconds']),r['microseconds'],entries)
out={'result':'pass','native_runtime_agreements':1,'source_request_packet_observations_exact':True,'raw':str(D),'scope':'Fresh portable protocol source; overlaps dense/source behavior. Completes author39 native profiles alongside source28/regression8/state2 audits.'};(R/'.tools/review10-variadic-protocol-native-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('protocol native pass')
