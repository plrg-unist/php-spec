from pathlib import Path
import base64,hashlib,json,stat,sys
R=Path.cwd();K=R/'.tools/runtime7-variadic-state-timeout';sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
p=K/'coverage/semantics/variadic-state.json';x=json.load(open(p));assert x['result']=='pass' and x['assertions']==829;N=Path(x['original_raw']);O=Path(x['raw']);m=json.load(open(K/'inputs.json'));nr=nc=0
for f in N.rglob('*.response'):
 if 'original-inputs' in f.parts:continue
 assert q.t.wire.loads(f.read_text())['ok'];q.t.wire.loads(f.with_suffix('.request').read_text());nr+=1
for f in N.rglob('close.json'):
 if 'original-inputs' in f.parts:continue
 c=json.load(open(f));assert c['status']=='exit' and c['exit_status']==c['final_exit_status']==0;assert (f.parent/'stderr').read_bytes()==(f.parent/'trailing.stdout').read_bytes()==b'';nc+=1
records=[]
for row in x['records']:
 d=O/row['id'];old=N/row['id'];assert (d/'state.watsup').read_bytes()==(old/'state.watsup').read_bytes();assert hashlib.sha256((d/'state.watsup').read_bytes()).hexdigest()==row['fixture_sha256'];cmd=json.load(open(d/'runner.command.json'));status=json.load(open(d/'runner.status.json'));assert status['status']=='exit' and status['exit_status']==0 and status['seconds']<900;assert (d/'runner.stdout').read_bytes().strip()==b'true' and (d/'runner.stderr').read_bytes()==b''
 for n in cmd[:-1]:
  f=Path(n);rel=str(f.relative_to(K));assert hashlib.sha256(f.read_bytes()).hexdigest()==m['files'][rel] and stat.S_IMODE(f.stat().st_mode)==m['modes'][rel]
 source=base64.b64decode(row['source_base64']);assert (old/'source.php').read_bytes()==source;native=row['native'];assert all(row['actual'][k]==native[k] for k in ['stdout','stderr','exit_status']);assert (old/'native.stdout').read_bytes()==base64.b64decode(native['stdout']);assert (old/'native.stderr').read_bytes()==base64.b64decode(native['stderr']);assert json.load(open(old/'native.status.json'))['exit_status']==native['exit_status'];req=row['request'];assert (old/'request.input').read_bytes()==q.packet(int(req['seconds']),req['microseconds'],[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in req['env']]);records.append({'id':row['id'],'fixture_sha256':row['fixture_sha256'],'assertions':row['assertions'],'status':status,'native_original':str(old)})
t=json.load(open(N/'variadic-returned-reference-tail/runner.status.json'));assert t=={'status':'timeout','seconds':300};assert not (N/'variadic-tail-singleton-after-cleanup/runner.status.json').exists();report={'result':'pass','fingerprint':m['fingerprint'],'prepared_fingerprint':x['prepared_fingerprint'],'raw':str(O),'original_raw':str(N),'records':records,'decoded_responses':nr,'clean_worker_closures':nc,'standalone_true':2,'native_runtime_agreements':2,'assertions':829,'original_timeout':t,'scope':'Exact original prepared fixtures/module/runner identities; only900s allowance differs, no native rerun. First300s timeout and originally unrun second fixture remain distinct from completed retries.'};(R/'.tools/review10-variadic-author-state-audit.json').write_text(json.dumps(report,indent=2));print(report)
