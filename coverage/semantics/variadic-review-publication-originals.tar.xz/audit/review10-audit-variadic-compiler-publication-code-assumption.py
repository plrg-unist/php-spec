from pathlib import Path
import hashlib,json,stat
R=Path.cwd();D=R/'.tools/compiler7-variadic/publication';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();p=json.load(open(R/'coverage/semantics/variadic-compiler-pairing.json'));c=p['compiler'];f=json.load(open(R/'.tools/review10-variadic-state-timeout/inputs.json'))
assert p['final']==f
unchanged={n for n,h in c['files'].items() if f['files'].get(n)==h};changed=set(c['files'])-unchanged;added=set(f['files'])-set(c['files'])
assert len(unchanged)==p['unchanged_shared_paths']==952 and changed==set(p['changed']) and len(changed)==3
assert added==set(p['added']) and len(added)==4 and not p['removed'];assert p['all_shared_modes_equal'] and all(c['modes'][n]==f['modes'][n] for n in c['files'])
for n in p['compiler_owned_unchanged']:
 assert c['files'][n]==f['files'][n]==sha(R/n) and c['modes'][n]==stat.S_IMODE((R/n).stat().st_mode)
paths={}
for n in ['VARIADIC-COMPILER.md','variadic-compiler-originals.json','variadic-compiler-originals.tar.xz','variadic-compiler-final-originals.json','variadic-compiler-final-originals.tar.xz','variadic-compiler-pairing.json']:
 path=('docs/semantics/' if n.endswith('.md') else 'coverage/semantics/')+n;source=D/n
 if 'originals' in n:
  owner=R/'.tools'/('compiler7-variadic-final-supplement' if '-final-' in n else 'compiler7-variadic')
  source=owner/('archive.json' if n.endswith('.json') else 'originals.tar.xz')
 assert sha(R/path)==sha(source) and stat.S_IMODE((R/path).stat().st_mode)==stat.S_IMODE(source.stat().st_mode)
 paths[path]={'sha256':sha(source),'mode':stat.S_IMODE(source.stat().st_mode)}
assert 'b49a564c' in (R/'docs/semantics/VARIADIC-COMPILER.md').read_text()
out={'result':'pass','code_commit':'b49a564c','compiler_commit':'3c27910a','compiler':c['fingerprint'],'final':f['fingerprint'],'files':paths,'owned_paths':4,'unchanged':952,'changed':3,'added':4,'mode_changes':0,'scope':'Full compiler955 to canonical959 bridge derived independently; semanticcee5 and compiler46/4d69 retain identities, with explicit test-only expectation and timeout bridges to4854.'}
(R/'.tools/review10-variadic-compiler-publication-audit.json').write_text(json.dumps(out,indent=2)+'\n');print('six compiler publication paths pass')
