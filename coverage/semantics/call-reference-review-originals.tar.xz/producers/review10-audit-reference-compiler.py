from pathlib import Path
import hashlib,json,tarfile,sys
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
D=R/'.tools/compiler6-reference-calls';report=json.loads((D/'archive.json').read_text());a=D/'originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==report['sha256']
data={};modes={}
with tarfile.open(a,mode='r|xz') as t:
 for member in t:
  if member.name=='SHA256.json':m=json.load(t.extractfile(member));continue
  b=data[member.linkname] if member.islnk() else t.extractfile(member).read()
  assert sha(b)==m['files'][member.name] and member.mode==m['modes'][member.name]
  data[member.name]=b;modes[member.name]=member.mode
assert set(data)==set(m['files']) and len(data)==report['paths']
for prefix,name in [('baseline926','compiler929/baseline-inputs.json'),('compiler929','compiler929/final-inputs.json')]:
 snapshot=json.loads(data[name])
 for rel,h in snapshot['files'].items():
  key=prefix+'/'+rel
  if key in data:assert sha(data[key])==h and modes[key]==snapshot['modes'][rel]
  else:assert m['tools'][key]=={'sha256':h,'mode':snapshot['modes'][rel]}
canonical=json.loads((R/'.tools/review10-types-canonical/inputs.json').read_text())
for name,tool in m['tools'].items():
 rel=name.split('/original-inputs/')[-1] if '/original-inputs/' in name else name.split('/',1)[1]
 assert tool['sha256']==canonical['files'][rel],name
for name,tool in m['historical_native_tool_aliases'].items():
 rel=tool['current_binding'].split('/',1)[1]
 assert tool['sha256']==canonical['files'][rel] and tool['mode']==canonical['modes'][rel]
responses=closures=0
for name,b in data.items():
 if name.endswith('/close.json'):
  parent=name[:-len('close.json')];assert json.loads(b)=={'status':'exit','exit_status':0,'final_exit_status':0}
  assert not data[parent+'stderr'] and not data[parent+'trailing.stdout']
  requests=[n for n in data if n.startswith(parent) and n.endswith('.request')]
  for n in range(len(requests)):
   wire.loads(data[parent+str(n)+'.request'].decode());assert wire.loads(data[parent+str(n)+'.response'].decode())['ok']
  closures+=1;responses+=len(requests)
result={'result':'pass','archive_sha256':report['sha256'],'paths':len(data),'baseline':report['baseline'],'candidate':report['candidate'],'responses':responses,'clean_closures':closures,'tools':len(m['tools']),'historical_native_aliases':len(m['historical_native_tool_aliases']),'scope':'Every archive payload/hash/mode and full baseline926/compiler929 map; retained executable hashes and historical native alias pin; recorded worker packets and clean closures. Native phase and runtime Unsupported distinctions remain original, not semantic agreement counts.'}
(R/'.tools/review10-reference-compiler-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
