from pathlib import Path
import hashlib,json,tarfile,sys
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
D=R/'.tools/compiler6-reference-lines';report=json.loads((D/'archive.json').read_text());a=D/'originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==report['sha256']
data={};modes={}
with tarfile.open(a,mode='r|xz') as t:
 for member in t:
  if member.name=='SHA256.json':m=json.load(t.extractfile(member));continue
  b=data[member.linkname] if member.islnk() else t.extractfile(member).read()
  assert sha(b)==m['files'][member.name] and member.mode==m['modes'][member.name]
  data[member.name]=b;modes[member.name]=member.mode
assert set(data)==set(m['files']) and len(data)==report['paths']
with tarfile.open(R/'.tools/compiler6-reference-calls/originals.tar.xz') as t:old=json.load(t.extractfile('SHA256.json'))
assert json.loads(data['prior/SHA256-original.json'])==old
for p,h in old['files'].items():assert sha(data['prior/'+p])==h and modes['prior/'+p]==old['modes'][p]
for p,v in old['tools'].items():assert m['tools']['prior/'+p]==v
for prefix,name in [('prior/baseline926','prior/compiler929/baseline-inputs.json'),('shared929','shared929/final-inputs.json')]:
 snapshot=json.loads(data[name])
 for rel,h in snapshot['files'].items():
  key=prefix+'/'+rel
  if key in data:assert sha(data[key])==h and modes[key]==snapshot['modes'][rel]
  else:assert m['tools'][key]=={'sha256':h,'mode':snapshot['modes'][rel]}
canonical=json.loads((R/'.tools/review10-types-canonical/inputs.json').read_text())
for name,tool in m['tools'].items():
 rel=next(p for p in canonical['files'] if name.endswith('/'+p))
 assert tool['sha256']==canonical['files'][rel],name
for name,tool in m['historical_native_tool_aliases'].items():
 binding=m['tools'][tool['current_binding']];assert tool['sha256']==binding['sha256'] and tool['mode']==binding['mode']
responses=closures=0
for name,b in data.items():
 if name.endswith('/close.json'):
  parent=name[:-len('close.json')];assert json.loads(b)=={'status':'exit','exit_status':0,'final_exit_status':0}
  assert not data[parent+'stderr'] and not data[parent+'trailing.stdout']
  requests=[n for n in data if n.startswith(parent) and n.endswith('.request')]
  for n in range(len(requests)):
   wire.loads(data[parent+str(n)+'.request'].decode());assert wire.loads(data[parent+str(n)+'.response'].decode())['ok']
  closures+=1;responses+=len(requests)
paired=json.loads((R/'.tools/review10-reference-final/inputs.json').read_text())
shared=json.loads(data['shared929/final-inputs.json'])
changed=[]
for p,h in shared['files'].items():
 if paired['files'][p]!=h or paired['modes'][p]!=shared['modes'][p]:changed.append(p)
assert set(changed)=={'Makefile','spec/semantics/30-storage.watsup','spec/semantics/40-control.watsup','spec/semantics/42-array-write-control.watsup','spec/semantics/84-call-integrity.watsup','spec/semantics/modules.json'},changed
result={'result':'pass','archive_sha256':report['sha256'],'paths':len(data),'preserved_prior_paths':len(old['files']),'candidate':report['candidate'],'paired':paired['fingerprint'],'paired_changed_existing':changed,'responses':responses,'clean_closures':closures,'tools':len(m['tools']),'historical_native_aliases':len(m['historical_native_tool_aliases']),'scope':'Every combined payload/hash/mode; exact prior e406 payload and original manifest; complete926/shared929 maps, pinned tool identities, recorded packets/closures, and paired933 existing-path delta. Historical code9331 focused gates and final929d365 expanded29 gate retain their own identities.'}
(R/'.tools/review10-reference-compiler-final-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
