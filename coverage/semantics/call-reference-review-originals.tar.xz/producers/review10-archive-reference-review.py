from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path.cwd();files={};tools={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
def tree(n,p):
 for f in p.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:add(n+'/'+str(f.relative_to(p)),f)
for name,path in [('baseline926',R/'.tools/review10-types-canonical'),('first928',R/'.tools/runtime7-acquire-first'),('final933',R/'.tools/review10-reference-final')]:
 m=json.loads((path/'inputs.json').read_text());add(name+'/inputs.json',path/'inputs.json')
 for rel,h in m['files'].items():
  f=path/rel;assert sha(f.read_bytes())==h and stat.S_IMODE(f.stat().st_mode)==m['modes'][rel],rel;add(name+'/'+rel,f)
for row in json.loads((R/'.tools/review10-reference-raw-audit.json').read_text())['records']:
 p=Path(row['root']);tree('raw/'+p.name,p)
for p in R.glob('.tools/review10-*reference*.py'):add('producers/'+p.name,p)
for p in R.glob('.tools/review10-reference-*-audit.json'):add('audits/'+p.name,p)
add('producers/review10-call-line-originals.py',R/'.tools/review10-call-line-originals.py')
add('compiler/paired933-bridge.json',R/'.tools/compiler6-reference-lines/paired933-bridge.json')
add('author/final-gate-audit.json',R/'.tools/runtime7-acquire-candidate/final-gate-audit.json')
for name in ['zend_compile.c','zend_execute.c','zend_vm_def.h']:add('vendor/php-src/Zend/'+name,R/'vendor/php-src/Zend'/name)
m={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools}
a=R/'.tools/review10-reference-review-originals.tar.xz';seen={}
with tarfile.open(a,'w:xz') as t:
 b=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(m['files'][n],m['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
verified={}
with tarfile.open(a,mode='r|xz') as t:
 for z in t:
  if z.name=='SHA256.json':continue
  h=verified[z.linkname] if z.islnk() else sha(t.extractfile(z).read())
  assert h==m['files'][z.name] and z.mode==m['modes'][z.name];verified[z.name]=h
assert set(verified)==set(files)
result={'archive':str(a),'sha256':sha(a.read_bytes()),'paths':len(files),'bytes':a.stat().st_size,'tools':tools,'baseline':json.loads((R/'.tools/review10-types-canonical/inputs.json').read_text())['fingerprint'],'tested':json.loads((R/'.tools/review10-reference-final/inputs.json').read_text())['fingerprint'],'scope':'Independent original926 acquisition/ownership sources and existing typed-return line defect; immutable first928 Notice-line and deferred-result counterexamples with fixture setup failures separate; exact final933 source/state/protocol and full926 compatibility gates. All142 recorded responses/43 clean closures audited. Binaries hash/mode-bound, raw copied tool modes distinct from executable snapshot modes. Four reference-return source controls remain pending, not agreement.'}
(R/'.tools/review10-reference-review-originals-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result['sha256'],result['paths'],result['bytes'])
