from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
groups={
 'native926-originals':['review10-reference-originals-njtxxlzj','review10-reference-target-originals-p2iinf0z','review10-reference-order-originals-kuinfe7x','review10-call-line-originals-xfi4gcj2'],
 'early928-source':['review10-reference-replay-9281_bjs'],
 'early928-protocol-and-setup':['review10-reference-protocol-xx4hgc_u','review10-reference-protocol-wk0k8vz4','review10-reference-nested-protocol-3lwvqeq2','review10-reference-protocol-990xwto1','review10-reference-nested-protocol-ekmn9q8y','review10-reference-nested-protocol-01kz67pj','review10-reference-unit-original-kf_gwj6n','review10-reference-result-original-jggrxgv5','review10-reference-result-original-juz81xy8','review10-reference-wrapped-result-original-zj9xg4xr','review10-reference-origin-result-original-8cf9ukzk'],
 'final933':['review10-reference-replay-co85hjtv','review10-reference-state-__i54_jb','review10-reference-compatibility-9gp6azbd','review10-reference-final/.tools/call-reference-protocol-fkj98f50'],
}
records=[]
for category,names in groups.items():
 for name in names:
  root=R/'.tools'/name;workers=[]
  for p in root.rglob('close.json'):
   d=p.parent;assert json.loads(p.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes()
   requests=list(d.glob('*.request'));assert len(requests)==len(list(d.glob('*.response')))
   for n in range(len(requests)):
    wire.loads((d/f'{n}.request').read_text());assert wire.loads((d/f'{n}.response').read_text())['ok']
   workers.append({'path':str(d),'responses':len(requests),'clean_closure':True})
  records.append({'root':str(root),'category':category,'workers':workers,'responses':sum(w['responses'] for w in workers)})
result={'result':'pass','records':records,'responses':sum(r['responses'] for r in records),'clean_closures':sum(len(r['workers']) for r in records),'scope':'Complete original926, early928 and final933 recorded packets/clean closures. Native mismatch, Unsupported, malformed-state interpreter failures and standalone fixture setup failures remain distinct categories; successful transport is not semantic agreement.'}
(R/'.tools/review10-reference-raw-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result['responses'],result['clean_closures'])
