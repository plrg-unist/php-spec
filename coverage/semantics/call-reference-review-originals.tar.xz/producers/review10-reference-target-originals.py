from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'valuecall-computed-target-alias':b'<?php\nfunction g(){return [2];}\n$x=[1];$y=&$x;$n="x";$z=($$n=&g());$x[0]=3;echo $x[0],$y[0],$z[0];',
 'valuecall-dim-target-alias':b'<?php\nfunction g(){return [2];}\n$a=[[1]];$y=&$a[0];$z=($a[0]=&g());$a[0][0]=3;echo $a[0][0],$y[0],$z[0];',
}
if __name__=='__main__':scope.main(CASES,'review10-reference-target-originals',Path(__file__))
