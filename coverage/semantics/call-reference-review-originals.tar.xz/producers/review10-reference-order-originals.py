from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'valuecall-autovivify-dim-target':b'<?php\nfunction g(){echo "G";return [2];}\n$a[0]=&g();$y=&$a[0];$a[0][0]=3;echo $y[0];',
 'valuecall-return-error-before-assignment':b'<?php\nfunction g():int{echo "G";return [2];}\n$a=[[1]];$y=&$a[0];$a[0]=&g();echo "AFTER";',
}
if __name__=='__main__':scope.main(CASES,'review10-reference-order-originals',Path(__file__))
