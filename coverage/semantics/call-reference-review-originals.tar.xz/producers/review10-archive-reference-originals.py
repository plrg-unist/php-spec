from pathlib import Path
import hashlib,tarfile,json,stat,io,sys,base64
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda b:hashlib.sha256(b).hexdigest()
baseline=json.loads((R/'.tools/review10-types-canonical/inputs.json').read_text())
files={};tools={};responses=closures=0
def add(name,path):
 if path.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  rel=str(path).split('/original-inputs/')[-1]
  assert sha(path.read_bytes())==baseline['files'][rel]
  tools[name]={'sha256':baseline['files'][rel],'mode':baseline['modes'][rel],'baseline_path':rel}
 else:files[name]=path
for label,name in [('ownership','review10-reference-originals-njtxxlzj'),('targets','review10-reference-target-originals-p2iinf0z')]:
 d=R/'.tools'/name;report=json.loads((d/'report.json').read_text());assert report['fingerprint']==baseline['fingerprint']
 for row in report['records']:
  p=d/row['id'];assert Path(row['context']).read_bytes()==base64.b64decode(row['source_base64'])
  assert row['actual']['status']=='unsupported' and not row['pass']
  assert (p/'native.stdout').read_bytes()==base64.b64decode(row['native']['stdout'])
  assert (p/'native.stderr').read_bytes()==base64.b64decode(row['native']['stderr'])
  assert json.loads((p/'native.status.json').read_text())=={'status':'exit','exit_status':row['native']['exit_status']}
 for close in d.rglob('close.json'):
  w=close.parent;assert json.loads(close.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0}
  assert not (w/'stderr').read_bytes() and not (w/'trailing.stdout').read_bytes()
  requests=list(w.glob('*.request'));assert len(requests)==len(list(w.glob('*.response')))
  for n in range(len(requests)):
   wire.loads((w/f'{n}.request').read_text());assert wire.loads((w/f'{n}.response').read_text())['ok']
  responses+=len(requests);closures+=1
 for p in d.rglob('*'):
  if p.is_file():add(label+'/'+str(p.relative_to(d)),p)
for name in ['review10-reference-originals.py','review10-reference-target-originals.py','review10-archive-reference-originals.py']:
 add('producers/'+name,R/'.tools'/name)
add('baseline926.json',R/'.tools/review10-types-canonical/inputs.json')
for name in ['vendor/php-src/Zend/zend_execute.c','tests/semantics/request_environment.py','bin/php-semantics','frontend/wire.py']:
 add(name,R/name)
m={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools}
a=R/'.tools/review10-reference-originals.tar.xz';seen={}
with tarfile.open(a,'w:xz') as t:
 b=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(m['files'][n],m['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(a) as t:
 for n in sorted(m['files']):assert sha(t.extractfile(n).read())==m['files'][n] and t.getmember(n).mode==m['modes'][n]
r={'archive':str(a),'sha256':sha(a.read_bytes()),'paths':len(files),'bytes':a.stat().st_size,'baseline':baseline['fingerprint'],'responses':responses,'clean_closures':closures,'tools':tools,'scope':'Eight native/current926 exact source/request originals: four value-call assignment ownership/target controls, four reference-return ownership controls. All runtime Unsupported; no semantic agreement. Full raw native and recorded adapter/frontend closures retained. Copied input modes retained literally; executable tool modes bound separately to accepted926.'}
(R/'.tools/review10-reference-originals-archive.json').write_text(json.dumps(r,indent=2)+'\n');print(r['sha256'],r['paths'],r['bytes'],responses,closures)
