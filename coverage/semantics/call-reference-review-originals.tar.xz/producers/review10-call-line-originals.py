from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'typed-return-call-argument-emission':b'<?php\nfunction g($x){return [];}\nfunction f():int{\nreturn g(\n 1\n);\n}\nf();',
}
if __name__=='__main__':scope.main(CASES,'review10-call-line-originals',Path(__file__))
