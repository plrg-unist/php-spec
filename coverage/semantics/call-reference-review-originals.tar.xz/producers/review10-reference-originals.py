from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'valuecall-nested-array-owner':b'<?php\nfunction g(){return [1,2];}\nfunction f(){$x=&g();$y=$x;$x[0]=3;return [$x,$y];}\n$a=f();echo $a[0][0],$a[1][0];',
 'valuecall-assign-result-alias':b'<?php\nfunction g(){return [2];}\n$x=[1];$y=&$x;$z=($x=&g());$x[0]=3;echo $x[0],$y[0],$z[0];',
 'refreturn-value-array-cow':b'<?php\n$a=[1];function &f(){global $a;return $a;}\n$b=f();$b[0]=2;echo $a[0],$b[0];',
 'refreturn-held-send-unset':b'<?php\n$x=[1];function &f(){global $x;return $x;}\nfunction g(){global $x;unset($GLOBALS["x"]);return 0;}\nfunction h(&$a,$b){$a[0]=3;echo $a[0];}\nh(f(),g());echo isset($x);',
 'refreturn-forward-local-array-owner':b'<?php\nfunction &g(){$a=[1];return $a;}\nfunction &f(){return g();}\n$x=&f();$y=&$x;$x[0]=3;echo $y[0];',
 'typed-refreturn-error-global-array-owner':b'<?php\n$a=[1];$b=&$a;function &f():int{global $a;return $a;}\n$x=&f();',
}
if __name__=='__main__':scope.main(CASES,'review10-reference-originals',Path(__file__))
