from pathlib import Path
import argparse,base64,hashlib,json,subprocess,sys,tempfile
parser=argparse.ArgumentParser();parser.add_argument('candidate',type=Path);parser.add_argument('--match',default='');args=parser.parse_args()
R=Path.cwd();K=args.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'))
import function_call_state as cs
import request_environment as q
import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-reference-state-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes())
original=R/'.tools/review10-reference-originals-njtxxlzj/report.json';rows={r['id']:r for r in json.loads(original.read_text())['records']}
extra=R/'.tools/review10-reference-target-originals-p2iinf0z/report.json';rows.update({r['id']:r for r in json.loads(extra.read_text())['records']})
order=R/'.tools/review10-reference-order-originals-kuinfe7x/report.json';rows.update({r['id']:r for r in json.loads(order.read_text())['records']})
selection=['valuecall-nested-array-owner','valuecall-dim-target-alias','valuecall-return-error-before-assignment']
selection=[n for n in selection if args.match in n];assert selection
modules=[K/n for n in json.loads((K/'spec/semantics/modules.json').read_text())];runner=K/'tests/semantics/_build/default/numeric_runner.exe';sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={str(p.relative_to(K)):sha(p.read_bytes()) for p in [*modules,runner,K/'tests/semantics/function_call_state.py',K/'tests/semantics/recorded_worker.py']};before=q.t.syntax_validation.implementation_fingerprint()
(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'closure':before,'direct':inputs,'source_report':str(original),'source_report_sha256':sha(original.read_bytes()),'extra_report':str(extra),'extra_report_sha256':sha(extra.read_bytes()),'order_report':str(order),'order_report_sha256':sha(order.read_bytes())},indent=2)+'\n')
for p in inputs:
 dst=D/'original-inputs'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((K/p).read_bytes())
prefix=cs.PREFIX+r"""
dec $review_default_item(pstate, nat*) : pvalue
def $review_default_item(S, n_name*) = $entry_value(S, pitem)
  -- if $lookup(S.ENV, n_name*) = (n_cell)
  -- if S.STORE[n_cell] = DEFINED (PARRAY n_array)
  -- if $entry_lookup(S.ARRAYS[n_array].ITEMS, KINT 0) = (pitem)
"""
extras={
 'valuecall-nested-array-owner':['$lookup(S_out.ENV, [97]) = (n_a)','S_out.STORE[n_a] = DEFINED (PARRAY n_array)'],
 'valuecall-return-error-before-assignment':['$lookup(S_out.ENV, [97]) = (n_a)','S_out.STORE[n_a] = DEFINED (PARRAY n_array)','$entry_lookup(S_out.ARRAYS[n_array].ITEMS, KINT 0) = (ALIAS n_y)','$lookup(S_out.ENV, [121]) = (n_y)','n_y <- S_out.REFCELLS','$review_default_item(S_out, [121]) = PINT 1'],
 'valuecall-dim-target-alias':['$lookup(S_out.ENV, [97]) = (n_a)','S_out.STORE[n_a] = DEFINED (PARRAY n_array)','$entry_lookup(S_out.ARRAYS[n_array].ITEMS, KINT 0) = (ALIAS n_y)','$lookup(S_out.ENV, [121]) = (n_y)','n_y <- S_out.REFCELLS','$review_default_item(S_out, [121]) = PINT 3','$review_default_item(S_out, [122]) = PINT 2'],
}

records=[];frontend=adapter=None
print(D,flush=True)
try:
 frontend=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire')
 adapter=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for name in selection:
  row=rows[name];directory=D/name;directory.mkdir();(directory/'original.json').write_text(json.dumps(row,indent=2)+'\n')
  assert Path(row['context']).read_bytes()==base64.b64decode(row['source_base64'])
  parsed=frontend.request({'op':'parse','source':row['source_base64']});assert parsed['accepted'];checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True})
  (directory/'checked.json').write_text(json.dumps(checked)+'\n')
  result=adapter.request({'op':'execute','ast':parsed['ast'],'steps':10000,'filename':q.b64(bytes(Path(row['context']))),'request':row['request']});(directory/'state.json').write_text(json.dumps(result)+'\n')
  actual=q.cli.observe(result['state'],row['context']);assert actual['status'] in ('normal','php_error') and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  initial='$php_request_run('+checked['fixture']+', 0, '+json.dumps(q.b64(bytes(Path(row['context']))))+', '+rs.request_fixture(row['request'])+')'
  completion='THROWN "TypeError" n_message* 2' if name=='valuecall-return-error-before-assignment' else 'NORMAL'
  checks=['S_initial = '+initial,'S_initial.COMPLETION = BUDGET','S = S_initial[.COMPLETION = NORMAL]','S_out = $drive(S, 10000)','S_out.COMPLETION = '+completion,'$outputs(S_out.EVENTS) = '+cs.d.byte_sequence(base64.b64decode(row['native']['stdout'])),'S_out.FRAMES = eps','S_out.CURRENT = eps','S_out.GLOBALTABLE = eps','S_out.ITERATORS = eps','S_out.HELD = eps','S_out.TODO = eps','S_out.CONSTCONTEXT = eps','$heap_valid($heap_graph(S_out))','$call_valid(S_out)','$call_descriptors_valid(S_out)',*extras[name]]
  for budget in [*range(33),64,128]:
   checks += [f'S_b{budget} = $drive(S, {budget})',f'$resume_destructuring(S_b{budget}, 1) = $drive(S, {budget+1})',f'$heap_valid($heap_graph(S_b{budget}))',f'$call_valid(S_b{budget})',f'$call_descriptors_valid(S_b{budget})',f'S_b{budget}.REQUEST = S.REQUEST',f'S_b{budget}.HTTPROOTS = S.HTTPROOTS']
  checks += [f'$resume_destructuring(S_b{budget}, 10000) = S_out' for budget in [0,1,7,16,32,64,128]]
  fixture=directory/'state.watsup';fixture.write_text(prefix+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+c+'\n' for c in checks));records.append({'id':name,'fixture':str(fixture),'assertions':len(checks),'actual':actual})
finally:
 try:
  if frontend is not None:frontend.close()
 finally:
  if adapter is not None:adapter.close()
for row in records:
 directory=Path(row['fixture']).parent;command=[str(runner),*map(str,modules),row['fixture']];(directory/'runner.command.json').write_text(json.dumps(command)+'\n')
 try:result=subprocess.run(command,capture_output=True,timeout=300)
 except subprocess.TimeoutExpired as error:
  (directory/'runner.stdout').write_bytes(error.stdout or b'');(directory/'runner.stderr').write_bytes(error.stderr or b'');(directory/'runner.status.json').write_text(json.dumps({'status':'timeout','seconds':300})+'\n');raise
 (directory/'runner.stdout').write_bytes(result.stdout);(directory/'runner.stderr').write_bytes(result.stderr);(directory/'runner.status.json').write_text(json.dumps({'status':'exit','exit_status':result.returncode})+'\n');row['pass']=result.returncode==0 and result.stdout.strip()==b'true' and not result.stderr
 (D/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(row['id'],row['pass'],flush=True);assert row['pass']
assert before==q.t.syntax_validation.implementation_fingerprint();assert all(sha((K/p).read_bytes())==h for p,h in inputs.items())
report={'result':'pass','candidate':str(K),'fingerprint':before,'direct_inputs':inputs,'raw':str(D),'records':records,'assertions':sum(r['assertions'] for r in records),'one_step_budgets':[*range(33),64,128],'full_resume_budgets':[0,1,7,16,32,64,128]};(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(D,report['assertions'])
