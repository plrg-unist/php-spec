<?php
function g($x){return [];}
function f():int{
return g(
 1
);
}
f();