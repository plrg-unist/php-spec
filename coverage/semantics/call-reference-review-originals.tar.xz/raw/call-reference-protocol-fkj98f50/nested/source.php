<?php
function g(){return [1,2];}
function f(){$x=&g();$y=$x;$x[0]=3;return [$x,$y];}
$a=f();echo $a[0][0],$a[1][0];