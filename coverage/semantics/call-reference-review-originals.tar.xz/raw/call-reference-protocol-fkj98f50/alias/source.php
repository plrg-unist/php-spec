<?php
function g(){return [2];}
$x=[1];$y=&$x;$z=($x=&g());$x[0]=3;echo $x[0],$y[0],$z[0];