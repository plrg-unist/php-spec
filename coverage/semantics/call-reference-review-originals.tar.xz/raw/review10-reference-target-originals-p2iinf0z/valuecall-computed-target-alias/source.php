<?php
function g(){return [2];}
$x=[1];$y=&$x;$n="x";$z=($$n=&g());$x[0]=3;echo $x[0],$y[0],$z[0];