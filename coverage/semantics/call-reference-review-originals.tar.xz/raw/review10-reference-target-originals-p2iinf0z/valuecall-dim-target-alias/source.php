<?php
function g(){return [2];}
$a=[[1]];$y=&$a[0];$z=($a[0]=&g());$a[0][0]=3;echo $a[0][0],$y[0],$z[0];