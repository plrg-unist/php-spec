<?php
function g(){echo "G";return [2];}
$a[0]=&g();$y=&$a[0];$a[0][0]=3;echo $y[0];