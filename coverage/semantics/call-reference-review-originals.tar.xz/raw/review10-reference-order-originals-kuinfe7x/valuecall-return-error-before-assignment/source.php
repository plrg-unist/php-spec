<?php
function g():int{echo "G";return [2];}
$a=[[1]];$y=&$a[0];$a[0]=&g();echo "AFTER";