<?php
$x=[1];function &f(){global $x;return $x;}
function g(){global $x;unset($GLOBALS["x"]);return 0;}
function h(&$a,$b){$a[0]=3;echo $a[0];}
h(f(),g());echo isset($x);