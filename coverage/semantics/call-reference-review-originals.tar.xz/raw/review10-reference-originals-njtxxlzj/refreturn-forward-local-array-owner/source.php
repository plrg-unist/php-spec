<?php
function &g(){$a=[1];return $a;}
function &f(){return g();}
$x=&f();$y=&$x;$x[0]=3;echo $y[0];