<?php
$a=[1];$b=&$a;function &f():int{global $a;return $a;}
$x=&f();