# Positional reference send result kinds

This private supplement pairs with the frozen five-path positional-reference
compiler preparation. It activates no canonical semantics. Runtime consumers,
source comparisons, saved-state integrity and ownership remain separate gates.
Defaults, types, named/unpacked/variadic arguments, reference returns and ordinary
builtin bodies remain subsequent work.

Pinned `vendor/php-src/Zend/zend_compile.c` supplies these facts:

- `zend_adjust_for_fetch_type` (2240): read and quiet fetch results are TMP.
- `zend_compile_assign` (3452): ordinary assignment results are TMP; reference
  destructuring emits MAKE_REF with a VAR result. Value destructuring compiles its
  RHS in read mode (direct CV receives QM_ASSIGN).
- `zend_compile_list_assign` (3302): its result is the RHS operand, including
  nested destructuring results. `zend_compile_assign_ref` (3549) produces VAR.
- `zend_compile_args` (3799–3896): nonvariable VAR results use SEND_VAR_NO_REF[_EX];
  TMP/constant results use SEND_VAL[_EX]. Variable expressions separately choose
  compiler-known or runtime-selected access modes. A call returning a value may
  therefore produce a temporary reference and Notice at its argument send.
- Conditional, shorthand conditional and coalesce compilation (10483–10565),
  assignment and all admitted pre/post increment operations produce TMP. They
  cannot become reference sends merely because a runtime intermediate operand is
  represented with a reference cell.

`$ppsend_var(expression)` in module 78 derives the relevant result-kind fact from
the checked original expression: direct function calls and reference assignments;
reference destructuring; recursively the RHS of value destructuring. Other
currently admitted nonvariable expressions are values. This is not a writable
expression predicate and does not replace PPW/PPF/CODEARG selection. Runtime must
consult it before preserving a REFERENCE result for a nonvariable send. Known
noncall expression DIM roots remain static write errors; deferred DIM roots also
use the result kind, as independently captured by review9. Builtin calls converted
by Zend to special TMP-producing instructions require a refinement when their
currently Unsupported execution becomes admitted.

Module 64 now compiles a direct function call used as a reference-destructuring
RHS in PPR, after the existing RHS validation. Acquisition and reference-element
processing remain runtime work. VM MAKE_REF (9262) copies a non-reference VAR
result without turning it into an actual reference. Consequently a by-value call
used there produces the reference-element Notice, and a subsequent argument send
also produces the Only-variables Notice. A reference-list RHS actual CV or DIM
retains its caller cell and produces neither send Notice nor a copy of that root.

The 12 original sources retain pinned native lint/runtime bytes, checked ASTs,
old accepted first-call compiler/runtime states and the old five-path reference
compiler states. They cover direct/forward value-list calls, reference-list CV,
DIM, nested and call results, value-list CV/DIM/literal, and constant conditional/
coalesce CV results. Original accepted-runtime Unsupported outcomes are not
agreements. The separate 12-phase/36-context gate checks exact source occurrence
projection and result kinds; the original 48-reference/16-context gate still
passes. A focused shared destructuring compiler gate passes 111 source phases and
32 malformed-metadata controls. The failed first fixture syntax and missing
legacy archive setup are retained before their fixes. Worker records are decoded
JSON responses, not exact transport wire or separately captured worker stderr.

The earlier frozen reference preparation document's proposed retirement of a
reference-parameter pending control was mistaken: `function_compiler.py` contains
seven pending controls, and all seven stay pending, including reference returns.
No existing pending control is retired by this supplement.
