<?php function f(&$x){}f(
1
);