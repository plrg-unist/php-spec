# Positional reference parameters: private compiler preparation

This candidate extends first-call frozen866 (02f6029f). It is not published source
activation. Runtime sends, binding, ownership and public resumption integrity must
be paired and reviewed after first-call acceptance. Defaults, types, variadics,
named/unpacked arguments and reference returns remain subsequent work. The
existing 114 protocol observations remain unchanged in archive52d02a43.

The compiler reuses `psparam.BYREF` from module17. Module78 accepts untyped
positional reference parameters with value returns and selects `PPW` for actual
variable arguments of finalized earlier declarations, using each parameter's
individual flag. Surplus positions remain by value. Forward, self and namespace
fallback calls retain `PPF`/`CODEARG`; the direct ordinary CV fast path stays `PPR`.
Access choice does not replace runtime-selected callable identity or send behavior.

Literal/other expressions, whole `$GLOBALS`, and direct function call results stay
`PPR`. Their send protocol determines whether execution raises Error or accepts a
temporary reference with Notice. A function call used as a writable dimension
base compiles as `PPR` while its dimension retains `PPW`. A literal temporary array
dimension retains the native temporary-write static error. Existing signature,
temporary-write, source-occurrence, scope and header helpers remain shared.

Runtime must choose the selected parameter from the memoized target before each
argument fetch/send. It acquires and retains actual reference cells for variable
arguments, then binds those cells in the callee, preserving aliases and effects of
later arguments. Do not infer result kind from AST names alone: measured pre/post
increment and assignment controls use execution Error, while a value-returning
function call uses Notice and a fresh temporary reference. Dimensions of call
results need returned-value separation and ownership. Literal/GLOBALS errors
precede entry and use caller traces; temporary references live through the call
and are released on return/error.

Pinned sources: `zend_compile_args`, `zend_delayed_compile_dim` and
`zend_compile_var_inner` in `Zend/zend_compile.c`; `ZEND_SEND_VAL_EX`,
`ZEND_SEND_VAR_NO_REF[_EX]`, `ZEND_SEND_REF` and `ZEND_RECV` in
`Zend/zend_vm_def.h`. Source pin:34308a6666b2d489c509541ea9befea9e2b42348.

Forty-eight native/checked-source originals retain full previous compiler/runtime
states:38 in `.tools/protocol-originals-37j9iq8a`,10 in
`.tools/extra-originals-23ebaobc`. The extra producer uses the immutable broad
root's exact866 modules/tools; commands retain that binding. Worker responses are
decoded JSON, not exact wire. The compiler gate passes48 phases and16 descriptor/
header assertions; runtime agreement is not claimed. The first handwritten DSL
computed-index failure and its exact module remain in
`.tools/function-reference-compiler-tpld7o0b`.

Before atomic admission, pair the runtime consumer and source, alias/COW,
retained-root, error-priority and corrupted/resumed-state gates. Update the old
named-compiler by-reference pending control only with that paired change.
