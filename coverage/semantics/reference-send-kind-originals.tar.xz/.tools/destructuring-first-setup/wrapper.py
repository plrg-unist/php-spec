from pathlib import Path
import base64,hashlib,json,subprocess,sys,tempfile,traceback
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'));import destructuring_compiler as c
T=c.types;manifest=json.loads((D/'final-inputs.json').read_text());out=Path(tempfile.mkdtemp(prefix='destructuring-regression-',dir=D/'.tools'));print(out,flush=True)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(digest(D/p)==h for p,h in manifest['files'].items())
(out/'inputs.json').write_text(json.dumps(manifest,indent=2));(out/'wrapper.py').write_bytes(Path(__file__).read_bytes())
catalogue=[{'id':n,'source_base64':base64.b64encode(s).decode(),'sha256':hashlib.sha256(s).hexdigest()} for n,s in c.CASES.items()]
(out/'catalogue.json').write_text(json.dumps(catalogue,indent=2));print('catalogue',len(catalogue),flush=True)
run_original=subprocess.run;request_original=T.Worker.request;temp_original=tempfile.TemporaryDirectory;calls=[];requests=[]
class KeepTemporaryDirectory(temp_original):
 def __init__(self,*args,**kwargs):super().__init__(*args,**kwargs);self._finalizer.detach()
 def cleanup(self):pass

def run(command,*args,**kwargs):
 i=len(calls);record={'command':list(map(str,command)),'timeout':kwargs.get('timeout'),'cwd':str(kwargs.get('cwd',D))};calls.append(record);(out/f'process-{i}-command.json').write_text(json.dumps(record))
 if 'dune' in list(map(str,command)):
  assert list(map(str,command))==[str(D/'scripts/opam-exec.sh'),'dune','build','--root',str(T.HERE),'numeric_runner.exe'],command
  path='tests/semantics/_build/default/numeric_runner.exe';assert digest(D/path)==manifest['files'][path]
  record.update({'status':'build-not-run','provisioning':'Exact copied numeric runner hash verified','sha256':manifest['files'][path]});(out/f'process-{i}-result.json').write_text(json.dumps(record));return None
 wants_text=kwargs.pop('text',False)
 try:r=run_original(command,*args,**kwargs)
 except subprocess.TimeoutExpired as e:
  for label,value in [('stdout',e.stdout),('stderr',e.stderr)]:
   value=value or b'';(out/f'process-{i}-{label}').write_bytes(value.encode() if isinstance(value,str) else value)
  record['status']='timeout';(out/f'process-{i}-result.json').write_text(json.dumps(record));raise
 except BaseException:
  record['status']='tool-error';record['exception']=traceback.format_exc();(out/f'process-{i}-result.json').write_text(json.dumps(record));raise
 for label,value in [('stdout',r.stdout),('stderr',r.stderr)]:
  value=value or b'';(out/f'process-{i}-{label}').write_bytes(value.encode() if isinstance(value,str) else value)
 record.update({'status':'exit','exit_status':r.returncode});(out/f'process-{i}-result.json').write_text(json.dumps(record))
 if Path(str(command[0])).name=='numeric_runner.exe' and r.stderr:raise AssertionError('SpecTec stderr retained at '+str(out))
 if wants_text:r=subprocess.CompletedProcess(r.args,r.returncode,r.stdout.decode(),r.stderr.decode())
 return r

def request(self,payload):
 i=len(requests);record={'command':self.p.args,'operation':payload.get('op')};requests.append(record);(out/f'request-{i}-command.json').write_text(json.dumps(record));(out/f'request-{i}-input.json').write_text(json.dumps(payload))
 try:r=request_original(self,payload)
 except BaseException:
  record['status']='tool-error';record['exception']=traceback.format_exc();(out/f'request-{i}-status.json').write_text(json.dumps(record));raise
 (out/f'request-{i}-output.json').write_text(json.dumps(r));record['status']='response';(out/f'request-{i}-status.json').write_text(json.dumps(record));return r

subprocess.run=run;T.Worker.request=request;tempfile.TemporaryDirectory=KeepTemporaryDirectory
try:c.main();status='pass'
except BaseException:
 status='fail';(out/'failure.txt').write_text(traceback.format_exc());raise
finally:
 subprocess.run=run_original;T.Worker.request=request_original;tempfile.TemporaryDirectory=temp_original
 stable=all(digest(D/p)==h for p,h in manifest['files'].items());(out/'result.json').write_text(json.dumps({'status':status,'inputs_stable':stable,'source_fingerprint':manifest['fingerprint'],'catalogue_count':len(catalogue),'catalogue_sha256':digest(out/'catalogue.json'),'processes':len(calls),'requests':len(requests),'build':'No build performed; exact copied numeric runner verified'},indent=2));print(out,status,'stable',stable,flush=True);assert stable
