from pathlib import Path
import hashlib,io,json,tarfile
O=Path(__file__).resolve().parent;D=O/'candidate'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((D/'final-inputs.json').read_text());assert all(digest(D/p)==h for p,h in m['files'].items())
files={str(Path('candidate')/p):D/p for p in m['files']}
for p in ['DESIGN.md','archive.py','cases.json','originals.py','send-kind-delta.json']:files[p]=O/p
for p in ['copied-inputs.json','final-inputs.json','semantics-reference-inputs.json','destructuring-regression.py','coverage/semantics/function-reference-compiler.json','coverage/semantics/function-reference-send-compiler.json','coverage/semantics/destructuring-compiler.json']:files['candidate/'+p]=D/p
for prefix in [O/'.tools',D/'.tools']:
 for p in prefix.rglob('*'):
  if p.is_file():files[str(p.relative_to(O))]=p
for rel,h in json.loads((D/'semantics-reference-inputs.json').read_text())['references'].items():assert digest(D/rel)==h;files['candidate/'+rel]=D/rel
bindings={p:h for p,h in m['files'].items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p in bindings:files.pop('candidate/'+p,None)
hashes={p:digest(f) for p,f in files.items()};out=O/'coverage/semantics/reference-send-kind-originals.tar.xz';out.parent.mkdir(parents=True,exist_ok=True);seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 b=(json.dumps({'files':hashes,'tools':bindings,'source_inputs':m},indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 for p,f in sorted(files.items()):
  h=hashes[p];i=t.gettarinfo(str(f),arcname=p)
  if h in seen:i.type=tarfile.LNKTYPE;i.linkname=seen[h];i.size=0;t.addfile(i)
  else:
   seen[h]=p
   with f.open('rb') as stream:t.addfile(i,stream)
with tarfile.open(out,'r:xz') as t:
 for p,h in hashes.items():assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==h,p
report={'archive':str(out.relative_to(O)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':bindings,'input_count':len(m['files']),'scope':'Private reference compiler result-kind supplement;12 native old-source/runtime/phase originals,12 new phases/36 source-path-kind contexts,48 previous phases/16 contexts,111 shared destructuring phases/32 metadata controls. Runtime pairing and source publication remain pending.','originals':'.tools/send-kind-originals-1vpjdo7c','old_reference_compiler':'.tools/old-reference-compiler','source866_archive':{'path':'coverage/semantics/final-call-broad-compiler-originals.tar.xz','sha256':'1dac5ba5cc2ca9a3433d12f71c50d06be5242eff903214c6a68cf604eb3012af'},'raw_send_compiler':'candidate/.tools/function-reference-send-compiler-hvyhc3vi','raw_previous_compiler':'candidate/.tools/function-reference-compiler-ysnufp33','raw_shared_compiler':'candidate/.tools/destructuring-regression-he5f10mf','retained_failures':['candidate/.tools/function-reference-send-compiler-bljat3xj','.tools/destructuring-first-setup'],'worker_boundary':'Decoded complete Worker responses, not exact transport wire or separately captured worker stderr. Exact native/SpecTec subprocess bytes and statuses retained.'}
(O/'coverage/semantics/reference-send-kind-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert all(digest(D/p)==h for p,h in m['files'].items())
