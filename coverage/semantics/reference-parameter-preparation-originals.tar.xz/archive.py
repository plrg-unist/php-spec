from pathlib import Path
import json,hashlib,tarfile,io
D=Path(__file__).resolve().parent
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
original=json.loads((D/'final-inputs.json').read_text());baseline=json.loads((D/'baseline-inputs.json').read_text())
assert all(digest(D/p)==h for p,h in original['files'].items())
for p in ['spec/semantics/46-source-compiler.watsup','spec/semantics/78-function-compiler.watsup']:
 assert digest(D/'before-compiler'/p)==baseline['files'][p]
files={p:D/p for p in original['files']}
for p in ['baseline-inputs.json','final-inputs.json','semantics-reference-inputs.json','reference-delta.json','reference-delta.patch','originals.py','extra-originals.py','cases.json','extra-cases.json','archive.py','coverage/semantics/function-reference-compiler.json']:
 files[p]=D/p
for sub in ['.tools','before-compiler']:
 for p in (D/sub).rglob('*'):
  if p.is_file() and not str(p.relative_to(D)).startswith(('.tools/php/','.tools/php-file.so','.tools/request-clock.so')):files[str(p.relative_to(D))]=p
for p,h in json.loads((D/'semantics-reference-inputs.json').read_text())['references'].items():assert digest(D/p)==h;files[p]=D/p
tools={p:h for p,h in original['files'].items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p,h in tools.items():assert digest(D/p)==h;files.pop(p,None)
hashes={p:digest(f) for p,f in files.items()};out=D/'coverage/semantics/reference-parameter-preparation-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as tar:
 b=(json.dumps({'files':hashes,'tools':tools,'source866':original['baseline']},indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);tar.addfile(i,io.BytesIO(b))
 for p,f in sorted(files.items()):
  h=hashes[p];i=tar.gettarinfo(str(f),arcname=p)
  if h in seen:i.type=tarfile.LNKTYPE;i.linkname=seen[h];i.size=0;tar.addfile(i)
  else:
   seen[h]=p
   with f.open('rb') as stream:tar.addfile(i,stream)
with tarfile.open(out,'r:xz') as tar:
 for p,h in hashes.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h,p
report={'archive':str(out.relative_to(D)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':tools,'paired_source':baseline['fingerprint'],'scope':'Private next-stage compiler preparation:48 native/source old-state originals and48 compiler phase checks plus16 descriptors. Runtime consumer, ownership, integrity and source publication remain pending.','original_batches':['.tools/protocol-originals-37j9iq8a','.tools/extra-originals-23ebaobc'],'accepted_compiler_raw':'.tools/function-reference-compiler-m_1e7yv9','retained_failure':'.tools/function-reference-compiler-tpld7o0b','input_count':len(original['files']),'delta_paths':list(json.loads((D/'reference-delta.json').read_text())['files']),'worker_boundary':'Complete decoded JSON response records; not exact wire or separate worker stderr. Exact native/compiler subprocess bytes retained.'}
(D/'coverage/semantics/reference-parameter-preparation-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert all(digest(D/p)==h for p,h in original['files'].items())
