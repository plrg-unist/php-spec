from pathlib import Path
import hashlib,json,stat
R=Path.cwd();D=R/'.tools/compiler6-reference-return98';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();h=json.loads((D/'publication-hashes.json').read_text());m=json.loads((R/'.tools/review10-return-final/inputs.json').read_text());c=json.loads((D/'final-inputs.json').read_text());p=json.loads((R/'coverage/semantics/reference-return-compiler-pairing.json').read_text())
for n,v in h.items():assert sha(R/n)==v and stat.S_IMODE((R/n).stat().st_mode)==stat.S_IMODE((D/'publication'/n).stat().st_mode)
assert p['compiler']==c['fingerprint'] and p['paired']==m['fingerprint'];assert len(p['copied_exact_files'])==9
for n,v in p['copied_exact_files'].items():assert v=={'sha256':c['files'][n],'mode':c['modes'][n]}=={'sha256':m['files'][n],'mode':m['modes'][n]};assert sha(R/n)==v['sha256'] and stat.S_IMODE((R/n).stat().st_mode)==v['mode']
a=json.loads((D/'spec/semantics/modules.json').read_text());b=json.loads((R/'spec/semantics/modules.json').read_text());assert [n for n in b if n not in a]==['spec/semantics/99-reference-returns.watsup'] and [n for n in b if n in a]==a
out={'result':'pass','compiler_commit':'46c7d848','code_commit':'563fee7a','files':h,'copied_compiler_paths':9,'ordered_registry_addition':'spec/semantics/99-reference-returns.watsup','compiler':c['fingerprint'],'paired':m['fingerprint'],'test_only_bridges_independently_verified':'.tools/review10-return-test-bridge-audit.json'};(R/'.tools/review10-return-compiler-publication-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
