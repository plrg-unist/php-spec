from pathlib import Path
import base64,hashlib,json,stat,tarfile
R=Path.cwd(); P=R/'.tools/runtime7-return-candidate/publication'; C=P/'coverage/semantics'; sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((C/'reference-return-runtime-publication-originals.json').read_text()); blob=C/'reference-return-runtime-publication-originals.tar.xz'
assert sha(blob.read_bytes())==a['sha256'] and blob.stat().st_size==a['bytes']
assert a['history_archive_sha256']=='5b28cfe93fc40de6eab249426d0d43f75ac6fdd831df8393426df19b54c94d23'
with tarfile.open(blob) as t:
 b=t.extractfile('MANIFEST.json').read(); assert sha(b)==a['manifest_sha256']; m=json.loads(b)
 assert len(m['files'])==60
 for n,v in sorted(m['files'].items()):
  b=t.extractfile(n).read();assert sha(b)==v['sha256'] and len(b)==v['bytes'] and t.getmember(n).mode==v['mode'],n
p=json.loads((C/'reference-return-runtime.json').read_text()); f=json.loads((R/'.tools/review10-return-final/inputs.json').read_text())
for n,h in f['files'].items():assert sha((R/n).read_bytes())==h and stat.S_IMODE((R/n).stat().st_mode)==f['modes'][n],n
cli=p['canonical_cli']; assert len(cli['records'])==8 and cli['fingerprint']==f['fingerprint']
for row in cli['records']:
 d=Path(cli['raw'])/row['id']; o=row['original']; actual=json.loads((d/'stdout').read_text());assert actual==row['actual']
 assert json.loads((d/'status.json').read_text())=={'status':'exit','exit_status':0};assert (d/'stderr').read_bytes()==b''
 assert json.loads((d/'request.json').read_text())==o['request'];source=Path(o['context']); assert source.read_bytes()==base64.b64decode(o['source_base64']) and sha(source.read_bytes())==row['source_sha256']
 assert base64.b64decode(o['request']['file']).decode()==str(source)
 cmd=json.loads((d/'command.json').read_text());assert cmd[:2]==[str(R/'bin/php-semantics'),str(source)]
 for k in ['stdout','stderr','exit_status']:assert actual[k]==o['native'][k],(row['id'],k)
 for k,v in o['actual'].items():assert actual[k]==v,(row['id'],k)
 nd=source.parent;assert (nd/'native.stdout').read_bytes()==base64.b64decode(o['native']['stdout']);assert (nd/'native.stderr').read_bytes()==base64.b64decode(o['native']['stderr'])
paths={str(x.relative_to(P)):{'sha256':sha(x.read_bytes()),'mode':stat.S_IMODE(x.stat().st_mode)} for x in P.rglob('*') if x.is_file()};assert len(paths)==7
out={'result':'pass','fingerprint':f['fingerprint'],'canonical_files_modes':942,'publication_archive_sha256':a['sha256'],'payloads':60,'history_dependency':a['history_archive_sha256'],'canonical_cli':{'native_agreements':8,'clean_process_closures':8,'source_request_and_raw_observations_exact':True},'paths':paths}
(R/'.tools/review10-return-publication-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
