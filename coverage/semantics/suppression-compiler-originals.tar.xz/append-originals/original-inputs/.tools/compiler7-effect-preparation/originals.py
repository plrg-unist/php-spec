from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent;B=R.parents[1];sys.path.insert(0,str(B/'tests/semantics'));import function_scope as fs
CASES={
 'silence-folded-append-once':b'<?php $a=[];echo (@([$a[]]=[2]))[0]+3,$a[0],$a[1]??"N",$after,"DONE";',
 'silence-nested-append-once':b'<?php $a=[];echo (@(@([$a[]]=[2])))[0]+3,$a[0],$a[1]??"N",$after,"DONE";',
}
(R/'cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
fs.main(CASES,'compiler7-suppression-effect-originals942',Path(__file__))
