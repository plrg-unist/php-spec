from pathlib import Path
import hashlib,json,os,stat,subprocess,sys,tempfile
R=Path(__file__).resolve().parent;C=R/'candidate';B=R.parents[1];sys.path.insert(0,str(C/'tests/semantics'));import static_types as types
m=json.loads((C/'accepted-first-inputs.json').read_text());names=sorted([*m['files'],'tests/semantics/suppression_compiler.py','tests/semantics/suppression_compiler_cases.json'])
files={n:hashlib.sha256((C/n).read_bytes()).hexdigest() for n in names};modes={n:stat.S_IMODE((C/n).stat().st_mode) for n in names}
identity={'fingerprint':types.syntax_validation.implementation_fingerprint(),'files':files,'modes':modes};assert identity['fingerprint']['files']==len(files)
(C/'final-inputs.json').write_text(json.dumps(identity,indent=2)+'\n')
D=B/'.tools/compiler5-reference-send-kinds/candidate';old=D/'.tools/destructuring-regression-he5f10mf';destructuring=Path(json.loads((old/'process-111-command.json').read_text())['command'][-1])
fixtures={'send-kind':(D/'.tools/function-reference-send-compiler-hvyhc3vi/compiler.watsup',12,36),'destructuring':(destructuring,111,32)}
out=Path(tempfile.mkdtemp(prefix='shared-',dir=R));print(out,flush=True);(out/'inputs.json').write_text(json.dumps(identity,indent=2)+'\n')
modules=[C/p for p in json.loads((C/'spec/semantics/modules.json').read_text())];records=[]
for name,(p,phases,projections) in fixtures.items():
 raw=p.read_bytes();(out/(name+'.watsup')).write_bytes(raw);cmd=[str(C/'tests/semantics/_build/default/numeric_runner.exe'),*map(str,modules),str(p)];(out/(name+'.command.json')).write_text(json.dumps(cmd))
 z=subprocess.run(cmd,capture_output=True,timeout=60);(out/(name+'.stdout')).write_bytes(z.stdout);(out/(name+'.stderr')).write_bytes(z.stderr);(out/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':z.returncode}))
 assert z.returncode==0 and z.stdout==b'true\n' and not z.stderr,(name,z.returncode,z.stdout,z.stderr)
 records.append({'id':name,'phases':phases,'projections':projections,'fixture':str(p),'fixture_sha256':hashlib.sha256(raw).hexdigest()});print(name,phases,projections,flush=True)
assert files=={n:hashlib.sha256((C/n).read_bytes()).hexdigest() for n in names}
(out/'report.json').write_text(json.dumps({'result':'pass','inputs':identity,'records':records,'scope':'Exact retained historical compiler fixtures replayed under current compiler candidate. Historical native/worker phases remain bound to their archive; no fresh native execution.'},indent=2)+'\n')
