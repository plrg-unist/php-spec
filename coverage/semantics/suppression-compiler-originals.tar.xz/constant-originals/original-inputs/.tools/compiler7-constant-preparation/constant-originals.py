from pathlib import Path
import json,sys
R=Path(__file__).resolve().parent;B=R.parents[1];sys.path.insert(0,str(B/'tests/semantics'));import function_scope as fs
CASES={
 'silence-constant-dead-write':b'<?php @false && ($GLOBALS=1);echo "DONE";',
 'silence-constant-dead-hole':b'<?php @true || [,1];echo "DONE";',
 'silence-constant-folded-list-effects':b'<?php echo (@([$x]=[2]))[0]+3,$x,$after,"DONE";',
 'silence-nested-constant-effects':b'<?php echo @(@([$x]=[2])),$x,$after,"DONE";',
 'silence-constant-parent-warning':b'<?php echo (@NAN)."x";echo $after,"DONE";',
}
(R/'constant-cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
fs.main(CASES,'compiler7-suppression-constant-originals942',Path(__file__))
