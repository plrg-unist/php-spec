from pathlib import Path
import json,sys,os,hashlib,subprocess,re
R=Path(__file__).resolve().parent;B=R.parent/'runtime7-return-statefix3';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
N=B/'.tools/compiler7-suppression-effect-originals942-7f4qih7x';rows=json.loads((N/'originals.json').read_text());O=R/'effect-lowering-originals';O.mkdir();profile={'scope':'Separate opcode instrumentation; ordinary native full requests remain at original source root. Lint is compilation-only.','overrides':['opcache.enable_cli=1','opcache.optimization_level=0','opcache.opt_debug_level=65536','opcache.file_update_protection=0'],'baseline':json.loads((R.parent/'runtime7-suppression-candidate/accepted-inputs.json').read_text())['fingerprint']};(O/'profile.json').write_text(json.dumps(profile,indent=2)+'\n');records=[]
for row in rows:
 p=Path(row['context']);d=O/row['id'];d.mkdir();cmd=[str(scope.q.t.PHP),'-n',*scope.q.t.FLAGS,'-l',str(p)];z=subprocess.run(cmd,capture_output=True,env=scope.q.t.ENV,timeout=10);(d/'lint.command.json').write_text(json.dumps(cmd));(d/'lint.stdout').write_bytes(z.stdout);(d/'lint.stderr').write_bytes(z.stderr);(d/'lint.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}));r={'id':row['id'],'source_file':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'lint_exit':z.returncode,'ordinary_native':row['native'],'raw':str(d)}
 if z.returncode==0:
  cmd=[str(scope.q.t.PHP),'-n',*scope.q.t.FLAGS,*[x for setting in profile['overrides'] for x in ['-d',setting]],'-d','variables_order=EGPCS',str(p)];env={'LD_PRELOAD':str(B/'.tools/request-clock.so')};(d/'opcode.command.json').write_text(json.dumps({'argv':cmd,'env':env,'cwd':str(p.parent),'request_input':str(p.parent/'request.input')}));
  with (p.parent/'request.input').open('rb') as stream:
   os.dup2(stream.fileno(),198)
   try:z=subprocess.run(cmd,capture_output=True,cwd=p.parent,env=env,pass_fds=(198,),timeout=10)
   finally:os.close(198)
  (d/'opcode.stdout').write_bytes(z.stdout);(d/'opcode.stderr').write_bytes(z.stderr);(d/'opcode.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}));assert z.returncode==row['native']['exit_status'];assert '; (before optimizer)' in z.stderr.decode();r['instructions']=[line for line in z.stderr.decode().splitlines() if re.match(r'^\d{4} ',line)];print(row['id'],[s for s in r['instructions'] if any(k in s for k in ['SILENCE','FETCH_R','SEND_','RETURN_BY_REF'])],flush=True)
 records.append(r);(O/'records.json').write_text(json.dumps(records,indent=2)+'\n')
(O/'report.json').write_text(json.dumps({'result':'pass','scope':'Two non-idempotent effect compilation phases and pre-optimizer lowering observations. No suppression source admission/runtime agreement.','profile':profile,'records':records},indent=2)+'\n')
