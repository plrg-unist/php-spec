from pathlib import Path
import json,pprint
R=Path(__file__).resolve().parent;C=R/'candidate';B=R.parents[1]
rows=json.loads((R/'phase-lyzxqy5w/records.json').read_text())
cases={r['id']:Path(r['source']).read_text() for r in rows}
contexts={r['id']:r['assertions'][3:] for r in rows if r['id'] not in ['suppress-static-array-hole','suppress-static-write-priority','suppress-constant-default']}
(C/'tests/semantics/suppression_compiler_cases.json').write_text(json.dumps(cases,indent=2)+'\n')
s=(B/'tests/semantics/reference_return_compiler.py').read_text()
s=s.replace('Reference return compiler phases and source designation/mode/emission metadata.','Suppression compiler phases, operand kinds, retained effects and source lines.')
s=s.replace('reference_return_cases.json','suppression_compiler_cases.json')
a=s.index('CONTEXTS = ');b=s.index('\ndef digest',a)
s=s[:a]+'CONTEXTS = '+pprint.pformat(contexts,sort_dicts=False,width=105)+'\n'+s[b:]
s=s.replace('reference-return-compiler','suppression-compiler')
s=s.replace("            if name not in PENDING:\n                body += '  -- if $pptrace(P) = ' + context.expected_events(events, file) + '\\n'\n            if name in PENDING:\n                body += '  -- if P.COMPLETION = PPCABRUPT (UNSUPPORTED '+json.dumps(PENDING[name])+')\\n'\n            elif native.returncode == 0:","            body += '  -- if $pptrace(P) = ' + context.expected_events(events, file) + '\\n'\n            if native.returncode == 0:")
s=s.replace('Reference return compiler source phases, return designation, mode restoration and emission metadata; runtime ownership/demand pairing is separate.','Suppression compile phases, source designation, known operand/effect retention and enclosing lines; runtime emission/ownership pairing is separate.')
s=s.replace("len(CASES)-len(PENDING), 'pending': PENDING,",'len(CASES),')
s=s.replace("print(len(records)-len(PENDING), 'exact compiler phase comparisons;',len(PENDING),'explicit pending controls')", "print(len(records), 'exact compiler phase comparisons;', sum(map(len, CONTEXTS.values())), 'source projections')")
assert 'PENDING' not in s
(C/'tests/semantics/suppression_compiler.py').write_text(s)
p=C/'tests/semantics/reference_return_compiler.py';s=p.read_text();s=s.replace("PENDING = {'suppression': 'ordinary expression or writable operand compilation', 'void-suppression': 'ordinary expression or writable operand compilation'}",'PENDING = {}');p.write_text(s)
print('maintained17 suppression producer and retired2 compiler expectations prepared')
