from pathlib import Path
import hashlib,io,json,lzma,stat,tarfile
R=Path(__file__).resolve().parent;B=R.parents[1];C=R/'candidate';files={};modes={};tools={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(name,p):
 mode=stat.S_IMODE(p.stat().st_mode)
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  tools[name]={'sha256':digest(p),'mode':mode};return
 files[name]=p.read_bytes();modes[name]=mode
def tree(name,p):
 for f in sorted(p.rglob('*')):
  if f.is_file() and f.suffix!='.pyc' and '__pycache__' not in f.parts:add(name+'/'+str(f.relative_to(p)),f)
baseline=B/'.tools/runtime7-return-statefix3'
accepted=B/'.tools/runtime7-suppression-candidate/accepted-inputs.json'
a=json.loads(accepted.read_text());add('baseline942/inputs.json',accepted)
for n,h in a['files'].items():
 p=baseline/n;assert digest(p)==h and stat.S_IMODE(p.stat().st_mode)==a['modes'][n];add('baseline942/'+n,p)
m=json.loads((C/'final-inputs.json').read_text())
for n,h in m['files'].items():
 p=C/n;assert digest(p)==h and stat.S_IMODE(p.stat().st_mode)==m['modes'][n];add('candidate/'+n,p)
for n in ['accepted-first-inputs.json','final-inputs.json','coverage/semantics/suppression-compiler.json','coverage/semantics/reference-return-compiler.json']:add('candidate/'+n,C/n)
tree('candidate/raw',C/'.tools')
for p in sorted(R.iterdir()):
 if p.is_dir() and p.name!='candidate' and p.name!='publication':tree(p.name,p)
 elif p.is_file() and p.suffix in ['.py','.md','.watsup','.json'] and p.name not in ['archive.json']:add(p.name,p)
for label,path in [('constant-originals',B/'.tools/runtime7-suppression-candidate/.tools/compiler7-suppression-constant-originals942-5wdjxbfq'),('constant-producer',B/'.tools/runtime7-suppression-candidate/.tools/compiler7-constant-preparation'),('append-originals',B/'.tools/runtime7-return-statefix3/.tools/compiler7-suppression-effect-originals942-7f4qih7x'),('append-producer',B/'.tools/runtime7-return-statefix3/.tools/compiler7-effect-preparation')]:tree(label,path)
for name,p in [('suppression933',B/'.tools/compiler6-suppression/originals.tar.xz'),('demand933',B/'.tools/compiler6-reference-demand/originals.tar.xz'),('send-kinds',B/'coverage/semantics/reference-send-kind-originals.tar.xz')]:add('historical/'+name+'.tar.xz',p)
for n in ['zend_compile.c','zend_vm_def.h','zend_execute.c','zend_errors.h']:add('vendor/php-src/Zend/'+n,B/'vendor/php-src/Zend'/n)
hashes={n:hashlib.sha256(v).hexdigest() for n,v in files.items()};out=R/'originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 raw=(json.dumps({'files':hashes,'modes':modes,'tools':tools},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,raw in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(hashes[n],modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(raw);t.addfile(z,io.BytesIO(raw))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
report={'archive':str(out),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'tools':tools,'candidate':m['fingerprint'],'semantic_base':json.loads((C/'accepted-first-inputs.json').read_text())['fingerprint'],'scope':'Compiler100 source phases and known-result/effect metadata preparation. Ordinary runtime replays and independent acceptance are separate. No source publication/full family claim.','gates':{'retained_lints':17,'retained_source_assertions':179,'maintained_lints':17,'maintained_contexts':131,'reference_return_lints':58,'reference_return_contexts':49,'historical_fixture_replays':[{'phases':12,'projections':36},{'phases':111,'projections':32}]},'new_originals942':7,'historical_archives':{n:hashes[n] for n in hashes if n.startswith('historical/')},'raw_boundary':'Full recorded frontend/adapter packets and clean closures for new source and phase runs; raw native/lint/opcode/runner output and status. Historical send/destructuring worker limitation remains in nested original archive. Setup failures before native execution have descriptions rather than standalone original stderr capture.'}
(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
