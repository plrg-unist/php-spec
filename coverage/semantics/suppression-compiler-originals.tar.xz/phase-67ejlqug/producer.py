from pathlib import Path
import base64,hashlib,json,subprocess,sys,tempfile
R=Path(__file__).resolve().parent;ROOT=R.parent/'runtime7-suppression-first';sys.path.insert(0,str(ROOT/'tests/semantics'))
import static_types as types,source_compiler as compiler,source_context as context
from recorded_worker import Worker
out=Path(tempfile.mkdtemp(prefix='phase-',dir=R));print(out,flush=True)
modules=[ROOT/p for p in json.loads((ROOT/'spec/semantics/modules.json').read_text())]
runner=ROOT/'tests/semantics/_build/default/numeric_runner.exe'
files=[*modules,runner,ROOT/'_build/default/adapter/main.exe',Path(__file__)]
inputs={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
(out/'inputs.json').write_text(json.dumps({'fingerprint':types.syntax_validation.implementation_fingerprint(),'files':inputs},indent=2))
records=json.loads((R.parent/'compiler6-suppression/lowering-originals/records.json').read_text())+json.loads((R/'lowering-originals/records.json').read_text())
adapter=Worker([str(ROOT/'_build/default/adapter/main.exe'),str(ROOT)],out/'adapter-wire')
frontend=Worker([str(types.PHP),'-n',*types.FLAGS,'-d','extension='+str(ROOT/'.tools/php-file.so'),str(ROOT/'frontend/worker.php')],out/'frontend-wire')
def walk(x,path):
 if isinstance(x,list):
  for i,v in enumerate(x):yield from walk(v,path+[f'PCINDEX {i}'])
 elif isinstance(x,dict) and 'node' in x:
  yield x,path
  for i,v in enumerate(x['fields']):yield from walk(v,path+[f'PCFIELD {i}'])
def expr(path):return '['+','.join(path)+']'
checks=[];rows=[]
try:
 for i,row in enumerate(records):
  p=Path(row['source_file']);raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==row['source_sha256']
  parsed=frontend.request({'op':'parse','source':base64.b64encode(raw).decode()});assert parsed['accepted']
  checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True});assert checked['ok']
  (out/(row['id']+'.checked.json')).write_text(json.dumps(checked))
  d=Path(row['raw']);native=subprocess.CompletedProcess([],row['lint_exit'],(d/'lint.stdout').read_bytes(),(d/'lint.stderr').read_bytes())
  events=context.events(native)
  body=[f'P = $ppstart(91, {checked["fixture"]}, {types.byte_expr(str(p))})', '$pptrace(P) = '+context.expected_events(events,p)]
  if row['lint_exit']==0:
   body+=['P.COMPLETION = PPCNORMAL']
   for j,(node,path) in enumerate((n,p) for n,p in walk(parsed['ast']['program'],[]) if n['node']=='Expr_ErrorSuppress'):
    pp=expr(path);child=expr(path+['PCFIELD 0']);v=f'expression_{j}'
    body += [f'$occurrence_node(P.FOLD.SOURCE.OCCURRENCES, {pp}) = (NExprErrorSuppress {v} metadata_{j})',f'$ppaccess(P, {pp}) = (PPR)',f'$ppaccess(P, {child}) = (PPR)',f'~$ppreturn_variable(NExprErrorSuppress {v} metadata_{j})',f'~$ppreturn_call(NExprErrorSuppress {v} metadata_{j})']
    isvar=node['fields'][0]['node']=='Expr_FuncCall'
    body += [f'$ppsend_var(NExprErrorSuppress {v} metadata_{j}) = {str(isvar).lower()}']
    if row['id'].startswith('silence-constant') or row['id']=='silence-nested-constant-effects':
     body += [f'((PPCEFFECT {pp}) <- P.EXPRESSIONS)']
   if row['id'] in ['silence-constant-dead-write','silence-constant-dead-hole']:
    body += ['$ppaccess(P, [PCINDEX 0,PCFIELD 0,PCFIELD 1]) = eps']
   if row['id']=='suppress-multiline-call-parent':
    body += ['P.FUNCTIONS = [pfunction_g,pfunction_f]', '$code_expression(pfunction_f.CODE.EXPRESSIONS, [PCINDEX 1,PCFIELD 5,PCINDEX 0]) = ((5,false))','$code_expression(pfunction_f.CODE.EXPRESSIONS, [PCINDEX 1,PCFIELD 5,PCINDEX 0,PCFIELD 0]) = ((5,false))','$code_expression(pfunction_f.CODE.EXPRESSIONS, [PCINDEX 1,PCFIELD 5,PCINDEX 0,PCFIELD 0,PCFIELD 0]) = ((4,false))']
  checks.append(f'dec $case{i}() : bool\ndef $case{i}() = true\n'+''.join('  -- if '+c+'\n' for c in body))
  rows.append({'id':row['id'],'source':str(p),'source_sha256':row['source_sha256'],'lint_raw':str(d),'assertions':body})
  (out/(row['id']+'.state.watsup')).write_text(f'dec $main() : ppstate\ndef $main() = $ppstart(91, {checked["fixture"]}, {types.byte_expr(str(p))})\n')
finally:
 try:frontend.close()
 finally:adapter.close()
fixture=out/'compiler.watsup';fixture.write_text(compiler.PREFIX+'\n'.join(checks)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(checks))))
cmd=[str(runner),*map(str,modules),str(fixture)];(out/'runner.command.json').write_text(json.dumps(cmd))
z=subprocess.run(cmd,capture_output=True,timeout=60);(out/'runner.stdout').write_bytes(z.stdout);(out/'runner.stderr').write_bytes(z.stderr);(out/'runner.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}))
(out/'records.json').write_text(json.dumps(rows,indent=2))
assert inputs=={str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in files}
assert z.returncode==0 and z.stdout==b'true\n' and not z.stderr,z
(out/'report.json').write_text(json.dumps({'result':'pass','phases':len(rows),'assertions':sum(len(r['assertions']) for r in rows),'records':rows,'inputs':inputs},indent=2))
print(len(rows),'phases;',sum(len(r['assertions']) for r in rows),'assertions')
