from pathlib import Path
import hashlib,io,json,tarfile
D=Path(__file__).resolve().parent;C=D.parents[1]
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
manifest=json.loads((D/'publication-inputs.json').read_text());files={'candidate/'+p:D/p for p in manifest}
source=json.loads((D/'coverage/semantics/builtin-argument-modes.json').read_text());bridge=json.loads((C/'coverage/semantics/builtin-argument-modes-publication.json').read_text());native=json.loads((C/'coverage/semantics/builtin-argument-modes-canonical.json').read_text())
for p,h in manifest.items():assert digest(C/p)==digest(D/p)==h
for p,h in source['inputs'].items():assert digest(C/p)==h;files['source-inputs/'+p]=C/p
for p in ['scripts/generate-builtin-functions.py','spec/php.watsup','spec/semantics/00-numeric.watsup','spec/semantics/10-bytes.watsup','spec/semantics/16-static-types.watsup','tests/semantics/static_types.py','tests/semantics/profile.json','tests/validate.py','tests/corpus.py','frontend/wire.py']:
 files['prerequisites/'+p]=C/p
for p in ['coverage/semantics/builtin-argument-modes-canonical.json','coverage/semantics/builtin-argument-modes-publication.json']:files['canonical/'+p]=C/p
for label,path in [('source-derivation',C/source['raw']),('canonical-check',C/bridge['source_check']),('canonical-metadata',C/native['raw'])]+[('canonical-source-'+str(i),C/p) for i,p in enumerate(bridge['source_check_preprocessing'])]:
 for p in path.rglob('*'):
  if p.is_file():files[label+'/'+str(p.relative_to(path))]=p
for path in (D/'.tools').glob('builtin-modes-check-*'):
 for p in path.rglob('*'):
  if p.is_file():files['private-gates/'+str(p.relative_to(D/'.tools'))]=p
for p in ['publication-inputs.json','archive.py']:files['candidate/'+p]=D/p
hashes={p:digest(f) for p,f in files.items()}
# Existing pinned tool bytes are hash-bound, as in the accepted occupancy archive.
tools={p:h for p,h in native['inputs'].items() if p.endswith(('/numeric_runner.exe','/bin/php'))}
for p,h in tools.items():assert digest(C/p)==h and digest(D/p)==h,p
name='coverage/semantics/builtin-argument-mode-originals.tar.xz';target=C/name
with tarfile.open(target,'w:xz',preset=6) as tar:
 b=(json.dumps({'files':hashes,'tools':tools,'tool_payloads':'Hash bindings to project-local pinned build; executable bytes are not embedded.'},indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);tar.addfile(i,io.BytesIO(b))
 for p,f in sorted(files.items()):tar.add(f,arcname=p,recursive=False)
with tarfile.open(target,'r:xz') as tar:
 for p,h in hashes.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h,p
r={'archive':name,'sha256':digest(target),'bytes':target.stat().st_size,'paths':len(files),'tools':tools,'scope':'Standalone source-derived builtin positional argument metadata, original minimal-loader setup failure, native metadata and pure table checks, exact canonical reproduction. No call source activation or builtin execution.'}
(C/'coverage/semantics/builtin-argument-mode-originals.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
