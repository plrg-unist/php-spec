<?php
$r=[];
foreach(get_defined_functions()["internal"] as $n) {
 $f=new ReflectionFunction($n);$p=[];
 foreach($f->getParameters() as $a) $p[]=["name"=>$a->getName(),"send_mode"=>$a->isPassedByReference()?($a->canBePassedByValue()?2:1):0,"variadic"=>$a->isVariadic()];
 $r[$n]=$p;
}
echo json_encode(["identity"=>[PHP_VERSION,PHP_SAPI,PHP_INT_SIZE,PHP_ZTS,ini_get("disable_functions")],"functions"=>$r]);
