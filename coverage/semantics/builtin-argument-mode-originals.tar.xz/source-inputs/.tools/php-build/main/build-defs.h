/*
   +----------------------------------------------------------------------+
   | Copyright (c) The PHP Group                                          |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.01 of the PHP license,      |
   | that is bundled with this package in the file LICENSE, and is        |
   | available through the world-wide-web at the following url:           |
   | https://www.php.net/license/3_01.txt                                 |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Author: Stig Sæther Bakken <ssb@php.net>                             |
   +----------------------------------------------------------------------+
*/

#define CONFIGURE_COMMAND " '../php-src/configure'  '--prefix=/home/user/workspace/php-spec/.tools/php-build/../php' '--disable-all' '--enable-cli' '--disable-cgi' '--disable-phpdbg' '--without-pear' '--enable-tokenizer' '--enable-mbstring' '--disable-mbregex' '--enable-ctype'"
#define PHP_PROG_SENDMAIL	"/usr/sbin/sendmail"
#define PEAR_INSTALLDIR         ""
#define PHP_INCLUDE_PATH	".:"
#define PHP_EXTENSION_DIR       "/home/user/workspace/php-spec/.tools/php-build/../php/lib/php/extensions/no-debug-non-zts-20250925"
#define PHP_PREFIX              "/home/user/workspace/php-spec/.tools/php-build/../php"
#define PHP_BINDIR              "/home/user/workspace/php-spec/.tools/php-build/../php/bin"
#define PHP_SBINDIR             "/home/user/workspace/php-spec/.tools/php-build/../php/sbin"
#define PHP_MANDIR              "/home/user/workspace/php-spec/.tools/php-build/../php/php/man"
#define PHP_LIBDIR              "/home/user/workspace/php-spec/.tools/php-build/../php/lib/php"
#define PHP_DATADIR             "/home/user/workspace/php-spec/.tools/php-build/../php/share/php"
#define PHP_SYSCONFDIR          "/home/user/workspace/php-spec/.tools/php-build/../php/etc"
#define PHP_LOCALSTATEDIR       "/home/user/workspace/php-spec/.tools/php-build/../php/var"
#define PHP_CONFIG_FILE_PATH    "/home/user/workspace/php-spec/.tools/php-build/../php/lib"
#define PHP_CONFIG_FILE_SCAN_DIR    ""
#define PHP_SHLIB_SUFFIX        "so"
#define PHP_SHLIB_EXT_PREFIX    ""
