from pathlib import Path
import json
R=Path.cwd();D=R/'.tools/review10-publication'
def put(p,s):
 f=D/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_text(s)
p='PROGRESS.md';s=(R/p).read_text();a=s.index('[Untyped positional defaults]');b=s.index('Earlier checkpoints retain',a)
s=s[:a]+'''[Source strict_types declarations](docs/semantics/SOURCE-STRICT-DECLARATIONS.md)
are independently reviewed in [strict-declaration-review.json](coverage/semantics/strict-declaration-review.json)
on exact **917/309b046c**. Compiler92/runtime93 compile legal strict-only directives,
execute declaration work without runtime effects, and bind unit/function STRICT
metadata to actual source. Setting1 is sticky; zero does not clear it. Five original
forged unit flags survived public resume before the repaired guard; existing
function-flag rejection remains intact. Canonical CLI8 passes. No family closes.

Independent gates retain21 source profiles:18 native agreements and three explicit
encoding/type boundaries. Seven additional builtin profiles remain Unsupported.
Two strict-cache programs pass543 dense state/resumption assertions. Three no-directive
programs preserve entire909 states at seven cuts after removing only new false
pcode.STRICT fields, including saved reference owners and cache-before-error behavior.
Retained-context and fresh17-control protocol runs each pass168 assertions. Author
8 sources/17 flag projections,2 states/542 assertions and17 protocol/168 assertions
pass. The paired compiler gate has37 exact phases/lines, two other-directive
boundaries and47 source projections. Source sets overlap and are not added.

The review audits236 independent recorded responses/23 clean closures, including
historical originals and a separate precleanup tool attempt; author final115/8
is separate. Compiler910/912 preparation, unguarded913 and packaging917/15db remain
historical. The15db→309b bridge removes only an unused test dictionary; runtime,
compiler and tools are byte-identical. Full frozen bytes and modes match canonical.

[Untyped defaults](docs/semantics/SOURCE-POSITIONAL-DEFAULTS.md) remain accepted at
c7cb1b44 on909/e25eb2b9 (code1fce6586, compiler2b247d81, runtime8151b96d).
Their [review](coverage/semantics/default-parameter-review.json) retains130 source
profiles,57 exact author contexts,4 states/1,091 assertions,6 readiness programs,
12 projections/95 assertions and two historical no-default bridges. Omitted
receives, caches, declaration contexts and fresh reference/array ownership remain
unchanged by strict declaration activation.

The next increment connects scalar/container parameter and return types through
existing16/17 normalization and call/default machinery. Caller strictness governs
argument checks; callee strictness governs returns. Successful deferred evaluation
caches before type verification, and caches the uncoerced value. Reference returns,
other callables, other declare directives and builtin execution remain required.
The [core checklist](docs/semantics/CORE-CONTINUATION-CHECKLIST.md) retains control,
objects, exceptions, dynamic sources, generators/fibers, lifetime and core intrinsics.
PHP_VERSION value reads, other missing builtin constants, define/defined and legal
object/class/callable constants remain open. NEW side effects must extend caching.

'''+s[b:]
s=s.replace('untyped defaults reviewed; remaining call protocols pending','untyped defaults and lexical strictness reviewed; typed and remaining call protocols pending').replace('records124 partial,181 pending','records125 partial,180 pending').replace('accepted constants and untyped defaults are reflected in their partial rows.','accepted constants, defaults and lexical strictness are reflected in their partial rows.')
a=s.index('Runtime6 and compiler6 retain implementation continuity');b=s.index('Each coherent increment',a)
s=s[:a]+'''Runtime6 and compiler6 continue with typed parameter/return integration after
strict declaration acceptance. Review10 owns independent strict review and follows
through types; root orchestrates. The [strict contract](docs/semantics/SOURCE-STRICT-DECLARATIONS.md)
and [core checklist](docs/semantics/CORE-CONTINUATION-CHECKLIST.md) record current
continuation. Stage owned files, commit reviewed increments and never push.
Coordinate canonical builds, binaries and the index. Earlier handoffs retain
historical identities and original failures.

'''+s[b:];put(p,s)
p='README.md';s=(R/p).read_text().replace('binds exact909 source, protocol, state and production checks. Types, reference\nreturns and remaining callable protocols stay pending.', 'binds exact909 source, protocol, state and production checks.\n[Source strict_types declarations](docs/semantics/SOURCE-STRICT-DECLARATIONS.md) now\nexecute with source-checked unit/function flags; [independent review](coverage/semantics/strict-declaration-review.json)\nbinds917 source, protocol, cache/resume and complete weak-state bridges. Typed\nchecks, reference returns and remaining callable protocols stay pending.');put(p,s)
p='docs/semantics/CORE-CONTINUATION-CHECKLIST.md';s=(R/p).read_text().replace('124 partial,181 pending','125 partial,180 pending').replace('- [ ] Complete lexical strictness, parameter/return types and reference returns.', '- [x] Strict-only source declarations and source-bound unit/function flags are\n  reviewed on917/309b046c in [strict-declaration-review.json](../../coverage/semantics/strict-declaration-review.json).\n  Compiler92/runtime93 preserve untyped calls/defaults/reference owners; two\n  independent cache states/543 assertions and three complete weak909 state bridges\n  pass. Other declare directives and actual strict/weak type checks remain open.\n- [ ] Complete parameter/return types and reference returns.').replace('binds private strict92\n  preparation; typed/object defaults and remaining callable forms stay open.', 'retains historical strict92\n  preparation; the [current strict contract](SOURCE-STRICT-DECLARATIONS.md) supplies\n  typed integration inputs. Typed/object defaults and remaining callable forms stay open.');put(p,s)
for p in ['docs/semantics/DEFAULTS-REVIEWER-HANDOFF.md','docs/semantics/DEFAULTS-ACTIVATION-PLAN.md']:
 s=(R/p).read_text();i=s.index('\n')+1;s=s[:i]+'''\nStrict92/runtime93 subsequently passed independent review on917/309b046c; see the
[current contract](SOURCE-STRICT-DECLARATIONS.md) and
[review](../../coverage/semantics/strict-declaration-review.json). This document's
909/910 preparation identities remain historical. Typed parameter/return integration
is next; no typed execution or full callable closure is claimed.\n'''+s[i:];put(p,s)
p='coverage/semantics/features.json';x=json.loads((R/p).read_text());implementation=['spec/semantics/92-strict-compiler.watsup','spec/semantics/93-strict-declarations.watsup','spec/semantics/84-call-integrity.watsup'];tests=['tests/semantics/strict_declarations.py','tests/semantics/strict_declaration_compiler.py','tests/semantics/strict_declaration_protocol.py','tests/semantics/strict_declaration_state.py','coverage/semantics/strict-declaration-review.json'];review='Independent lexical strict declaration review on917/309b046c: source literal/placement/line rules, no-op work, source-derived unit/function flags and forged-metadata rejection;21 source profiles18native+3pending,7builtin boundaries,2cache states543assertions,17protocol168 and three complete909 weak-state bridges. Parameter/return enforcement, builtin execution, other declare directives and dependent core protocols remain pending; no family closes.'
for row in x['constructors']+x['runtime_obligations']:
 if row.get('constructor') in ['NDeclareItem','NStmtDeclare'] or row.get('id')=='static.strict-types':row.update(status='partial',implementation=implementation,source_tests=tests,review=review)
put(p,json.dumps(x,indent=2)+'\n')
