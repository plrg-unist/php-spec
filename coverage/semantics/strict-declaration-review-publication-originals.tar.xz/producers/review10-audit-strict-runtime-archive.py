from pathlib import Path
import json,hashlib,tarfile,stat
R=Path.cwd();D=R/'.tools/runtime6-strict-history';info=json.load(open(D/'strict-declaration-runtime-originals.json'));a=D/'strict-declaration-runtime-originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==info['sha256'];seen={}
with tarfile.open(a,'r|xz') as t:
 for e in t:
  b=t.extractfile(e).read()
  if e.name=='index.json':assert sha(b)==info['index_sha256'];m=json.loads(b)
  else:h=e.name.removeprefix('payload/');assert sha(b)==h and h not in seen;seen[h]=len(b)
assert len(m['files'])==info['paths'] and len(seen)==info['unique_payloads'];assert set(seen)=={x['sha256'] for x in m['files'] if 'sha256' in x};paths={x['path']:x for x in m['files']};assert len(paths)==info['paths'];assert m['inputs']==json.load(open(R/'.tools/review10-strict-final/inputs.json'))
for x in m['files']:
 p=R/x['path']
 if 'sha256' in x:assert seen[x['sha256']]==x['bytes'];assert sha(p.read_bytes())==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==x['mode'],p
 else:assert p.is_symlink() and p.readlink().as_posix()==x['symlink']
for p,h in m['inputs']['files'].items():
 x=paths['.tools/runtime6-strict-directive/'+p];assert x['sha256']==h and x['mode']==m['inputs']['modes'][p]
r={'result':'pass','archive':str(a),'sha256':info['sha256'],'paths':info['paths'],'unique_payloads':len(seen),'inputs':m['inputs']['fingerprint'],'all_payload_bytes_and_path_modes':True,'scope':'Author content-addressed archive, every unique payload and indexed path/mode, complete final917 closure, raw source/state/protocol and historical failures preserved.'};(R/'.tools/review10-strict-runtime-archive-audit.json').write_text(json.dumps(r,indent=2));print(r)
