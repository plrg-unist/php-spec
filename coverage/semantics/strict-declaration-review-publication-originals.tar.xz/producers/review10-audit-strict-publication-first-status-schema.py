from pathlib import Path
import json,tarfile,hashlib,stat,base64
R=Path.cwd();D=R/'.tools/runtime6-strict-history';sha=lambda b:hashlib.sha256(b).hexdigest();info=json.load(open(D/'strict-declaration-runtime-publication-originals.json'));a=D/'strict-declaration-runtime-publication-originals.tar.xz';assert sha(a.read_bytes())==info['sha256'];history=json.load(open(D/'index.json'));old={x['sha256'] for x in history['files'] if 'sha256' in x};seen={}
with tarfile.open(a,'r|xz') as t:
 for e in t:
  b=t.extractfile(e).read()
  if e.name=='index.json':assert sha(b)==info['index_sha256'];m=json.loads(b)
  else:h=e.name.removeprefix('payload/');assert sha(b)==h;seen[h]=len(b)
assert len(m['files'])==info['paths'] and len(seen)==info['new_payloads']
for x in m['files']:
 p=R/x['path'];assert x['sha256'] in old|seen.keys();assert sha(p.read_bytes())==x['sha256'] and stat.S_IMODE(p.stat().st_mode)==x['mode'],p
K=R/'.tools/runtime6-strict-directive';manifest=json.load(open(K/'final-inputs.json'))
for p,h in manifest['files'].items():assert sha((R/p).read_bytes())==h and stat.S_IMODE((R/p).stat().st_mode)==manifest['modes'][p],p
cli=json.load(open(K/'.tools/strict-publication-cli-_xrbyvqx/report.json'));assert cli['result']=='pass' and cli['fingerprint']==manifest['fingerprint'] and len(cli['records'])==8
for x in cli['records']:
 d=Path(cli['raw'])/x['id'];assert json.load(open(d/'status.json'))=={'status':'exit','exit_status':0};assert not (d/'stderr').read_bytes();actual=json.loads((d/'stdout').read_bytes());original=x['original'];assert actual['status'] in ('normal','php_error','static_rejection');assert all(actual[k]==original['native'][k] for k in ['stdout','stderr','exit_status']);assert sha(Path(original['context']).read_bytes())==x['source_sha256'];assert json.load(open(d/'request.json'))==original['request'];command=json.load(open(d/'command.json'));assert command[0]==str(R/'bin/php-semantics') and original['context'] in command
pub=json.load(open(D/'publication-inputs.json'))
for p,x in pub['files'].items():assert sha((R/x['source']).read_bytes())==x['sha256'] and stat.S_IMODE((R/x['source']).stat().st_mode)==x['mode'],p
r={'result':'pass','fingerprint':manifest['fingerprint'],'publication_archive':{'sha256':info['sha256'],'paths':48,'new_payloads':27,'depends_on':info['history_sha256']},'canonical_inputs_bytes_modes':917,'cli_observations':8,'author_publication_paths':9,'scope':'Exact archive payload/dependency and canonical917 bytes/modes, eight actual production CLI stdout/stderr/status envelopes and native observations at original source/request contexts; nine author reports preserve original bytes/modes.'};(R/'.tools/review10-strict-publication-audit.json').write_text(json.dumps(r,indent=2));print(r)
