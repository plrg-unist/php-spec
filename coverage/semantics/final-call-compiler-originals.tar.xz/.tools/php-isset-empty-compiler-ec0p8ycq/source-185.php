<?php isset($a,
$b[
]);