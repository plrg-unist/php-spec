<?php isset($a,
${[1]});