<?php echo "A";${
[]
}=7;echo "B";