<?php echo "A";$r=&${
[1]
};echo "B";