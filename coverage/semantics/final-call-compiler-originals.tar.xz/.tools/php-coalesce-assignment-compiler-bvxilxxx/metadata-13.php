<?php $n="this";
${"".
$n} ??=
7;