<?php echo "A";echo ${
[]
};echo "B";