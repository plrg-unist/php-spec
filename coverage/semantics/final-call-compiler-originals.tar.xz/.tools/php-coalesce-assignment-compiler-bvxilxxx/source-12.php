<?php echo "A";echo ${
NAN
};echo "B";