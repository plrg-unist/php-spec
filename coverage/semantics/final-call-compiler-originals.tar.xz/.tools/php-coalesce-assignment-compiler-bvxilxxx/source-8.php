<?php echo "A";unset(${
[1]
});echo "B";