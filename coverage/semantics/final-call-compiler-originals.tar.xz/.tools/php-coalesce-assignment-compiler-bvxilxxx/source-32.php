<?php echo "A";unset(${
(list($x)=[[1]])
});echo "B";