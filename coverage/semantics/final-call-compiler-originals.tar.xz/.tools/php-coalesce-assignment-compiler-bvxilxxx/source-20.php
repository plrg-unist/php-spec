<?php echo "A";unset(${
INF
});echo "B";