<?php echo "A";${
INF
}??=7;echo "B";