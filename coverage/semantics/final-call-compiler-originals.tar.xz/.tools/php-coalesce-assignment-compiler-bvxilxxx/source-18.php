<?php echo "A";echo ${
INF
};echo "B";