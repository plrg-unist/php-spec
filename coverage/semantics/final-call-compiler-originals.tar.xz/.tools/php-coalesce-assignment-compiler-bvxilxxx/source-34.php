<?php echo "A";${
(list($x)=[[1]])
}??=7;echo "B";