<?php echo "A";echo ${
INF
}??7;echo "B";