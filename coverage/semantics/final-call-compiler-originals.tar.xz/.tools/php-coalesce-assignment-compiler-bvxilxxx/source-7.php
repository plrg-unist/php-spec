<?php echo "A";${
[1]
}=7;echo "B";