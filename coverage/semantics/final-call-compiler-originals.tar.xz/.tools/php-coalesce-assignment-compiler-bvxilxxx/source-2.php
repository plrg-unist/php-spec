<?php echo "A";unset(${
[]
});echo "B";