<?php echo "A";${
NAN
}??=7;echo "B";