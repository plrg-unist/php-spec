<?php echo "A";$r=&${
[]
};echo "B";