<?php $a[
$k] ??=
$http_response_header;echo $http_response_header;