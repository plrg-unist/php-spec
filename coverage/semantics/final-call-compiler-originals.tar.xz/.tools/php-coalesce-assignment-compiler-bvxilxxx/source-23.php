<?php echo "A";$r=&${
INF
};echo "B";