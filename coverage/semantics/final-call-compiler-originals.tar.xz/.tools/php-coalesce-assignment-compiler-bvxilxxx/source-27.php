<?php echo "A";echo ${
(list($x)=[1])
}??7;echo "B";