<?php echo "A";$r=&${
NAN
};echo "B";