<?php $a=false;
$a[1.2+
0] ??=
7;