<?php echo "A";echo ${
NAN
}??7;echo "B";