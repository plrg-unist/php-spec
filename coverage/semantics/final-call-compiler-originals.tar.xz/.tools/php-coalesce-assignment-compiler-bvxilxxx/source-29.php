<?php echo "A";$r=&${
(list($x)=[1])
};echo "B";