<?php echo "A";echo ${
[]
}??7;echo "B";