<?php echo "A";unset(${
NAN
});echo "B";