<?php $a=true;
$a[1.2+
0] ??=
7;