<?php echo "A";echo ${
[1]
}??7;echo "B";