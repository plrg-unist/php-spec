<?php $n="GLOBALS";
${"".
$n} ??=
7;