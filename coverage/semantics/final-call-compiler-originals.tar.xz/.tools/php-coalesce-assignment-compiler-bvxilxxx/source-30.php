<?php echo "A";echo ${
(list($x)=[[1]])
};echo "B";