<?php $a=null;
$a[1.2+
0] ??=
7;