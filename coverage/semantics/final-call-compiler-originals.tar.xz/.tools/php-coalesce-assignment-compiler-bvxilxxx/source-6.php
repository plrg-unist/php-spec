<?php echo "A";echo ${
[1]
};echo "B";