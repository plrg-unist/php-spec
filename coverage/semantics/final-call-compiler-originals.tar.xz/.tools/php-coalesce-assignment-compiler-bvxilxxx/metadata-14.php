<?php $n="this";
${(string)
$n} ??=
7;