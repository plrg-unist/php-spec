<?php function f($x){}f(
$GLOBALS=1
);