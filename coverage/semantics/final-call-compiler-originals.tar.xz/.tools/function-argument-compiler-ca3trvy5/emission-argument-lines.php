<?php function f($x){}f(
1/0
);