<?php function f($x,$y){}f(
7
);