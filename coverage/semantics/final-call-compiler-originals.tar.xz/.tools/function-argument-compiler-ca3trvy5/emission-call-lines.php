<?php function f($x){1/0;}f(
7
);