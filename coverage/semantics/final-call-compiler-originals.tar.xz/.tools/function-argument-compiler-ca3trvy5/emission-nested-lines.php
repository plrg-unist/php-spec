<?php function f($x){1/0;}function g(){return 7;}f(
g()
);