<?php function f($x){}f(
$http_response_header
);echo $http_response_header;