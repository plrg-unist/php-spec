<?php echo "A";echo $GLOBALS[
1.2
]??7;echo "B";