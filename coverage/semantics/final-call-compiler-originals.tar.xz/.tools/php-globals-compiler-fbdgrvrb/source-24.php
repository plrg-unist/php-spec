<?php echo "A";echo $GLOBALS[
(list($x)=[1])
];echo "B";