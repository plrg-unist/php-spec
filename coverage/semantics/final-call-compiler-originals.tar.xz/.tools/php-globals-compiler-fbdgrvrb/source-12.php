<?php echo "A";echo $GLOBALS[
NAN
];echo "B";