<?php 
unset(
${"GLO"."BALS"}
);