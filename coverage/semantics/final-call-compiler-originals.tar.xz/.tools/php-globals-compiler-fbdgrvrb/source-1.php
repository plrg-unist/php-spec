<?php echo "A";$GLOBALS[
[]
]=7;echo "B";