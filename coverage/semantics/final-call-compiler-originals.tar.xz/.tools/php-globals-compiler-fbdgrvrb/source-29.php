<?php echo "A";$r=&$GLOBALS[
(list($x)=[1])
];echo "B";