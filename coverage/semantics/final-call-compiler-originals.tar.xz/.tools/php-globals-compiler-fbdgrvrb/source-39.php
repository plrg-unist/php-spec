<?php echo "A";echo $GLOBALS[
null
]??7;echo "B";