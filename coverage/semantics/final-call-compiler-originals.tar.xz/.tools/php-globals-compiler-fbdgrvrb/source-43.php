<?php echo "A";$GLOBALS[
1.2
]=7;echo "B";