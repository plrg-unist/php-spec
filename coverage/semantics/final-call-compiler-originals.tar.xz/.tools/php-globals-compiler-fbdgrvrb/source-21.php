<?php echo "A";echo $GLOBALS[
INF
]??7;echo "B";