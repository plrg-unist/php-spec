<?php echo "A";unset($GLOBALS[
1.2
]);echo "B";