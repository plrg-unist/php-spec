<?php echo "A";echo $GLOBALS[
"http_response_header"
];echo "B";