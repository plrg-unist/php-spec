<?php echo "A";echo $GLOBALS[
INF
];echo "B";