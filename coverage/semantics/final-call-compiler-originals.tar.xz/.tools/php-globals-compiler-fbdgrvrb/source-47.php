<?php echo "A";$r=&$GLOBALS[
1.2
];echo "B";