<?php echo "A";$GLOBALS[
"http_response_header"
]??=7;echo "B";