<?php echo "A";$r=&$GLOBALS[
null
];echo "B";