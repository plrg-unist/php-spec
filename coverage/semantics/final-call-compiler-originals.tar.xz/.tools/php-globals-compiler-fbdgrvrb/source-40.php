<?php echo "A";$GLOBALS[
null
]??=7;echo "B";