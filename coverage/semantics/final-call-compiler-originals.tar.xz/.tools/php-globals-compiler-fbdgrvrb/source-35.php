<?php echo "A";$r=&$GLOBALS[
"http_response_header"
];echo "B";