<?php echo "A";$r=&$GLOBALS[
[1]
];echo "B";