<?php echo "A";$GLOBALS[
NAN
]??=7;echo "B";