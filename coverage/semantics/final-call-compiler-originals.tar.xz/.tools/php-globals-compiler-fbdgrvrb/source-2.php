<?php echo "A";unset($GLOBALS[
[]
]);echo "B";