<?php echo "A";$r=&$GLOBALS[
[]
];echo "B";