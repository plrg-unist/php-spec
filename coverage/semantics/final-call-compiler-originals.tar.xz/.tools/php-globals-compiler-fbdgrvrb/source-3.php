<?php echo "A";echo $GLOBALS[
[]
]??7;echo "B";