<?php echo "A";echo $GLOBALS[
[]
];echo "B";