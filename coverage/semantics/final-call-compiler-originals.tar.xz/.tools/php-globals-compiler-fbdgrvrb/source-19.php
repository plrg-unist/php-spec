<?php echo "A";$GLOBALS[
INF
]=7;echo "B";