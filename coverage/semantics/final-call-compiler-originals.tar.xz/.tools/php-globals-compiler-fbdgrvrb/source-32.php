<?php echo "A";unset($GLOBALS[
"http_response_header"
]);echo "B";