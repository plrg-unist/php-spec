<?php echo "A";echo $GLOBALS[
NAN
]??7;echo "B";