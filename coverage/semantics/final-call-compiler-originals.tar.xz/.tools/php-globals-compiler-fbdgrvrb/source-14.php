<?php echo "A";unset($GLOBALS[
NAN
]);echo "B";