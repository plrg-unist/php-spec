<?php echo "A";unset($GLOBALS[
[1]
]);echo "B";