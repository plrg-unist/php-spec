<?php echo "A";echo $GLOBALS[
[1]
];echo "B";