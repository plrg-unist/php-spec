<?php echo "A";echo $GLOBALS[
1.2
];echo "B";