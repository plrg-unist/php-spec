<?php echo "A";$r=&$GLOBALS[
INF
];echo "B";