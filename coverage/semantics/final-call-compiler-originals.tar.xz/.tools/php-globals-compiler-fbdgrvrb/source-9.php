<?php echo "A";echo $GLOBALS[
[1]
]??7;echo "B";