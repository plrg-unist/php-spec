<?php echo "A";$GLOBALS[
[1]
]??=7;echo "B";