<?php echo "A";echo $GLOBALS[
null
];echo "B";