<?php echo "A";$GLOBALS[
(list($x)=[1])
]=7;echo "B";