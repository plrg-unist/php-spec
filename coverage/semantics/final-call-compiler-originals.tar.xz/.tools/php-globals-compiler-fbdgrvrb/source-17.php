<?php echo "A";$r=&$GLOBALS[
NAN
];echo "B";