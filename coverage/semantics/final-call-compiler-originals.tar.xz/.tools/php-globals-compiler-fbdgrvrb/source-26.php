<?php echo "A";unset($GLOBALS[
(list($x)=[1])
]);echo "B";