<?php 
$x
=&
${"GLO"."BALS"};