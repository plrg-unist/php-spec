<?php echo "A";unset($GLOBALS[
null
]);echo "B";