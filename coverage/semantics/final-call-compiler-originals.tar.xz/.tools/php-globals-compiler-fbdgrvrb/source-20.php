<?php echo "A";unset($GLOBALS[
INF
]);echo "B";