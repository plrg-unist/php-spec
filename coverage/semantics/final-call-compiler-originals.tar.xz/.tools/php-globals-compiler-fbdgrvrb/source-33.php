<?php echo "A";echo $GLOBALS[
"http_response_header"
]??7;echo "B";