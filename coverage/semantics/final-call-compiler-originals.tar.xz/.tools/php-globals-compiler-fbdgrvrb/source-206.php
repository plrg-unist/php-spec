<?php 
${"GLO"."BALS"}
=
1;