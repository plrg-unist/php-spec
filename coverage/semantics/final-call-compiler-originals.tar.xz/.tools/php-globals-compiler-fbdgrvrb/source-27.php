<?php echo "A";echo $GLOBALS[
(list($x)=[1])
]??7;echo "B";