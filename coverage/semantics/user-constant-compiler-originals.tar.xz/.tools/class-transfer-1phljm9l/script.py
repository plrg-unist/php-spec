from pathlib import Path
import hashlib,json,subprocess,tempfile
r=Path(__file__).resolve().parent;o=Path(tempfile.mkdtemp(prefix='class-transfer-',dir=r/'.tools'));print(o,flush=True)
a=[
'$pvclass_operand(PARRAY 42) = eps',
'$pvclass_string((PINT 9), PVSCALAR)',
'~$pvclass_string((PINT 10), PVSCALAR)',
'~$pvclass_string((PFLOAT 0), PVSCALAR)',
'$pvclass_string(eps, PVARRAY false eps)',
'$pvclass_concat((PSTRING eps), PVSTRING false, (PSTRING eps), PVSTRING true) = PVSTRING true',
'$pvclass_concat((PSTRING eps), PVSTRING true, (PSTRING eps), PVSTRING false) = PVSTRING false',
'$pvclass_concat((PSTRING ([97])), PVSTRING true, (PSTRING ([98])), PVSTRING true) = PVSTRING false',
'$pvclass_binary(BITAND, (PSTRING ([97])), PVSTRING false, (PSTRING ([98])), PVSTRING false) = PVSTRING true',
'$pvclass_binary(BITAND, (PSTRING ([97])), PVSTRING true, (PSTRING ([98,99])), PVSTRING true) = PVSTRING false',
'$pvclass_binary(BITOR, (PSTRING eps), PVSTRING true, (PSTRING eps), PVSTRING true) = PVSTRING false',
'$pvclass_binary(BITXOR, (PSTRING ([97])), PVSTRING false, (PSTRING ([98])), PVSTRING false) = PVSTRING true',
'$pvclass_bitnot((PSTRING eps)) = PVSTRING false',
'$pvclass_bitnot((PSTRING ([97]))) = PVSTRING true',
'$pvclass_cast(PVFOLD, CASTARRAY, (PNULL), PVSCALAR) = PVARRAY false eps',
'$pvclass_cast(PVEXEC, CASTARRAY, (PNULL), PVSCALAR) = PVARRAY true eps',
'$pvclass_cast(PVEXEC, CASTARRAY, eps, PVARRAY true eps) = PVARRAY true eps',
'$pvclass_cast(PVFOLD, CASTSTRING, (PSTRING ([97])), PVSTRING false) = PVSTRING false',
'$pvclass_union(PVARRAY true eps, PVARRAY true eps) = PVARRAY false eps',
'$pvclass_get($pvclass_put(PVARRAY true eps, KINT 0, PVSTRING false), KINT 0) = (PVSTRING false)',
'$pvclass_get($pvclass_union(PVARRAY false ([(KINT 0, PVSTRING true)]), PVARRAY false ([(KINT 0, PVSTRING false)])), KINT 0) = (PVSTRING true)',
'$pvclass_intern(PVSTRING false) = PVSTRING true',
'$pvclass_intern(PVARRAY false ([(KINT 0, PVSTRING false)])) = PVARRAY false ([(KINT 0, PVSTRING false)])']
f=o/'transfer.watsup';f.write_text('dec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+x+'\n' for x in a))
modules=[r/p for p in json.loads((r/'spec/semantics/modules.json').read_text())];runner=r/'tests/semantics/_build/default/numeric_runner.exe';watched=[*modules,runner,Path(__file__)];h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before={str(p.relative_to(r)):h(p) for p in watched};(o/'inputs.json').write_text(json.dumps(before,indent=2));(o/'script.py').write_bytes(Path(__file__).read_bytes());cmd=[str(runner),*map(str,modules),str(f)];(o/'command.json').write_text(json.dumps(cmd))
try:p=subprocess.run(cmd,capture_output=True,timeout=30)
except subprocess.TimeoutExpired as e:
 (o/'stdout').write_bytes(e.stdout or b'');(o/'stderr').write_bytes(e.stderr or b'');(o/'status.json').write_text(json.dumps({'status':'timeout'}));raise
(o/'stdout').write_bytes(p.stdout);(o/'stderr').write_bytes(p.stderr);(o/'status.json').write_text(json.dumps({'status':'exit','exit_status':p.returncode}));assert before=={str(p.relative_to(r)):h(p) for p in watched};assert p.returncode==0 and p.stdout.strip()==b'true' and not p.stderr,p.stderr
print(len(a),'source-backed class transfer assertions pass; no source execution or allocation observation claim')
