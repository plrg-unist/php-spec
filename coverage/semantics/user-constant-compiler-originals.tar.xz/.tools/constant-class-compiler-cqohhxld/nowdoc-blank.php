<?php const C=<<<'E'

E;