<?php const C=<<<E
\x61
E;