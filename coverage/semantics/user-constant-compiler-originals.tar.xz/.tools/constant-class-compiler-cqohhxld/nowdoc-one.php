<?php const C=<<<'E'
a
E;