<?php const TRUE=
UNKNOWN;