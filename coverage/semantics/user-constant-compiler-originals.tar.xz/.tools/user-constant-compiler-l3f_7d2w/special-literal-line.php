<?php const TRUE=
1;