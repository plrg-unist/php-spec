<?php const TRUE=
1+2;