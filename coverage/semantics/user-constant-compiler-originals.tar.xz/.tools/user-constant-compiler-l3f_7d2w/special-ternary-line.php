<?php const TRUE=
true ?
1 :
2;