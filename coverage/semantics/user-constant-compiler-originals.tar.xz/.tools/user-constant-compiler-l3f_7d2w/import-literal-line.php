<?php namespace N;use const A\C;const C=
1;