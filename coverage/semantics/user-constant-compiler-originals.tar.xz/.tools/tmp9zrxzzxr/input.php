<?php $u=7;$v=9;
$result=[[
 $u[]=>
 "abc"["1x"]]];
function observe($v) { return match(gettype($v)) { 'NULL'=>['n'], 'boolean'=>['b',$v], 'integer'=>['i',(string)$v], 'double'=>['f',bin2hex(pack('E',$v))], 'string'=>['s',bin2hex($v)], 'array'=>['a',array_map(fn($k)=>[observe($k),observe($v[$k])],array_keys($v))] }; } echo json_encode(observe($result[0]));