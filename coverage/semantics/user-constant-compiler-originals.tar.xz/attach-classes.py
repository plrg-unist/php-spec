from pathlib import Path
r=Path(__file__).resolve().parent;s=r/'spec/semantics'
p=s/'45-constant-context.watsup';t=p.read_text()
t=t.replace('syntax pfstate = { CONSTANT bool,','syntax pfstate = { CLASSFACTS (pcpath, pvalueclass)*, CONSTANT bool,')
t=t.replace('{ CONSTANT false, FUNCTION','{ CLASSFACTS eps, CONSTANT false, FUNCTION')
t=t.replace('syntax pfitem = PFITEM pvalue? pfkey bool | PFSPREAD pvalue?','syntax pfitem = PFITEM pvalue? pfkey bool pvalueclass? | PFSPREAD pvalue? pvalueclass?')
t=t.replace('syntax pfbuild = PFBUILT pstate |','syntax pfbuild = PFBUILT pstate pvalueclass? |')
t=t.replace('$pftracked($pfcontextualize(F, pcpath), pcpath, expression, z)','$pfclass_finish($pftracked($pfcontextualize(F, pcpath), pcpath, expression, z), pcpath, expression)')
t=t.replace('($pfkey(phpType5, F_key.VALUE)) b]', '($pfkey(phpType5, F_key.VALUE)) b ($pfclass_at(F_value.CLASSFACTS, pcpath_item ++ [PCFIELD 1]))]')
t=t.replace('[PFSPREAD F_value.VALUE]', '[PFSPREAD F_value.VALUE ($pfclass_at(F_value.CLASSFACTS, pcpath ++ [PCFIELD 0, PCINDEX n, PCFIELD 1]))]')
t=t.replace('(PFITEM (pvalue) PFNO_KEY false)', '(PFITEM (pvalue) PFNO_KEY false pvalueclass?)').replace('(PFITEM (pvalue) (PFKEY (pvalue_key)) false)', '(PFITEM (pvalue) (PFKEY (pvalue_key)) false pvalueclass?)').replace('(PFSPREAD (pvalue))', '(PFSPREAD (pvalue) pvalueclass?)')
t=t.replace('dec $pfconstruct(pstate, nat, pfitem*, int)', 'dec $pfconstruct(pstate, nat, pfitem*, int, pvalueclass?)')
t=t.replace('dec $pfconstructkey(pstate, nat, pvalue, pfkey, pfitem*, int)', 'dec $pfconstructkey(pstate, nat, pvalue, pfkey, pfitem*, int, pvalueclass?, pvalueclass?)')
t=t.replace('dec $pfinsert(pstate, nat, pkey?, pvalue, pfitem*, int)', 'dec $pfinsert(pstate, nat, pkey?, pvalue, pfitem*, int, pvalueclass?, pvalueclass?)')
t=t.replace('dec $pfinserted(pstate, nat, pfitem*, int)', 'dec $pfinserted(pstate, nat, pfitem*, int, pvalueclass?)')
a=t.index('def $pfarray(F, pcpath, pfitem*, z) = $pfbuilt');b=t.index('def $pfbuilt(F, pcpath, PFDEFER',a)
t=t[:a]+'''def $pfarray(F, pcpath, pfitem*, z) = $pfbuilt(F, pcpath, $pfconstruct(S, n, pfitem*, z, $pfclass_array_start(F.CONSTANT, pfitem* = eps)), n, z)
  -- if $pfready(pfitem*)
  -- if S = $allocate_array(F.MEMORY, $array_empty())
  -- if S.RESULT = KNOWN (PARRAY n)
def $pfconstruct(S, n, eps, z, pvalueclass?) = PFBUILT S pvalueclass?
def $pfconstruct(S, n, (PFITEM (pvalue) pfkey false pvalueclass_item?) :: pfitem*, z, pvalueclass?) = $pfconstructkey(S, n, pvalue, pfkey, pfitem*, z, pvalueclass?, pvalueclass_item?)
def $pfconstructkey(S, n, pvalue, PFNO_KEY, pfitem*, z, pvalueclass?, pvalueclass_item?) = $pfinsert(S, n, eps, pvalue, pfitem*, z, pvalueclass?, pvalueclass_item?)
def $pfconstructkey(S, n, pvalue, PFKEY (PARRAY n_key), pfitem*, z, pvalueclass?, pvalueclass_item?) = PFSTATIC "Illegal offset type"
def $pfconstructkey(S, n, pvalue, PFKEY (pvalue_key), pfitem*, z, pvalueclass?, pvalueclass_item?) = $pfinsert(S_key, n, (S_key.KEY), pvalue, pfitem*, z, pvalueclass?, pvalueclass_item?)
  -- if $constant_state($key_value(S, pvalue_key, false, z)) = (S_key)
def $pfconstructkey(S, n, pvalue, pfkey, pfitem*, z, pvalueclass?, pvalueclass_item?) = PFDEFER
  -- otherwise
def $pfinsert(S, n, pkey?, pvalue, pfitem*, z, pvalueclass?, pvalueclass_item?) = $pfinserted($literal_insert(S, n, pkey?, pvalue, z), n, pfitem*, z, $pfclass_insert(pvalueclass?, S.ARRAYS[n].NEXT, pkey?, pvalueclass_item?))
def $pfinserted(S, n, pfitem*, z, pvalueclass?) = $pfconstruct(S, n, pfitem*, z, pvalueclass?)
  -- if S.COMPLETION = NORMAL
  -- if S.EVENTS = eps
def $pfinserted(S, n, pfitem*, z, pvalueclass?) = PFDEFER
  -- otherwise
def $pfbuilt(F, pcpath, PFBUILT S pvalueclass?, n, z) = $pfclass_record($pfremember(F[.MEMORY = S], pcpath, (PARRAY n), z), pcpath, pvalueclass?)
''' + t[b:]
t=t.replace('def $pfconstruct(S, n, (PFSPREAD (PARRAY n_source)) :: pfitem*, z) = $pfinserted($array_unpack(S, n, PARRAY n_source, z), n, pfitem*, z)', 'def $pfconstruct(S, n, (PFSPREAD (PARRAY n_source) pvalueclass_source?) :: pfitem*, z, pvalueclass?) = $pfinserted($array_unpack(S, n, PARRAY n_source, z), n, pfitem*, z, $pfclass_spread(pvalueclass?, S.ARRAYS[n].NEXT, pvalueclass_source?))')
t=t.replace('def $pfconstruct(S, n, (PFSPREAD (pvalue) pvalueclass?) :: pfitem*, z)', 'def $pfconstruct(S, n, (PFSPREAD (pvalue) pvalueclass_source?) :: pfitem*, z, pvalueclass?)')
p.write_text(t)
