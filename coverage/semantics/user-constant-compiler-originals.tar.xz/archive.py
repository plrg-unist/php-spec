from pathlib import Path
import hashlib,io,json,tarfile
D=Path(__file__).resolve().parent;B=D.parent/'compiler5-user-constants';O=D.parent/'compiler5-user-constant-originals'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((D/'final-inputs.json').read_text());b=json.loads((B/'final-inputs.json').read_text());assert all(digest(D/p)==h for p,h in m['files'].items());assert all(digest(B/p)==h for p,h in b['files'].items())
files={p:D/p for p in m['files']};files.update({'baseline887/'+p:B/p for p in b['files']})
extras=['archive.py','attach-classes.py','class-facts.fragment','make-class-check.py','baseline-inputs.json','final-inputs.json','class-compiler-delta.json','semantics-reference-inputs.json','allocation-source-inputs.json','shared-transfer-inputs.json','check-transfers.py','historical-input-audit.json','focused-regression.py','docs/semantics/USER-CONSTANT-COMPILER.md','docs/semantics/CONSTANT-VALUE-CLASSES.md','coverage/semantics/user-constant-compiler.json','coverage/semantics/constant-class-compiler.json','coverage/semantics/constant-context.json','coverage/semantics/source-context.json','coverage/semantics/magic-constants-compiler.json']
for p in extras:
 assert (D/p).is_file(),p;files[p]=D/p
for p in ['baseline-inputs.json','first37-inputs.json','final-inputs.json','constant-compiler-delta.json','semantics-reference-inputs.json','prepare-compiler.py','focused-regression.py','coverage/semantics/user-constant-compiler.json','coverage/semantics/constant-context.json','coverage/semantics/source-context.json','coverage/semantics/magic-constants-compiler.json']:
 assert (B/p).is_file(),p;files['baseline887/'+p]=B/p
for root,prefix in [(D/'.tools','.tools'),(D/'before-compiler','before-compiler'),(D/'historical-reconstructed','historical-reconstructed'),(B/'.tools','baseline887/.tools'),(B/'before-compiler','baseline887/before-compiler'),(O,'originals')]:
 for p in root.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files[str(Path(prefix)/p.relative_to(root))]=p
for r,prefix in [(D,''),(B,'baseline887/')]:
 for rel,h in json.loads((r/'semantics-reference-inputs.json').read_text())['references'].items():assert digest(r/rel)==h;files[prefix+rel]=r/rel
for rel,h in json.loads((D/'allocation-source-inputs.json').read_text()).items():assert digest(D/rel)==h;files[rel]=D/rel
tools={p:digest(f) for p,f in files.items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p in tools:files.pop(p)
hashes={p:digest(f) for p,f in files.items()};out=D/'coverage/semantics/user-constant-compiler-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'tools':tools,'source_inputs':m,'historical_source_inputs':b},indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
 for p,f in sorted(files.items()):
  h=hashes[p];info=t.gettarinfo(str(f),arcname=p)
  if h in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;t.addfile(info)
  else:
   seen[h]=p
   with f.open('rb') as stream:t.addfile(info,stream)
with tarfile.open(out,'r:xz') as t:
 for p,h in hashes.items():assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==h,p
report={'scope':'Private compiler88 user-constant declaration prerequisite and source-backed allocation class facts; no runtime/default admission or native allocation equivalence claim.','archive':str(out.relative_to(D)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':tools,'candidate':m['fingerprint'],'baseline':b['fingerprint'],'original_sources':{'initial37':'originals/.tools/send-kind-originals-pi2zdqs7','line6':'originals/lines/.tools/send-kind-originals-xpgc3zfn','old_states':'Initial37 against frozen runtime882; line6 against retained compiler first37; historical identities unchanged.'},'final_compiler':{'phases':45,'pending':10,'descriptors':29,'raw':'.tools/user-constant-compiler-pa7tj6lg'},'class_compiler':{'phases':40,'descriptors':120,'raw':'.tools/constant-class-compiler-serbij9q','scope':'Source-backed descriptor expectations, not native allocation or default execution observations.'},'focused':{'constant_context':'.tools/constant_context-regression-z92s7srx','source_context':'.tools/source_context-regression-xtn2jfvc','magic':'.tools/magic_constants_compiler-regression-m57qkf4h'},'failures':['baseline887/.tools/constant-first-load','baseline887/.tools/user-constant-compiler-i4y1k8wh','baseline887/.tools/user-constant-compiler-e1n691jt','.tools/class-transfer-1phljm9l','.tools/class-transfer-z60_p5tg','.tools/class-transfer-do_4c0ft','.tools/class-transfer-bbvem4x_','.tools/constant-class-compiler-w2s27nao'],'reconstruction':'baseline887/.tools/first37-reconstructed and historical-reconstructed contain explicitly labelled reconstructed byte-identical old input versions; historical-input-audit.json finds all98 retained module hashes in exact available payloads. Unmatched derivation variants are not asserted as old inputs.','transport':'Worker records are decoded JSON responses, not exact wire or separately captured worker stderr. Native/SpecTec subprocess bytes/status and timeout partials are retained.','independent_boundary_originals':'See canonical coverage/semantics/constant-review-diagnosis.json; reviewer owns its durable native/old887 boundary evidence.'}
(D/'coverage/semantics/user-constant-compiler-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert all(digest(D/p)==h for p,h in m['files'].items())
