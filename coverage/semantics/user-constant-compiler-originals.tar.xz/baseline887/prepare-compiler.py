from pathlib import Path
import json,shutil
R=Path(__file__).resolve().parent
p=R/'spec/semantics/45-constant-context.watsup';shutil.copy2(p,R/'before-compiler'/p.name);s=p.read_text().replace('syntax pfstate = { FUNCTION','syntax pfstate = { CONSTANT bool, FUNCTION').replace('= { FUNCTION eps, SOURCE','= { CONSTANT false, FUNCTION eps, SOURCE').replace('def $pfdispatch(F, pcpath, PFOTHER, z) = $pfunsupported(F, "constant-expression kind")','def $pfdispatch(F, pcpath, PFOTHER, z) = $pfunsupported(F, "constant-expression kind")\n  -- if ~F.CONSTANT\ndef $pfdispatch(F, pcpath, PFOTHER, z) = F[.VALUE = eps]\n  -- if F.CONSTANT');p.write_text(s)
s=(R.parent/'compiler5-default-compiler/spec/semantics/88-parameter-defaults.watsup').read_text();a=s.index('def $ppdefault_validate(');b=s.index('def $ppdefault_kind(',a);s=s[a:b].replace('$ppdefault_','$ppconstant_').replace('NExprFuncCall phpType28','NExprFuncCall phpType19').replace('phpType16 phpType45 phpType18','phpType16 phpType21 phpType18').replace('parameter default','constant initializer')
prefix=''';; User constants compile their initializer before declaration-name checks.
;; Constant AST validation follows existing45 folding and its original redirects.
dec $ppconstant_validate(ppstate, pcpath, pcnode) : ppstate
dec $ppconstant_node(ppstate, pcpath, pcnode) : ppstate
dec $ppconstant_children(ppstate, pcoccurrence*) : ppstate
dec $ppconstant_allowed(pcnode) : bool
dec $ppconstant_shape(pfshape) : bool
dec $ppconstant_expr(ppstate, pcpath, expression) : ppstate
dec $ppconstant_list(ppstate, pcpath, nat, phpType46*) : ppstate
dec $ppconstant_name(ppstate, pcpath, phpType11) : ppstate
dec $ppconstant_record(ppstate, pcpath, text, metadata) : ppstate

def $ppstatement(P, pcpath, NStmtConst (SEQUENCE eps) (SEQUENCE phpType46*) metadata) = $ppconstant_list($pplocate(P, pcpath, $source_line(metadata)), pcpath ++ [PCFIELD 1], 0, phpType46*)
  -- if P.COMPLETION = PPCNORMAL

def $ppconstant_list(P, pcpath, n, phpType46*) = P
  -- if P.COMPLETION =/= PPCNORMAL
def $ppconstant_list(P, pcpath, n, eps) = P
  -- if P.COMPLETION = PPCNORMAL
def $ppconstant_list(P, pcpath, n, (NConst phpType11 expression metadata) :: phpType46*) = $ppconstant_list($ppconstant_name($ppconstant_expr(P, pcpath ++ [PCINDEX n, PCFIELD 1], expression), pcpath ++ [PCINDEX n], phpType11), pcpath, $(n + 1), phpType46*)
  -- if P.COMPLETION = PPCNORMAL

def $ppconstant_expr(P, pcpath, expression) = $ppexpr($ppconstant_validate($ppfoldresult(P, $pfprepare(P.FOLD[.CONSTANT = true], pcpath, expression, P.ENV, P.LOCATION.LINE)), pcpath, expression), pcpath, expression, PPR)[.FOLD.CONSTANT = false]

def $ppconstant_name(P, pcpath, phpType11) = P
  -- if P.COMPLETION =/= PPCNORMAL
def $ppconstant_name(P, pcpath, NIdentifier (BYTES text) metadata) = $ppcheck(P, $context_error_bytes($ptascii("Cannot redeclare constant '") ++ $base64(text) ++ $ptascii("'"), P.LOCATION.LINE))
  -- if P.COMPLETION = PPCNORMAL
  -- if $special_constant($base64(text)) = (pvalue)
def $ppconstant_name(P, pcpath, NIdentifier (BYTES text) metadata) = $ppcheck(P, $context_error_bytes($ptascii("Cannot declare const ") ++ $ptjoin(P.ENV.NAMESPACE, $base64(text)) ++ $ptascii(" because the name is already in use"), P.LOCATION.LINE))
  -- if P.COMPLETION = PPCNORMAL
  -- if $special_constant($base64(text)) = eps
  -- if $pllookup(P.ENV.CONSTANTS, $base64(text)) = ptbytes_import
  -- if ptbytes_import =/= eps /\\ ptbytes_import =/= $ptjoin(P.ENV.NAMESPACE, $base64(text))
def $ppconstant_name(P, pcpath, NIdentifier (BYTES text) metadata) = $ppconstant_record(P, pcpath, text, metadata)
  -- if P.COMPLETION = PPCNORMAL
  -- if $special_constant($base64(text)) = eps
  -- if $pllookup(P.ENV.CONSTANTS, $base64(text)) = eps \\/ $pllookup(P.ENV.CONSTANTS, $base64(text)) = $ptjoin(P.ENV.NAMESPACE, $base64(text))
def $ppconstant_name(P, pcpath, phpType11) = $ppunsupported(P, "edited constant declaration name")
  -- otherwise

def $ppconstant_record(P, pcpath, text, metadata) = P[.NAMES = P.NAMES ++ [(pcpath, { ORIGINAL NName (BYTES text) metadata, KIND PLCONSTANT, RESOLVED ptbytes, FULL true, FALLBACK eps })]][.ENV = P.ENV[.SEEN = P.ENV.SEEN ++ [(PLCONSTANT, ptbytes)]]]
  -- if ptbytes = $ptjoin(P.ENV.NAMESPACE, $base64(text))

'''
# Match existing byte-error interface directly, without introducing another renderer.
prefix=prefix.replace('$ppcheck(P, $context_error_bytes(', '$ppconstant_error(P, ').replace('P.LOCATION.LINE))','P.LOCATION.LINE)')
# The replacement above only touches the two byte-message clauses.
prefix=prefix.replace('dec $ppconstant_record(', 'dec $ppconstant_error(ppstate, ptbytes, nat) : ppstate\ndef $ppconstant_error(P, ptbytes, n) = P[.COMPLETION = PPCABRUPT (STATICBYTES ptbytes n)]\n\ndec $ppconstant_record(')
(R/'spec/semantics/88-user-constant-compiler.watsup').write_text(prefix+s)
p=R/'spec/semantics/modules.json';m=json.loads(p.read_text());m.append('spec/semantics/88-user-constant-compiler.watsup');p.write_text(json.dumps(m,indent=2)+'\n')
