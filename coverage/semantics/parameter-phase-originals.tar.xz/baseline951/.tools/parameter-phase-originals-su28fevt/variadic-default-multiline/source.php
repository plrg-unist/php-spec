<?php
function f(
 int ...$xs =
 UNKNOWN
) {}