from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,tempfile
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'));import function_scope as fs
from recorded_worker import Worker
CASES={
 'variadic-default-literal':'<?php function f(...$xs=1){}',
 'variadic-default-constant':'<?php function f(int ...$xs=UNKNOWN){}',
 'variadic-default-multiline':'<?php\nfunction f(\n int ...$xs =\n UNKNOWN\n) {}',
 'variadic-default-before-body':'<?php function f(...$xs=1){$GLOBALS=1;}',
 'variadic-default-before-later-void':'<?php function f(...$xs=1,void $y){}',
 'variadic-default-before-same-void':'<?php function f(void ...$xs=UNKNOWN){}',
 'variadic-last-before-void':'<?php function f(...$xs,void $y){}',
 'redefined-before-void':'<?php function f($x,void $x){}',
 'void-plain':'<?php function f(void $x){}',
 'void-multiline':'<?php\nfunction f(\n void\n $x\n) {}',
 'void-before-later-variadic-default':'<?php function f(void $x,...$xs=1){}',
 'bad-default-before-variadic-default':'<?php function f(int $x="bad",...$xs=1){}',
 'valid-parameter-control':'<?php function f(int $x=1){echo $x;}f();',
 'valid-variadic-boundary':'<?php function f(...$xs){}',
}
(D/'cases.json').write_text(json.dumps(CASES,indent=2)+'\n');out=Path(tempfile.mkdtemp(prefix='parameter-phase-originals-',dir=D/'.tools'));before=fs.q.t.syntax_validation.implementation_fingerprint();print(out,flush=True);(out/'inputs.json').write_text(json.dumps({'fingerprint':before,'producer_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()},indent=2))
f=Worker([str(fs.q.t.PHP),'-n',*fs.q.t.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')],out/'frontend-wire');a=Worker([str(D/'_build/default/adapter/main.exe'),str(D)],out/'adapter-wire');records=[]
try:
 for name,source in CASES.items():
  d=out/name;d.mkdir();p=d/'source.php';p.write_text(source);entries=[b'LC_ALL=C',b'TZ=UTC',b'FIRST=one'];payload=d/'request.input';payload.write_bytes(fs.q.packet(1700000000,125000,entries));request={'env':[[fs.q.b64(k),fs.q.b64(v)] for k,v in(e.split(b'=',1)for e in entries)],'argv':[fs.q.b64(os.fsencode(p))],'file':fs.q.b64(os.fsencode(p)),'seconds':'1700000000','microseconds':125000,'variables':fs.q.b64(b'EGPCS'),'jit':True,'cwd':fs.q.b64(os.fsencode(d))};(d/'request.json').write_text(json.dumps(request));native=fs.native(p,payload,d)
  cmd=[str(fs.q.t.PHP),'-n',*fs.q.t.FLAGS,'-l',str(p)];z=subprocess.run(cmd,capture_output=True,env=fs.q.t.ENV,timeout=10)
  for n,v in [('lint.stdout',z.stdout),('lint.stderr',z.stderr)]: (d/n).write_bytes(v)
  (d/'lint.command.json').write_text(json.dumps(cmd));(d/'lint.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}))
  encoded=fs.q.b64(p.read_bytes());oracle=f.request({'op':'oracle','source':encoded});(d/'oracle.json').write_text(json.dumps(oracle));assert oracle['accepted'];parsed=f.request({'op':'parse','source':encoded});(d/'parsed.json').write_text(json.dumps(parsed));actual={'status':'frontend_failure','frontend':parsed}
  if parsed.get('accepted'):
   execute={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':fs.q.b64(os.fsencode(p)),'request':request};(d/'execute.json').write_text(json.dumps(execute));res=a.request(execute);(d/'state.json').write_text(json.dumps(res));actual=fs.q.cli.observe(res['state'],str(p))
  records.append({'id':name,'source_base64':encoded,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'context':str(p),'request':request,'native':native,'oracle':oracle,'parsed':parsed,'actual':actual,'lint_exit':z.returncode});(out/'records.json').write_text(json.dumps(records,indent=2));print(name,actual['status'],flush=True)
finally:
 try:f.close()
 finally:a.close()
assert fs.q.t.syntax_validation.implementation_fingerprint()==before
(out/'report.json').write_text(json.dumps({'fingerprint':before,'scope':'Exact951 prior source/native/parser/lint observations for deferred parameter semantic checks. Frontend failure and valid variadic Unsupported boundary remain separate.','records':records},indent=2)+'\n')
