from pathlib import Path
import hashlib,json,stat,sys,tempfile
R=Path(__file__).resolve().parent;D=R/'candidate';B=R/'baseline951';sys.path.insert(0,str(D/'tests/semantics'));import function_scope as fs
from recorded_worker import Worker
N=B/'.tools/parameter-phase-originals-su28fevt';out=Path(tempfile.mkdtemp(prefix='replay-',dir=R));print(out,flush=True);m=json.loads((D/'baseline-inputs.json').read_text());m={'fingerprint':fs.q.t.syntax_validation.implementation_fingerprint(),'files':{n:hashlib.sha256((D/n).read_bytes()).hexdigest() for n in m['files']},'modes':{n:stat.S_IMODE((D/n).stat().st_mode) for n in m['files']}};(D/'first-inputs.json').write_text(json.dumps(m,indent=2)+'\n');(out/'inputs.json').write_text(json.dumps(m,indent=2)+'\n')
f=Worker([str(fs.q.t.PHP),'-n',*fs.q.t.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')],out/'frontend-wire');a=Worker([str(D/'_build/default/adapter/main.exe'),str(D)],out/'adapter-wire');rows=[]
try:
 for row in json.loads((N/'records.json').read_text()):
  p=Path(row['context']);d=out/row['id'];d.mkdir();parsed=f.request({'op':'parse','source':row['source_base64']});(d/'parsed.json').write_text(json.dumps(parsed));assert parsed['accepted'],parsed
  req={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':fs.q.b64(str(p).encode()),'request':row['request']};(d/'execute.json').write_text(json.dumps(req));res=a.request(req);(d/'state.json').write_text(json.dumps(res));actual=fs.q.cli.observe(res['state'],str(p));ok=actual['status'] in ['normal','php_error','static_rejection'] and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status']);item={'original':row,'actual':actual,'pass':ok};rows.append(item);(out/'records.json').write_text(json.dumps(rows,indent=2));print(row['id'],ok,actual['status'],flush=True)
finally:
 try:f.close()
 finally:a.close()
assert fs.q.t.syntax_validation.implementation_fingerprint()==m['fingerprint']
expected=[r for r in rows if r['original']['id']!='valid-variadic-boundary'];(out/'report.json').write_text(json.dumps({'result':'pass' if all(r['pass'] for r in expected) else 'fail','fingerprint':m['fingerprint'],'compared':len(expected),'boundaries':['valid-variadic-boundary'],'records':rows},indent=2)+'\n');assert all(r['pass'] for r in expected);assert rows[-1]['actual']['status']=='unsupported'
