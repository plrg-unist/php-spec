from pathlib import Path
import hashlib,io,json,lzma,stat,tarfile
R=Path(__file__).resolve().parent;B=R/'baseline951';C=R/'candidate';files={};modes={};bindings={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,p):
 m=stat.S_IMODE(p.stat().st_mode)
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  bindings[n]={'sha256':sha(p),'mode':m};return
 files[n]=p.read_bytes();modes[n]=m
def tree(n,p):
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':add(n+'/'+str(f.relative_to(p)),f)
a=json.loads((B/'baseline-inputs.json').read_text());c=json.loads((C/'first-inputs.json').read_text())
for label,root,m in [('baseline951',B,a),('candidate',C,c)]:
 for n,h in m['files'].items():assert sha(root/n)==h and stat.S_IMODE((root/n).stat().st_mode)==m['modes'][n],n
 tree(label,root)
for p in sorted(R.iterdir()):
 if p.is_dir() and p not in [B,C,R/'publication']:tree(p.name,p)
 elif p.is_file() and p.suffix in ['.py','.md','.json'] and p.name!='archive.json':add(p.name,p)
hashes={n:hashlib.sha256(v).hexdigest() for n,v in files.items()};out=R/'originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 raw=(json.dumps({'files':hashes,'modes':modes,'tools':bindings},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,raw in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(hashes[n],modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(raw);t.addfile(z,io.BytesIO(raw))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
changed=[n for n in a['files'] if a['files'][n]!=c['files'][n]];assert len(changed)==3 and a['modes']==c['modes']
report={'archive':'parameter-phase-originals.tar.xz','sha256':sha(out),'bytes':out.stat().st_size,'paths':len(files),'tools':bindings,'baseline':a['fingerprint'],'candidate':c['fingerprint'],'changed_watched_paths':changed,'all_shared_modes_equal':True,'gates':{'native_originals':14,'native_agreements':13,'explicit_variadic_boundary':1,'elaborated_roundtrips':14,'public_cli':14,'signature_comparisons':359,'descriptor_checks':28,'return_reference_checks':174,'reproduced_handwritten_files':5,'generated_parser_reproduction':'exact'},'scope':'Two eager parameter restrictions deferred to existing source static compilation. Named-function source priority only; no pending class/closure or variadic runtime activation. Full raw original requests, native/lint/parser outputs, checked worker streams/closures, public CLI streams and maintained signature subprocesses retained. Signature harness build request explicitly not run against exact accepted runner; reproducibility gate separately regenerated PHP8 parser. Large executable tools are bound by exact hash/mode, not copied into this archive.'}
(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
