from pathlib import Path
import hashlib,tarfile,json,stat,io
R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();files={};tools={}
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
for label,name in [('cache-return-context','review10-types-originals-brma4fpo'),('return-alias','review10-types-return-alias-originals-ixu_0zfk')]:
 d=R/'.tools'/name
 for p in d.rglob('*'):
  if p.is_file():add(label+'/'+str(p.relative_to(d)),p)
for n in ['review10-types-originals.py','review10-types-return-alias-originals.py','review10-archive-types-originals.py']:add('producers/'+n,R/'.tools'/n)
add('baseline917.json',R/'.tools/review10-strict-final/inputs.json');add('vendor/php-src/Zend/zend_execute.c',R/'vendor/php-src/Zend/zend_execute.c')
m={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools};a=R/'.tools/review10-types-originals.tar.xz';seen={}
with tarfile.open(a,'w:xz') as t:
 b=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(m['files'][n],m['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(a) as t:
 for n,h in m['files'].items():assert sha(t.extractfile(n).read())==h and t.getmember(n).mode==m['modes'][n]
r={'archive':str(a),'sha256':sha(a.read_bytes()),'paths':len(files),'bytes':a.stat().st_size,'baseline':json.load(open(R/'.tools/review10-strict-final/inputs.json'))['fingerprint'],'tools':tools,'scope':'Nine independent typed default-cache/return-owner/alias/mixed-strictness native and current917 source originals, all917Unsupported. Three ticks-block mixedstrictness cases retain a separate later-declare dependency. Exact source/request/native process and recordedworker packets/closures retained. Tools bound to accepted917; no current type semantics agreement.'};(R/'.tools/review10-types-originals-archive.json').write_text(json.dumps(r,indent=2));print(r['sha256'],r['paths'],r['bytes'])
