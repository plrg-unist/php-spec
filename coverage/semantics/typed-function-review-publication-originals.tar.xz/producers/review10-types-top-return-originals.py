from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={'untyped-top-level-return-projection':b'<?php echo 1; return 2;'}
if __name__=='__main__':scope.main(CASES,'review10-types-top-return-originals',Path(__file__))
