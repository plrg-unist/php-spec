from pathlib import Path
import json,hashlib,sys,tempfile,subprocess
R=Path.cwd();K=R/'.tools/review10-typed-compiler';sys.path.insert(0,str(K/'tests/semantics'));import static_types as t;import source_compiler as c
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-types-projection-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes());m=json.load(open(K/'inputs.json'));rows=json.load(open(R/'.tools/review10-types-originals-brma4fpo/report.json'))['records']+json.load(open(R/'.tools/review10-types-return-alias-originals-ixu_0zfk/report.json'))['records'];mods=[K/p for p in json.load(open(K/'spec/semantics/modules.json'))];runner=K/'tests/semantics/_build/default/numeric_runner.exe';(D/'inputs.json').write_text(json.dumps(m,indent=2));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();assert all(sha(K/p)==h for p,h in m['files'].items())
def walk(x,path=()):
 if isinstance(x,dict) and 'node' in x:
  yield x,path
  for i,f in enumerate(x['fields']):yield from walk(f,path+(('PCFIELD',i),))
 elif isinstance(x,list):
  for i,f in enumerate(x):yield from walk(f,path+(('PCINDEX',i),))
def pexpr(path):return '['+','.join(k+' '+str(i) for k,i in path)+']'
f=a=None;fixtures=[];records=[]
try:
 f=Worker([str(t.PHP),'-n',*t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire');a=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for i,row in enumerate(rows):
  d=D/row['id'];d.mkdir();(d/'original.json').write_text(json.dumps(row));parsed=f.request({'op':'parse','source':row['source_base64']});assert parsed['accepted'];checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(checked));checks=['P = $ppstart(91, '+checked['fixture']+', '+t.byte_expr(row['context'])+')']
  if row['id'].startswith('mixed-'):checks += ['P.COMPLETION = PPCABRUPT (UNSUPPORTED "other declare directive compilation")']
  else:
   checks+=['P.COMPLETION = PPCNORMAL','P.RETURNS = eps','P.FUNCTIONS = [pfunction]'];fn=[(n,p) for n,p in walk(parsed['ast']['program']) if n['node']=='Stmt_Function'];assert len(fn)==1;n,path=fn[0];checks+=['pfunction.ORIGIN = PORIGIN 91 ('+pexpr(path)+')','pfunction.ENDLINE = '+n['meta']['endLine']['int']]
   for node,root in walk(parsed['ast']['program']):
    if node['node']=='Stmt_Return':checks += ['$code_expression(pfunction.CODE.EXPRESSIONS, '+pexpr(root)+') = (('+node['meta']['startLine']['int']+', false))']
  fixtures.append('dec $case'+str(i)+'() : bool\ndef $case'+str(i)+'() = true\n'+''.join('  -- if '+x+'\n' for x in checks));records.append({'id':row['id'],'assertions':len(checks),'pending_other_directive':row['id'].startswith('mixed-')})
finally:
 try:
  if f:f.close()
 finally:
  if a:a.close()
p=D/'projection.watsup';p.write_text(c.PREFIX+'\n'+'\n'.join(fixtures)+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if $case'+str(i)+'()\n' for i in range(len(fixtures))));cmd=[str(runner),*map(str,mods),str(p)];(D/'runner.command.json').write_text(json.dumps(cmd));out=subprocess.run(cmd,capture_output=True,timeout=120);(D/'runner.stdout').write_bytes(out.stdout);(D/'runner.stderr').write_bytes(out.stderr);(D/'runner.status.json').write_text(json.dumps({'status':'exit','exit_status':out.returncode}));assert all(sha(K/p)==h for p,h in m['files'].items());r={'result':'pass' if out.returncode==0 and out.stdout==b'true\n' and not out.stderr else 'fail','fingerprint':m['fingerprint'],'records':records,'assertions':sum(x['assertions'] for x in records),'scope':'Six independently retained native-source types compile normally with exact source function ENDLINE/return roots; three ticks-block mixedstrictness remain explicit dependent boundaries. No runtime agreement claimed.'};(D/'report.json').write_text(json.dumps(r,indent=2));print(r)
