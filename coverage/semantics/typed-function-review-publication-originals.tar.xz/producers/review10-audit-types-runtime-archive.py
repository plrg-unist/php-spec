from pathlib import Path
import hashlib,json,stat,tarfile
R=Path.cwd();K=R/'.tools/runtime6-typed-calls';report=json.load(open(K/'coverage/semantics/typed-function-runtime-originals.json'));p=K/report['archive'];sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(p.read_bytes())==report['sha256'];payloads={};index=None
with tarfile.open(p,mode='r|xz') as t:
 for member in t:
  data=t.extractfile(member).read()
  if member.name=='index.json':
   assert index is None and sha(data)==report['index_sha256'];index=json.loads(data)
  else:
   assert member.name.startswith('payload/') and member.mode==0o644;h=member.name.split('/')[1];assert sha(data)==h and h not in payloads;payloads[h]=len(data)
assert index is not None and len(payloads)==index['unique_payloads']==report['unique_payloads'];rows={r['path']:r for r in index['files']};assert len(rows)==len(index['files'])==report['paths'];assert sum(r['bytes'] for r in rows.values())==index['raw_bytes']==report['raw_bytes']
for name,row in rows.items():
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 assert payloads[row['sha256']]==row['bytes'];assert 0<=row['mode']<=0o7777
 if (R/name).exists():assert sha((R/name).read_bytes())==row['sha256'] and stat.S_IMODE((R/name).stat().st_mode)==row['mode'],name
m=json.load(open(K/'final-inputs.json'));assert index['inputs']==m and report['fingerprint']==m['fingerprint']
for name,h in m['files'].items():
 row=rows[str((K/name).resolve().relative_to(R))];assert row['sha256']==h and row['mode']==m['modes'][name],name
refs=json.load(open(K/'semantics-reference-inputs.json'))
for name,h in refs['references'].items():assert rows[str((K/name).resolve().relative_to(R))]['sha256']==h,name
out={'result':'pass','archive':str(p),'sha256':report['sha256'],'index_sha256':report['index_sha256'],'paths':len(rows),'unique_payloads':len(payloads),'bytes':p.stat().st_size,'all_payload_bytes_verified':True,'indexed_modes_verified_against_retained_paths':True,'all926_final_inputs_exact':True,'pinned_reference_inputs':len(refs['references']),'fingerprint':m['fingerprint'],'scope':'One-pass archive verification checks every content-addressed payload, every indexed size/mode, all926 frozen source/tool inputs and all pinned source-reference hashes. Source/state/compiler gate identities remain926/baa, protocol926/599; setup and legacy scopes remain as recorded in index classifications.'};(R/'.tools/review10-types-runtime-archive-audit.json').write_text(json.dumps(out,indent=2));print(out)
