from pathlib import Path
import argparse,copy,hashlib,json,sys,tempfile,stat
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);a=ap.parse_args();R=Path.cwd();new=a.candidate.resolve();old=R/'.tools/review10-strict-final';sys.path.insert(0,str(new/'tests/semantics'));import request_environment as q
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-types-untyped-bridge-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes());manifests={kind:json.load(open(k/'inputs.json')) for kind,k in [('old',old),('new',new)]}
def audit():
 for kind,k in [('old',old),('new',new)]:
  for p,h in manifests[kind]['files'].items():assert hashlib.sha256((k/p).read_bytes()).hexdigest()==h and stat.S_IMODE((k/p).stat().st_mode)==manifests[kind]['modes'][p],(kind,p)
audit();(D/'inputs.json').write_text(json.dumps(manifests,indent=2));rows={r['id']:r for r in json.load(open(R/'.tools/review10-strict-originals-kb3qdtc1/report.json'))['records']};selection=[rows['weak-cache-control'],json.load(open(R/'.tools/review9-reference-state-0tj_17y7/saved-param-owner/original.json'))];records=[]
def strip(state):
 origins={(unit['ID'],json.dumps(occ['args'][0],sort_keys=True)):occ['args'][1] for unit in state['SOURCES'] for occ in unit['OCCURRENCES']}
 removed={'endlines':0,'return_roots':0}
 def walk(x):
  if isinstance(x,dict):
   if 'ENDLINE' in x:
    unit,path=x['ORIGIN']['args'];node=origins[unit,json.dumps(path,sort_keys=True)];assert node['tag']=='NStmtFunction'
    lines=[m['args'][0] for m in node['args'][-1] if m['tag']=='MendLine'];assert lines==[x.pop('ENDLINE')];removed['endlines']+=1
   if set(x)=={'STRICT','GLOBALS','UNIT','EXPRESSIONS','NAMES','REDIRECTS'}:
    keep=[]
    for entry in x['EXPRESSIONS']:
     key=(x['UNIT'],json.dumps(entry['args'][0],sort_keys=True))
     if entry['tag']=='CODEEXPR' and origins[key]['tag']=='NStmtReturn':
      assert entry['args'][2] is False;removed['return_roots']+=1
     else:keep.append(entry)
    x['EXPRESSIONS']=keep
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(state);return removed
for row in selection:
 name=row['id'];d=D/name;d.mkdir();(d/'original.json').write_text(json.dumps(row));states={}
 f=Worker([str(new/'.tools/php/bin/php'),'-n',*q.t.FLAGS,'-d','extension='+str(new/'.tools/php-file.so'),str(new/'frontend/worker.php')],d/'frontend-wire')
 try:parsed=f.request({'op':'parse','source':row['source_base64']});assert parsed['accepted']
 finally:f.close()
 for kind,k in [('old',old),('new',new)]:
  w=Worker([str(k/'_build/default/adapter/main.exe'),str(k)],d/(kind+'-wire'))
  try:
   for budget in [0,8,16,32,64,128,10000]:
    out=w.request({'op':'execute','ast':parsed['ast'],'steps':budget,'filename':q.b64(row['context'].encode()),'request':row['request']});(d/(kind+'-'+str(budget)+'.json')).write_text(json.dumps(out));states[kind,budget]=out['state']
  finally:w.close()
 for budget in [0,8,16,32,64,128,10000]:
  projected=copy.deepcopy(states['new',budget]);removed=strip(projected);assert removed['endlines']>0;assert projected==states['old',budget],(name,budget)
 actual=q.cli.observe(states['new',10000],row['context']);assert actual['status'] in ('normal','php_error') and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status']);records.append({'id':name,'budgets':[0,8,16,32,64,128,10000],'max_saved_frames':max(len(states['new',n]['FRAMES']) for n in [0,8,16,32,64,128,10000]),'entire_state_equal_after_only_source_derived_endline_and_return_roots_removal':True,'native_agreement':True})
audit();report={'result':'pass','old':manifests['old']['fingerprint'],'new':manifests['new']['fingerprint'],'records':records,'scope':'Two exact accepted917 untyped sources: default cache before abrupt failure and saved reference owner. Only source-derived function ENDLINE and return-root CODEEXPR entries removed; all other state fields compare entirely at seven cuts.'};(D/'report.json').write_text(json.dumps(report,indent=2));print(report)
