from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={'calls1-two-frames': b'<?php function f($x){g($x);}function g($y){echo MISSING;}f("test");', 'calls3-callee-fatal-stack-and-output': b'<?php function f(){echo "A";return 1/0;}echo "B",f(),"C";'}
if __name__=='__main__':scope.main(CASES,'review10-types-render-originals',Path(__file__))
