from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'typed-default-scalar-cache-before-array-error':b'<?php\nconst C=3;\nfunction f(array $x=C){echo "BODY";}\nf();',
 'typed-default-null-cache-before-int-error':b'<?php\nconst C=[];\nfunction f(int $x=C[0]){echo "BODY";}\nf();',
 'typed-return-array-local-cleanup':b'<?php\nfunction f():int{$a=[1];$b=&$a[0];return $a;}\nf();',
 'typed-return-array-global-owner':b'<?php\nfunction f():int{global $a;$a=[1];$b=&$a[0];return $a;}\nf();',
 'mixed-weak-caller-strict-callee':b'<?php\ndeclare(ticks=0){function weak(){return f("2");}}\ndeclare(strict_types=1);\nfunction f(int $x){return $x;}\necho weak();',
 'mixed-strict-caller-weak-return':b'<?php\ndeclare(ticks=0){function weak():int{return "2";}}\ndeclare(strict_types=1);\necho weak();',
 'mixed-weak-caller-strict-return':b'<?php\ndeclare(ticks=0){function weak(){return f();}}\ndeclare(strict_types=1);\nfunction f():int{return "2";}\necho weak();',
}
if __name__=='__main__':scope.main(CASES,'review10-types-originals',Path(__file__))
