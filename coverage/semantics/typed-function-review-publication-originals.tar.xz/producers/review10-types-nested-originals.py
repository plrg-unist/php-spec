from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={'typed-nested-return-context':b'<?php\nfunction g():int{return 2;}\nfunction f():int{return g();}\necho f();'}
if __name__=='__main__':scope.main(CASES,'review10-types-nested-originals',Path(__file__))
