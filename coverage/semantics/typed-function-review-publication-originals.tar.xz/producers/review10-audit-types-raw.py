from pathlib import Path
import json,sys,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
roots=[R/".tools"/n for n in ['review10-types-originals-brma4fpo', 'review10-types-return-alias-originals-ixu_0zfk', 'review10-types-nested-originals-4jnh3zul', 'review10-types-top-return-originals-32gd60ea', 'review10-types-render-originals-pk3ckd1i', 'review10-types-replay-g3px7aj0', 'review10-types-replay-qcjt4l6f', 'review10-types-replay-pm40natw', 'review10-types-protocol-tvmh06b7', 'review10-types-protocol-_ealdbq_', 'review10-types-protocol-l69frhbl', 'review10-types-protocol-dadztpwv', 'review10-types-protocol-uhxecig7', 'review10-types-protocol-6sbhvt8v', 'review10-types-protocol-1tcusbw8', 'review10-types-protocol-15uc1hru', 'review10-types-state-f76v7p6c', 'review10-types-untyped-bridge-4wmqqdr2', 'review10-types-projection-9nrni2s6', 'review10-types-protocol-output-helper-e1qk7a35']]
records=[]
for root in roots:
 workers=[]
 for p in root.rglob('close.json'):
  d=p.parent;close=json.load(open(p));assert close=={'status':'exit','exit_status':0,'final_exit_status':0},p;assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes();requests=list(d.glob('*.request'));assert len(requests)==len(list(d.glob('*.response')))
  for n in range(len(requests)):
   req=(d/(str(n)+'.request')).read_bytes();res=(d/(str(n)+'.response')).read_bytes();assert req.endswith(b'\n') and res.endswith(b'\n');decoded=wire.loads(res.decode());assert decoded['ok'];wire.loads(req.decode())
  workers.append({'directory':str(d),'responses':len(requests),'clean_closure':True})
 records.append({'root':str(root),'workers':workers,'responses':sum(w['responses'] for w in workers)})
r={'result':'pass','records':records,'responses':sum(x['responses'] for x in records),'clean_closures':sum(len(x['workers']) for x in records),'scope':'Complete recorded worker request/response packets, parseability, ok flags, stderr, trailing stdout and process closures. Includes historical917 originals,920 guard defects, failed fixture setup attempts and926 final gates; categories are not semantic agreement counts.'};(R/'.tools/review10-types-raw-audit.json').write_text(json.dumps(r,indent=2));print(r['responses'],r['clean_closures'])
