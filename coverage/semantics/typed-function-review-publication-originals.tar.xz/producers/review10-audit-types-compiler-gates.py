from pathlib import Path
import json,hashlib,sys,base64
R=Path.cwd();K=R/'.tools/compiler6-typed-calls';m=json.load(open(K/'final-inputs.json'));sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();sys.path.insert(0,str(R/'frontend'));import wire
p=K/'coverage/semantics/typed-function-compiler.json';d=json.load(open(p));root=K/d['raw'];assert d['result']=='pass' and d['compared']==56 and len(d['pending'])==8 and d['context_assertions']==38 and len(d['cases'])==64
for p,h in d['inputs'].items():assert sha(K/p)==h and m['files'][p]==h,p
assert (root/'spectec.stdout').read_bytes()==b'true\n' and not (root/'spectec.stderr').read_bytes();assert json.load(open(root/'spectec.status.json'))=={'status':'exit','exit_status':0};assert sha(root/'compiler.watsup')==d['fixture_sha256']
for row in d['cases']:
 name=row['name'];assert (root/(name+'.php')).read_bytes()==base64.b64decode(row['source_base64']);assert json.load(open(root/(name+'.status.json')))['exit_status']==row['lint_exit'];command=json.load(open(root/(name+'.command.json')));assert command[0]==str(K/'.tools/php/bin/php') and str(root/(name+'.php')) in command
workers=[]
for p in root.rglob('close.json'):
 f=p.parent;assert json.load(open(p))=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (f/'stderr').read_bytes() and not (f/'trailing.stdout').read_bytes();n=len(list(f.glob('*.request')));assert n==len(list(f.glob('*.response')))
 for i in range(n):wire.loads((f/(str(i)+'.request')).read_text());assert wire.loads((f/(str(i)+'.response')).read_text())['ok']
 workers.append({'directory':str(f),'responses':n})
r={'result':'pass','fingerprint':m['fingerprint'],'typed_exact_native_phases':56,'dependent_boundaries':8,'source_projections':38,'native_profiles':64,'workers':workers,'raw_responses':sum(w['responses'] for w in workers),'clean_closures':len(workers),'scope':'Portable typed compiler gate: exact source bytes/native exit envelopes, sole pinned executable commands, actual SpecTec runner true with clean status, loaded920 input hashes, full worker packets and closures. Runtime95 acceptance remains separate.'};(R/'.tools/review10-types-compiler-gates-audit.json').write_text(json.dumps(r,indent=2));print(r)
