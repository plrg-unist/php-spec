from pathlib import Path
import json,hashlib,tarfile,stat
R=Path.cwd();K=R/'.tools/compiler6-typed-calls';info=json.load(open(K/'archive.json'));a=Path(info['archive']);sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==info['sha256']
with tarfile.open(a) as t:
 m=json.load(t.extractfile('SHA256.json'));assert len(m['files'])==6523 and set(t.getnames())==set(m['files'])|{'SHA256.json'}
 for p,h in m['files'].items():assert sha(t.extractfile(p).read())==h and t.getmember(p).mode==m['modes'][p],p
 for n,x in m['tools'].items():
  suffix=next(p for p in ['.tools/php/bin/php','.tools/php-file.so','.tools/request-clock.so','_build/default/adapter/main.exe','tests/semantics/_build/default/numeric_runner.exe'] if n.endswith(p));assert sha((R/'.tools/review10-strict-final'/suffix).read_bytes())==x['sha256'],n
 for p,x in m['historical_native_tool_aliases'].items():assert sha(Path(p).read_bytes())==x['sha256'] and stat.S_IMODE(Path(p).stat().st_mode)==x['mode'] and x['sha256']==sha((R/'.tools/review10-strict-final/.tools/php/bin/php').read_bytes())
 final=json.load(t.extractfile('compiler920/final-inputs.json'));assert final==json.load(open(R/'.tools/review10-typed-compiler/inputs.json'))
 for p,h in final['files'].items():assert sha((K/p).read_bytes())==h and stat.S_IMODE((K/p).stat().st_mode)==final['modes'][p],p
r={'result':'pass','archive':str(a),'sha256':info['sha256'],'paths':6523,'tools_bound':len(m['tools']),'historical_native_aliases_bound':len(m['historical_native_tool_aliases']),'all_payload_bytes_modes':True,'compiler':final['fingerprint'],'scope':'Independent compiler archive payload/mode,920source/toolclosure and historical native executable bindings. Gate observation/protocol and runtime95 acceptance remain separately reviewed.'};(R/'.tools/review10-types-compiler-archive-audit.json').write_text(json.dumps(r,indent=2));print(r)
