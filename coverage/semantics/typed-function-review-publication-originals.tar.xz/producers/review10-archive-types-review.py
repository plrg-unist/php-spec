from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path.cwd();files={};tools={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
def tree(n,p):
 for f in p.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:add(n+'/'+str(f.relative_to(p)),f)
for n,p in [('baseline917',R/'.tools/review10-strict-final'),('first920',R/'.tools/review10-types-first'),('tested926',R/'.tools/review10-types-final')]:
 m=json.load(open(p/'inputs.json'));add(n+'/inputs.json',p/'inputs.json')
 for rel,h in m['files'].items():
  f=p/rel;assert sha(f.read_bytes())==h and stat.S_IMODE(f.stat().st_mode)==m['modes'][rel],rel;add(n+'/'+rel,f)
for row in json.load(open(R/'.tools/review10-types-raw-audit.json'))['records']:
 p=Path(row['root']);tree('raw/'+p.name,p)
for p in R.glob('.tools/review10-*types*.py'):add('producers/'+p.name,p)
for p in R.glob('.tools/review10-types-*-audit.json'):add('audits/'+p.name,p)
for n in ['review10-types-render-early-audit.json','review10-types-compiler-archive-audit.json','review10-types-compiler-gates-audit.json','review10-types-pairing-audit.json','review10-types-raw-audit.json']:
 p=R/'.tools'/n
 if p.exists():add('audits/'+p.name,p)
add('corrected-protocol/typed_function_protocol.py',R/'.tools/review10-types-publication/tests/semantics/typed_function_protocol.py')
add('compiler920/inputs.json',R/'.tools/review10-typed-compiler/inputs.json')
add('compiler920/paired926-bridge.json',R/'.tools/compiler6-typed-calls/paired926-bridge.json')
for n in ['zend_exceptions.c','zend_execute.c','zend_vm_def.h','zend_API.c']:add('vendor/php-src/Zend/'+n,R/'vendor/php-src/Zend'/n)
manifest={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools};out=R/'.tools/review10-types-review-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 b=(json.dumps(manifest,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(manifest['files'][n],manifest['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(out) as t:
 for n,h in manifest['files'].items():assert sha(t.extractfile(n).read())==h and t.getmember(n).mode==manifest['modes'][n]
report={'archive':str(out),'sha256':sha(out.read_bytes()),'paths':len(files),'bytes':out.stat().st_size,'tools':tools,'scope':'Independent typed source originals on accepted917, actual first920 receive/fallthrough/return metadata defects and failed fixture setup attempts, exact tested926 source/state/protocol gates, complete untyped917 state bridges, recorded raw audits and source producers. The three mixed-strictness ticks cases remain dependency controls. Excluded binaries bind immutable input manifests; copied raw evidence modes remain distinct from invoked tool modes. The one-test output helper correction is retained separately and does not relabel926/baa semantic gates.','baseline':json.load(open(R/'.tools/review10-strict-final/inputs.json'))['fingerprint'],'tested':json.load(open(R/'.tools/review10-types-final/inputs.json'))['fingerprint']};(R/'.tools/review10-types-review-originals-archive.json').write_text(json.dumps(report,indent=2));print(report['sha256'],len(files),report['bytes'])
