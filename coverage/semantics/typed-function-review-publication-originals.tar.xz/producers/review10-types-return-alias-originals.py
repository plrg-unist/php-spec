from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'typed-value-return-reference-param-copy':b'<?php\nfunction f(&$x):int{return $x;}\n$x="2";$y=&$x;echo f($x),$x==="2",$y==="2";',
 'typed-value-return-global-alias-copy':b'<?php\n$x="2";$y=&$x;\nfunction f():int{global $x;$z=&$x;return $z;}\necho f(),$x==="2",$y==="2";',
}
if __name__=='__main__':scope.main(CASES,'review10-types-return-alias-originals',Path(__file__))
