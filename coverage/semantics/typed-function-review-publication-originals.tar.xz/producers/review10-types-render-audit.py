from pathlib import Path
import argparse,base64,hashlib,json,sys
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('reports',nargs='+',type=Path);a=ap.parse_args();K=a.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
R=Path.cwd();sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();records=[]
for report in a.reports:
 data=json.load(open(report));D=Path(data['raw'])
 for i,row in enumerate(data['records']):
  state=json.load(open(D/str(i)/'state.json'))['state'];actual=q.cli.observe(state,row['context']);c=state['COMPLETION']
  if c['tag'] not in ['THROWN','PHPERROR']:continue
  assert all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  if c['tag']=='THROWN':
   cls,msg,line=c['args'];raw=bytes(map(int,msg));assert actual['diagnostic']=={'class':cls,'message':base64.b64encode(raw).decode(),'line':int(line)}
   assert b' and defined' not in raw
   suffix=cls in ['TypeError','ArgumentCountError'] and b', called in ' in raw.split(b'\0',1)[0]
   assert (b' and defined' in base64.b64decode(actual['stderr']))==suffix
  else:cls='Error';line=c['args'][1];suffix=False
  records.append({'id':row['id'],'class':cls,'line':line,'trace_frames':len(state['TRACE']),'display_suffix':suffix,'native_exact':True,'report':str(report),'report_sha256':sha(report)})
result={'result':'pass','candidate':str(K),'renderer_sha256':sha(K/'bin/php-semantics'),'pinned_source':'vendor/php-src/Zend/zend_exceptions.c:740','pinned_source_sha256':sha(R/'vendor/php-src/Zend/zend_exceptions.c'),'records':records,'scope':'Exact native displays/trace lines remain equal; semantic THROWN class/message/line retained separately from temporary uncaught display suffix. Existing Error and DivisionByZeroError controls included.'};out=R/'.tools/review10-types-render-audit.json';out.write_text(json.dumps(result,indent=2));print(out,len(records))
