from pathlib import Path
import base64,json,hashlib,stat,sys
R=Path.cwd();K=R/'.tools/runtime6-typed-calls';sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();final=json.load(open(K/'final-inputs.json'));tested=json.load(open(R/'.tools/review10-types-final/inputs.json'));assert final==json.load(open(R/'.tools/review10-types-canonical/inputs.json'))
for p,h in final['files'].items():assert sha(K/p)==h and stat.S_IMODE((K/p).stat().st_mode)==final['modes'][p],p
reports={n:json.load(open(K/'coverage/semantics'/f)) for n,f in [('source','typed-functions.json'),('state','typed-function-state.json'),('compiler','typed-function-compiler.json'),('protocol','typed-function-protocol.json')]}
for n in ['source','state']:assert reports[n]['result']=='pass' and reports[n]['fingerprint']==tested['fingerprint']
assert len(reports['source']['records'])==38 and len(reports['state']['records'])==4 and reports['state']['assertions']==1096
assert reports['protocol']['result']=='pass' and reports['protocol']['fingerprint']==final['fingerprint'] and len(reports['protocol']['records'])==19 and reports['protocol']['assertions']==218
assert reports['compiler']['result']=='pass' and reports['compiler']['compared']==56 and len(reports['compiler']['pending'])==8 and reports['compiler']['context_assertions']==38
for n in ['state','compiler']:
 for p,h in reports[n]['inputs'].items():assert sha(K/p)==h,(n,p)
for p,h in reports['source']['direct_inputs'].items():assert sha(K/p)==h,('source',p)
source_root=Path(reports['source']['raw'])
for row in reports['source']['records']:
 d=source_root/row['id'];assert (d/'source.php').read_bytes()==base64.b64decode(row['source_base64']);assert row['context']==str(d/'source.php');assert json.load(open(d/'request.json'))==row['request'];state=json.load(open(d/'state.json'))['state'];actual=q.cli.observe(state,row['context']);assert actual==row['actual'];assert actual['status'] in ['normal','php_error'] and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
 for k in ['stdout','stderr']:assert (d/('native.'+k)).read_bytes()==base64.b64decode(row['native'][k])
 assert json.load(open(d/'native.status.json'))=={'status':'exit','exit_status':row['native']['exit_status']}
 command=json.load(open(d/'native.command.json'));assert command[0]==str(K/'.tools/php/bin/php') and command[-1]==row['context'];assert command[1:-1]==['-n',*q.t.FLAGS,'-d','variables_order='+base64.b64decode(row['request']['variables']).decode('ascii')]
for row in reports['source']['cache_projections']:
 d=source_root/row['id'];s=json.load(open(d/'state.json'))['state'];assert s['DEFAULTCACHE']==[row['uncoerced_cache']];c=s['DEFAULTCACHE'][0];assert c['VALUE']=={'tag':'PSTRING','args':[['50']]} and c['CLASS']=={'tag':'PVSTRING','args':[True]};assert any(c['ORIGIN']==v['ORIGIN'] for f in s['FUNCTIONS'] for v in f['DEFAULTS']);assert row['pass']
assert reports['source']['projection_assertions']==12
workers=[];runners=[]
for name,report in reports.items():
 root=Path(report['raw']);root=root if root.is_absolute() else K/root
 for p in root.rglob('close.json'):
  d=p.parent;assert json.load(open(p))=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes();rs=list(d.glob('*.request'));assert len(rs)==len(list(d.glob('*.response')))
  for i in range(len(rs)):
   req=(d/(str(i)+'.request')).read_bytes();res=(d/(str(i)+'.response')).read_bytes();assert req.endswith(b'\n') and res.endswith(b'\n');wire.loads(req.decode());assert wire.loads(res.decode())['ok']
  workers.append({'gate':name,'directory':str(d),'responses':len(rs)})
 if name in ['state','protocol']:
  for p in root.rglob('*.status.json'):
   if p.name.startswith('native.'):continue
   base=str(p)[:-len('.status.json')];assert json.load(open(p))=={'status':'exit','exit_status':0};assert Path(base+'.stdout').read_bytes().strip()==b'true' and not Path(base+'.stderr').read_bytes();runners.append(str(p))
assert len(runners)==23
report={'result':'pass','tested':tested['fingerprint'],'corrected':final['fingerprint'],'source':38,'cache_projections':3,'cache_projection_assertions':12,'state':4,'state_assertions':1096,'protocol':19,'protocol_assertions':218,'compiler_exact_phases':56,'compiler_boundaries':8,'compiler_projections':38,'workers':workers,'responses':sum(x['responses'] for x in workers),'closures':len(workers),'runner_true_closures':len(runners),'scope':'Every final source outcome/native packet and uncoerced cache, all recorded protocol/state/compiler wire closures and loaded input hashes, plus23 successful standalone state/protocol runner closures. Tested926/baa retained separately from one-test-corrected926/599.'};(R/'.tools/review10-types-author-audit.json').write_text(json.dumps(report,indent=2));print(report['responses'],report['closures'],len(runners))
