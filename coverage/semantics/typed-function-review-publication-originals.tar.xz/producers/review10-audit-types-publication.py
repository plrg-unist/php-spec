from pathlib import Path
import base64,hashlib,json,stat,tarfile
R=Path.cwd();K=R/'.tools/runtime6-typed-calls';sha=lambda b:hashlib.sha256(b).hexdigest();m=json.load(open(K/'final-inputs.json'))
for n,h in m['files'].items():assert sha((R/n).read_bytes())==h and stat.S_IMODE((R/n).stat().st_mode)==m['modes'][n],n
cli=json.load(open(K/'coverage/semantics/typed-function-publication-cli.json'));assert cli['result']=='pass' and cli['fingerprint']==m['fingerprint'] and len(cli['records'])==8
for row in cli['records']:
 d=Path(cli['raw'])/row['id'];old=row['original'];assert sha(Path(old['context']).read_bytes())==row['source_sha256']==sha(base64.b64decode(old['source_base64']));assert json.load(open(d/'request.json'))==old['request'];assert json.load(open(d/'status.json'))=={'exit_status':0};assert not (d/'stderr').read_bytes();actual=json.loads((d/'stdout').read_bytes());assert actual==row['actual'] and actual['frontend']=='accepted' and actual['checked']=='program' and actual['status'] in ['normal','php_error'];assert all(actual[n]==old['native'][n] for n in ['stdout','stderr','exit_status']);assert json.load(open(d/'command.json'))==[str(R/'bin/php-semantics'),old['context'],'--request-context',str(d/'request.json'),'--timeout','60']
info=json.load(open(K/'coverage/semantics/typed-function-runtime-publication-originals.json'));archive=K/info['archive'];assert sha(archive.read_bytes())==info['sha256'];history=json.load(open(K/'coverage/semantics/typed-function-runtime-originals.json'));assert info['history_sha256']==history['sha256'];oldaudit=json.load(open(R/'.tools/review10-types-runtime-archive-audit.json'));assert oldaudit['result']=='pass' and oldaudit['sha256']==history['sha256']
with tarfile.open(K/history['archive']) as t:oldindex=json.load(t.extractfile('index.json'))
oldpayloads={r['sha256']:r['bytes'] for r in oldindex['files']};newpayloads={}
with tarfile.open(archive,mode='r|xz') as t:
 for member in t:
  data=t.extractfile(member).read()
  if member.name=='index.json':assert sha(data)==info['index_sha256'];index=json.loads(data)
  else:h=member.name.split('/')[1];assert member.name=='payload/'+h and sha(data)==h;newpayloads[h]=len(data)
assert index['history_sha256']==history['sha256'] and index['fingerprint']==m['fingerprint'];assert len(index['files'])==info['paths']==55 and len(newpayloads)==info['new_payloads']==30
for row in index['files']:
 p=R/row['path'];assert sha(p.read_bytes())==row['sha256'] and stat.S_IMODE(p.stat().st_mode)==row['mode'];store=newpayloads if row['payload']=='publication' else oldpayloads;assert row['payload'] in ['publication','history'] and store[row['sha256']]==row['bytes']
report={'result':'pass','canonical_fingerprint':m['fingerprint'],'all926_bytes_modes_match':True,'canonical_cli':8,'cli_raw':cli['raw'],'publication_archive':info,'all55_indexed_paths_and30_new_payloads_verified':True,'history_payload_dependency_verified':True,'scope':'Eight canonical CLI commands, process closures, parsed outcomes, exact source/request/native-context equality, and complete supplement byte/mode audit. Prior source/state/compiler gates remain bound to926/baa; corrected protocol/canonical publication bind926/599.'};(R/'.tools/review10-types-publication-audit.json').write_text(json.dumps(report,indent=2));print('pass8 CLI;55 paths/30 new payloads;926 canonical bytes/modes')
