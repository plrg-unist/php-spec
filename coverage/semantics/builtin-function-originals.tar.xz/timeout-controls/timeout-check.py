from pathlib import Path
import importlib.util,json,subprocess,tempfile
from unittest.mock import patch
root=Path(__file__).resolve().parents[2];private=root/'.tools/compiler5-calls'
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
mods=[load('generate',private/'scripts/generate-builtin-functions.py'),load('test_builtins',private/'tests/semantics/builtin_functions.py')]
results=[]
for m in mods:
 made=[];actual=tempfile.mkdtemp
 def mk(*a,**kw):
  p=actual(*a,**kw);made.append(Path(p));return p
 def timeout(command,**kw):raise subprocess.TimeoutExpired(command,kw['timeout'],output=b'partial-output\x00',stderr=b'partial-error\xff')
 with patch.object(tempfile,'mkdtemp',mk),patch.object(subprocess,'run',timeout):
  try:m.derive(root) if hasattr(m,'derive') else m.main()
  except subprocess.TimeoutExpired:pass
  else:raise AssertionError('timeout did not propagate')
 out=made[-1];stem='Zend_zend_builtin_functions' if hasattr(m,'derive') else 'native'
 assert (out/(stem+'.stdout')).read_bytes()==b'partial-output\x00'
 assert (out/(stem+'.stderr')).read_bytes()==b'partial-error\xff'
 status=out/(stem+'.status.json' if hasattr(m,'derive') else 'native-status.json')
 assert json.loads(status.read_text())=={'status':'timeout'}
 assert (out/(stem+'.command.json' if hasattr(m,'derive') else 'native-command.json')).exists()
 results.append({'path':str(out),'status':'propagated timeout and exact byte preservation'})
(root/'.tools/compiler5-registry/timeout-results.json').write_text(json.dumps(results,indent=2)+'\n');print(results)
