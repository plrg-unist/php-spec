from pathlib import Path
import hashlib,io,json,tarfile
D=Path(__file__).resolve().parent;O=D.parent/'compiler5-builtin-write-originals'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
m=json.loads((D/'final-inputs.json').read_text());assert all(digest(D/p)==h for p,h in m['files'].items())
files={p:D/p for p in m['files']}
for p in ['archive.py','baseline-inputs.json','first81-inputs.json','first89-inputs.json','final-inputs.json','builtin-write-delta.json','semantics-reference-inputs.json','runtime6-final-compiler-bridge.json','focused-regression.py','docs/semantics/BUILTIN-CALL-COMPILER.md','coverage/semantics/builtin-write-compiler.json','coverage/semantics/function-reference-compiler.json','coverage/semantics/function-reference-send-compiler.json','coverage/semantics/function-compiler.json','coverage/semantics/function-argument-compiler.json','coverage/semantics/destructuring-compiler.json']:files[p]=D/p
for root,prefix in [(D/'.tools','.tools'),(O,'originals')]:
 for p in root.rglob('*'):
  if p.is_file():files[str(Path(prefix)/p.relative_to(root))]=p
for rel,h in json.loads((D/'semantics-reference-inputs.json').read_text())['references'].items():assert digest(D/rel)==h;files[rel]=D/rel
tools={p:h for p,h in m['files'].items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p in tools:files.pop(p,None)
hashes={p:digest(f) for p,f in files.items()};out=D/'coverage/semantics/reference-builtin-write-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 b=(json.dumps({'files':hashes,'tools':tools,'source_inputs':m},indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);t.addfile(i,io.BytesIO(b))
 for p,f in sorted(files.items()):
  h=hashes[p];i=t.gettarinfo(str(f),arcname=p)
  if h in seen:i.type=tarfile.LNKTYPE;i.linkname=seen[h];i.size=0;t.addfile(i)
  else:
   seen[h]=p
   with f.open('rb') as stream:t.addfile(i,stream)
with tarfile.open(out,'r:xz') as t:
 for p,h in hashes.items():assert hashlib.sha256(t.extractfile(p).read()).hexdigest()==h,p
report={'archive':str(out.relative_to(D)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':tools,'inputs':{'files':len(m['files']),'sha256':m['fingerprint']},'scope':'Private builtin call write-context/compiler ordering refinement paired with positional reference preparation.91 native old full-state originals and91 exact native compiler phases. No builtin execution or runtime acceptance claim.','ordered_cases_sha256':digest(D/'tests/semantics/builtin_write_cases.json'),'original_batches':['originals/.tools/send-kind-originals-uf5uw7sf','originals/expanded/.tools/send-kind-originals-214u2b4n','originals/priority/.tools/send-kind-originals-7k6knb_f','originals/lines/.tools/send-kind-originals-k61r6yra'],'compiler_raw':'.tools/builtin-write-compiler-7kbt1zjw','historical_before_refinement_raw':['.tools/builtin-write-compiler-4fj5s6ev','.tools/builtin-write-compiler-y93s2tif'],'focused':{'named':{'phases':39,'pending':7,'raw':'.tools/function_compiler-regression-yzzpomiq'},'historical_argument':{'phases':32,'contexts':21,'raw':'.tools/function_argument_compiler-regression-luldjt51'},'destructuring':{'phases':111,'metadata':32,'raw':'.tools/destructuring_compiler-regression-78g0xv1r'},'reference48':{'phases':48,'contexts':16,'raw':'.tools/function-reference-compiler-0mr9zdpv','scope':'Before final sprintf-only location refinement; exact module hashes retained.'},'send12':{'phases':12,'contexts':36,'raw':'.tools/function-reference-send-compiler-_d8z6aqx'}},'baseline_archive':{'path':'coverage/semantics/reference-send-kind-originals.tar.xz','sha256':'547bc6742983ec0812f3e1bdf5f90e7b30777f7199289afc0300ec609c5a92f9'},'reconstructed_payload':'first89-before-line/builtin_write_cases.json reconstructed byte-identically from retained first81 catalogue plus eight priority inputs, checked against the pre-repair first89 manifest; not described as an earlier captured file.','worker_boundary':'Retained decoded JSON responses, not exact transport wire or separate worker stderr. Native/SpecTec subprocess bytes and statuses retained; focused wrappers catch and retain timeout partial output.','paired_bridge':'runtime6-final-compiler-bridge.json'}
(D/'coverage/semantics/reference-builtin-write-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert all(digest(D/p)==h for p,h in m['files'].items())
