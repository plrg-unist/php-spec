<?php function f(&$x){}f(sprintf(
'abc'
)[0]);