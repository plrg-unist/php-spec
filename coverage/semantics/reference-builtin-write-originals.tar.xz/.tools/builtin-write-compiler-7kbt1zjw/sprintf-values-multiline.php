<?php function f(&$x){}f(sprintf(
'%d',
1
)[0]);