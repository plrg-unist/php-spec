<?php function f(&$x){}f(defined(
'X'
)[0]);