<?php function f(&$x){}f(strlen(
'a'
)[0]);