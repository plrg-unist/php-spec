<?php
function f(
$x=
UNKNOWN
){}