<?php
function f(
$x=
__LINE__
){}