<?php
function f() {
 return
 [ ,$x];
}