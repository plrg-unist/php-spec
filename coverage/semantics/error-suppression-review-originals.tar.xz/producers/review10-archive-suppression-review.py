from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path.cwd();files={};tools={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
def tree(n,p):
 for f in p.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:add(n+'/'+str(f.relative_to(p)),f)
for name,path in [('baseline942',R/'.tools/review10-return-final'),('first944',R/'.tools/review10-suppression-first'),('guarded944',R/'.tools/runtime7-suppression-guarded'),('semantic951',R/'.tools/review10-suppression-integration'),('final951',R/'.tools/review10-suppression-final')]:
 m=json.loads((path/'inputs.json').read_text());add(name+'/inputs.json',path/'inputs.json')
 for rel,h in m['files'].items():
  f=path/rel;assert sha(f.read_bytes())==h and stat.S_IMODE(f.stat().st_mode)==m['modes'][rel],rel;add(name+'/'+rel,f)
for row in json.loads((R/'.tools/review10-suppression-raw-audit.json').read_text())['records']:
 p=Path(row['root']);tree('raw/'+p.name,p)
for p in R.glob('.tools/*review10*suppression*.py'):add('producers/'+p.name,p)
add('producers/review10-return-reference-replay.py',R/'.tools/review10-return-reference-replay.py')
for p in R.glob('.tools/review10-suppression-*.json'):add('audits/'+p.name,p)
add('compiler/archive.json',R/'.tools/compiler7-suppression/archive.json')
add('author/semantic-test-bridge.json',R/'.tools/runtime7-suppression-candidate/semantic-test-bridge.json')
for name in ['zend_compile.c','zend_execute.c','zend_vm_def.h','zend_globals.h','zend_builtin_functions.c','zend_errors.h']:add('vendor/php-src/Zend/'+name,R/'vendor/php-src/Zend'/name)
add('vendor/php-src/main/main.c',R/'vendor/php-src/main/main.c')
m={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools}
a=R/'.tools/review10-suppression-review-originals.tar.xz';seen={}
with tarfile.open(a,'w:xz') as t:
 b=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(m['files'][n],m['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
verified={}
with tarfile.open(a,mode='r|xz') as t:
 for z in t:
  if z.name=='SHA256.json':continue
  h=verified[z.linkname] if z.islnk() else sha(t.extractfile(z).read())
  assert h==m['files'][z.name] and z.mode==m['modes'][z.name];verified[z.name]=h
assert set(verified)==set(files)
result={'archive':str(a),'sha256':sha(a.read_bytes()),'paths':len(files),'bytes':a.stat().st_size,'tools':tools,'baseline':json.loads((R/'.tools/review10-return-final/inputs.json').read_text())['fingerprint'],'tested':json.loads((R/'.tools/review10-suppression-integration/inputs.json').read_text())['fingerprint'],'final':json.loads((R/'.tools/review10-suppression-final/inputs.json').read_text())['fingerprint'],'compiler_originals_archive':'2cb921c7788ab453380f79aeb2259977efec3532d45f89edaa3091d7769ccae7','scope':'Independent four original942 native/full-request Unsupported sources; immutable first944 scope/task/source-line/mask counterexamples and explicit fixture failures; signed32 boundary correction with validmask/value positives. Semantic951/ff8d source4, protocol23/489, states4/1312, two full942 old-field bridges. Final951/c650 changes only demand report print. All90 decoded responses/33 clean worker closures audited;72 true standalone and4 retained fixture setup failures distinct. Full source/tool hash-mode maps retained; actual executable bytes are in linked author runtime archive. Two reused933 variable contexts retain original native provenance through compiler2cb nestedf38 archive.'}
(R/'.tools/review10-suppression-review-originals-archive.json').write_text(json.dumps(result,indent=2)+'\n');print(result['sha256'],result['paths'],result['bytes'])
