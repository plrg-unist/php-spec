from pathlib import Path
import base64,hashlib,json,sys
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
roots=[('baseline942','.tools/review10-suppression-originals-q1nzdxv_'),('first944-source','.tools/review10-return-reference-replay-utvzhs1l'),('semantic951-source','.tools/review10-return-reference-replay-szxj0sw4'),('semantic951-state','.tools/review10-suppression-state-guid6fm5'),('942-to951-bridge','.tools/review10-suppression-compatibility-b0esgf13'),('semantic951-protocol','.tools/review10-suppression-integration/.tools/error-suppression-protocol-3b_lvz1f')]
roots += [('original-and-repair-protocol','.tools/'+n) for n in ['review10-suppression-protocol-kd0isg_1','review10-suppression-protocol-g9ia539_','review10-suppression-protocol-hpzcn4f0','review10-suppression-protocol-f_onaw2j','review10-suppression-protocol-7mozwz_1','review10-suppression-protocol-_ch09_3e','review10-suppression-protocol-id3ickl4','review10-suppression-protocol-wv13ao8l','review10-suppression-protocol-rnibgcb8']]
records=[]
for scope,n in roots:
 d=R/n;responses=closures=natives=passed=failed=0
 for close in d.rglob('close.json'):
  p=close.parent;assert json.loads(close.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (p/'stderr').read_bytes() and not (p/'trailing.stdout').read_bytes()
  reqs=list(p.glob('*.request'))
  for i in range(len(reqs)):
   request=wire.loads((p/(str(i)+'.request')).read_text());response=wire.loads((p/(str(i)+'.response')).read_text());assert response['ok'];responses+=1
  closures+=1
 for status in d.rglob('native.status.json'):
  p=status.parent;r=json.loads(status.read_text());assert r['status']=='exit' and r['exit_status'] in (0,255);natives+=1
 for status in d.rglob('*.status.json'):
  if status.name=='native.status.json':continue
  r=json.loads(status.read_text());assert r['status']=='exit';stem=str(status)[:-12];stdout=Path(stem+'.stdout').read_bytes();stderr=Path(stem+'.stderr').read_bytes()
  if r['exit_status']==0:assert stdout.strip()==b'true' and not stderr;passed+=1
  else:assert d.name in ('review10-suppression-protocol-kd0isg_1','review10-suppression-protocol-_ch09_3e') and b'syntax error' in stderr or d.name=='review10-suppression-protocol-_ch09_3e' and b'otherwise' in stderr;failed+=1
 if scope=='semantic951-state':assert json.loads((d/'report.json').read_text())['result']=='pass'
 records.append({'root':str(d),'scope':scope,'responses':responses,'clean_worker_closures':closures,'native_processes':natives,'true_standalone_closures':passed,'retained_fixture_failures':failed})
# Bind exact source/native bytes and complete request provider inputs for fresh sources.
for p in [R/'.tools/review10-suppression-originals-q1nzdxv_/report.json']:
 report=json.loads(p.read_text())
 for row in report['records']:
  source=Path(row['context']);d=source.parent;assert source.read_bytes()==base64.b64decode(row['source_base64'])
  for k in ('stdout','stderr'):assert (d/('native.'+k)).read_bytes()==base64.b64decode(row['native'][k])
  assert json.loads((d/'native.status.json').read_text())['exit_status']==row['native']['exit_status'];assert json.loads((d/'request.json').read_text())==row['request'];assert (d/'request.input').is_file()
out={'result':'pass','records':records,'responses':sum(r['responses'] for r in records),'clean_worker_closures':sum(r['clean_worker_closures'] for r in records),'true_standalone_closures':sum(r['true_standalone_closures'] for r in records),'retained_fixture_failures':sum(r['retained_fixture_failures'] for r in records),'scope':'Actual942 Unsupported originals, first944 counterexamples, intermediate guard replays and semantic951 source/protocol/state/old-field bridges remain distinct. Four fixture syntax/elaboration failures are preserved; no tool failure is a semantic agreement.'}
(R/'.tools/review10-suppression-raw-audit.json').write_text(json.dumps(out,indent=2));print(out)
