from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as fs
CASES={
 'suppressed-default-warning-cache':b'<?php\nconst C="2x";function f($x=C+1){echo $x;}\n@f();f();echo $missing;',
 'suppressed-default-cache-type-error':b'<?php\nconst C="2x";function f(array $x=C+1){}\n@f();echo "AFTER";',
 'suppressed-reference-default-fresh-cells':b'<?php\nconst C="2x";function f(&$x=C+1){$x++;echo $x;}\n@f();@f();echo $missing;',
 'suppressed-default-evaluation-error':b'<?php\nconst C=1;function f($x=C/0){}\n@f();echo "AFTER";',
}
if __name__=='__main__':fs.main(CASES,'review10-suppression-originals',Path(__file__))
