from pathlib import Path
import argparse,base64,hashlib,json,subprocess,sys,tempfile
parser=argparse.ArgumentParser();parser.add_argument('candidate',type=Path);parser.add_argument('--match',default='');args=parser.parse_args()
R=Path.cwd();K=args.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'))
import function_call_state as cs
import request_environment as q
import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-suppression-state-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes())
original=R/'.tools/review10-suppression-originals-q1nzdxv_/report.json';rows={r['id']:r for r in json.loads(original.read_text())['records']}
extra=original;order=original
selection=list(rows)
selection=[n for n in selection if args.match in n];assert selection
modules=[K/n for n in json.loads((K/'spec/semantics/modules.json').read_text())];runner=K/'tests/semantics/_build/default/numeric_runner.exe';sha=lambda b:hashlib.sha256(b).hexdigest()
inputs={str(p.relative_to(K)):sha(p.read_bytes()) for p in [*modules,runner,K/'tests/semantics/function_call_state.py',K/'tests/semantics/recorded_worker.py']};before=q.t.syntax_validation.implementation_fingerprint()
(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'closure':before,'direct':inputs,'source_report':str(original),'source_report_sha256':sha(original.read_bytes()),'extra_report':str(extra),'extra_report_sha256':sha(extra.read_bytes()),'order_report':str(order),'order_report_sha256':sha(order.read_bytes())},indent=2)+'\n')
for p in inputs:
 dst=D/'original-inputs'/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes((K/p).read_bytes())
prefix=cs.PREFIX+r"""
dec $review_reference_stage(pstate) : bool
def $review_reference_stage(S) = true
  -- if S.TODO = (DEFAULT_STAGE porigin n) :: ptask*
def $review_reference_stage(S) = false -- otherwise
dec $review_reference_budget(pstate, nat, nat) : nat
def $review_reference_budget(S, n_left, n_count) = n_count -- if $review_reference_stage(S)
def $review_reference_budget(S, n_left, n_count) = $review_reference_budget(S_next[.COMPLETION = NORMAL], n_rest, $(n_count + 1))
  -- if ~$review_reference_stage(S)
  -- if $(n_left > 0)
  -- if n_rest = $(n_left - 1)
  -- if S_next = $drive_steps(S, 1)
"""
extras={name:(['S_out.DEFAULTCACHE = eps'] if name.endswith('evaluation-error') else ['S_out.DEFAULTCACHE = [pdefaultcache]','pdefaultcache.VALUE = PINT 3','pdefaultcache.CLASS = PVSCALAR','$default_function_at(S_out.FUNCTIONS, pdefaultcache.ORIGIN) = (pfunction)','$default_origin_at(pfunction.DEFAULTS, pdefaultcache.ORIGIN) = (pdefault)']) for name in selection}

records=[];frontend=adapter=None
print(D,flush=True)
try:
 frontend=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire')
 adapter=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for name in selection:
  row=rows[name];directory=D/name;directory.mkdir();(directory/'original.json').write_text(json.dumps(row,indent=2)+'\n')
  assert Path(row['context']).read_bytes()==base64.b64decode(row['source_base64'])
  parsed=frontend.request({'op':'parse','source':row['source_base64']});assert parsed['accepted'];checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True})
  (directory/'checked.json').write_text(json.dumps(checked)+'\n')
  result=adapter.request({'op':'execute','ast':parsed['ast'],'steps':10000,'filename':q.b64(bytes(Path(row['context']))),'request':row['request']});(directory/'state.json').write_text(json.dumps(result)+'\n')
  actual=q.cli.observe(result['state'],row['context']);assert actual['status'] in ('normal','php_error') and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  initial='$php_request_run('+checked['fixture']+', 0, '+json.dumps(q.b64(bytes(Path(row['context']))))+', '+rs.request_fixture(row['request'])+')'
  completion='THROWN "TypeError" n_message* 2' if name.endswith('type-error') else ('THROWN "DivisionByZeroError" n_message* 2' if name.endswith('evaluation-error') else 'NORMAL')
  checks=['S_initial = '+initial,'S_initial.COMPLETION = BUDGET','S = S_initial[.COMPLETION = NORMAL]','S_out = $drive(S, 10000)','S_out.COMPLETION = '+completion,'$outputs(S_out.EVENTS) = '+cs.d.byte_sequence(base64.b64decode(row['native']['stdout'])),'S_out.FRAMES = eps','S_out.CURRENT = eps','S_out.GLOBALTABLE = eps','S_out.ITERATORS = eps','S_out.HELD = eps','S_out.TODO = eps','S_out.CONSTCONTEXT = eps','S_out.REPORTING = 30719','S_out.SILENCES = eps','$heap_valid($heap_graph(S_out))','$call_valid(S_out)','$call_descriptors_valid(S_out)',*extras[name]]
  for budget in [*range(33),64,128]:
   checks += [f'S_b{budget} = $drive(S, {budget})',f'$resume_destructuring(S_b{budget}, 1) = $drive(S, {budget+1})',f'$heap_valid($heap_graph(S_b{budget}))',f'$call_valid(S_b{budget})',f'$call_descriptors_valid(S_b{budget})',f'S_b{budget}.REQUEST = S.REQUEST',f'S_b{budget}.HTTPROOTS = S.HTTPROOTS']
  checks += [f'$resume_destructuring(S_b{budget}, 10000) = S_out' for budget in [0,1,7,16,32,64,128]]
  checks += ['n_return = $review_reference_budget(S, 1000, 0)','n_before = $(n_return - 1)','n_after = $(n_return + 1)','n_after2 = $(n_return + 2)','n_after3 = $(n_return + 3)']
  for label in ['before','return','after','after2','after3']:
   checks += [f'S_{label} = $drive(S, n_{label})',f'n_{label}_next = $(n_{label} + 1)',f'$resume_destructuring(S_{label}, 1) = $drive(S, n_{label}_next)',f'$resume_destructuring(S_{label}, 10000) = S_out',f'$heap_valid($heap_graph(S_{label}))',f'$call_valid(S_{label})',f'$call_descriptors_valid(S_{label})',f'S_{label}.REQUEST = S.REQUEST',f'S_{label}.HTTPROOTS = S.HTTPROOTS']
  fixture=directory/'state.watsup'
  checks += ['S_return.REPORTING = 4437','S_return.SILENCES = eps','S_return.FRAMES = pframe :: pframe_tail*','pframe.SILENCES = [SILENCE porigin_silence 30719]']
  fixture.write_text(prefix.replace('DEFAULT_STAGE', 'DEFAULT_RECEIVE' if name.endswith('evaluation-error') else 'DEFAULT_BIND')+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+c+'\n' for c in checks));records.append({'id':name,'fixture':str(fixture),'assertions':len(checks),'actual':actual})
finally:
 try:
  if frontend is not None:frontend.close()
 finally:
  if adapter is not None:adapter.close()
for row in records:
 directory=Path(row['fixture']).parent;command=[str(runner),*map(str,modules),row['fixture']];(directory/'runner.command.json').write_text(json.dumps(command)+'\n')
 try:result=subprocess.run(command,capture_output=True,timeout=300)
 except subprocess.TimeoutExpired as error:
  (directory/'runner.stdout').write_bytes(error.stdout or b'');(directory/'runner.stderr').write_bytes(error.stderr or b'');(directory/'runner.status.json').write_text(json.dumps({'status':'timeout','seconds':300})+'\n');raise
 (directory/'runner.stdout').write_bytes(result.stdout);(directory/'runner.stderr').write_bytes(result.stderr);(directory/'runner.status.json').write_text(json.dumps({'status':'exit','exit_status':result.returncode})+'\n');row['pass']=result.returncode==0 and result.stdout.strip()==b'true' and not result.stderr
 (D/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(row['id'],row['pass'],flush=True);assert row['pass']
assert before==q.t.syntax_validation.implementation_fingerprint();assert all(sha((K/p).read_bytes())==h for p,h in inputs.items())
report={'result':'pass','candidate':str(K),'fingerprint':before,'direct_inputs':inputs,'raw':str(D),'records':records,'assertions':sum(r['assertions'] for r in records),'one_step_budgets':[*range(33),64,128],'full_resume_budgets':[0,1,7,16,32,64,128],'source_default_cuts':'actual DEFAULT_BIND, or DEFAULT_RECEIVE before failed evaluation, minus1 through plus3; each adjacent/full resume with source/heap/call/request roots and saved caller silence mask'};(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(D,report['assertions'])
