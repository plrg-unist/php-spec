from pathlib import Path
import hashlib,io,json,sys,tarfile
R=Path.cwd();D=R/'.tools/compiler7-suppression';sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda b:hashlib.sha256(b).hexdigest()
a=json.loads((D/'archive.json').read_text());assert sha((D/'originals.tar.xz').read_bytes())==a['sha256']
def unpack(blob):
 data={};modes={}
 with tarfile.open(fileobj=io.BytesIO(blob),mode='r|xz') as t:
  for e in t:
   if e.name in ('SHA256.json','MANIFEST.json'):m=json.load(t.extractfile(e));continue
   b=data[e.linkname] if e.islnk() else t.extractfile(e).read();assert sha(b)==m['files'][e.name] and e.mode==m['modes'][e.name];data[e.name]=b;modes[e.name]=e.mode
 assert set(data)==set(m['files'])
 return data,modes,m
def packets(data):
 responses=closures=0
 for n,b in data.items():
  if n.endswith('/close.json'):
   p=n[:-10];assert json.loads(b)=={'status':'exit','exit_status':0,'final_exit_status':0};assert not data[p+'stderr'] and not data[p+'trailing.stdout']
   reqs=[k for k in data if k.startswith(p) and k.endswith('.request')]
   for i in range(len(reqs)):wire.loads(data[p+str(i)+'.request'].decode());assert wire.loads(data[p+str(i)+'.response'].decode())['ok']
   responses+=len(reqs);closures+=1
 return {'responses':responses,'clean_closures':closures}
data,modes,m=unpack((D/'originals.tar.xz').read_bytes());assert len(data)==a['paths']==3515
base=json.loads(data['baseline942/inputs.json']);candidate=json.loads(data['candidate/final-inputs.json'])
for prefix,f in [('baseline942',base),('candidate',candidate)]:
 for n,h in f['files'].items():
  k=prefix+'/'+n
  if k in data:assert sha(data[k])==h and modes[k]==f['modes'][n]
  else:assert m['tools'][k]=={'sha256':h,'mode':f['modes'][n]}
known={(base['files'][p],base['modes'][p]) for p in ['.tools/php/bin/php','.tools/php-file.so','.tools/request-clock.so','_build/default/adapter/main.exe','tests/semantics/_build/default/numeric_runner.exe']}
for n,v in m['tools'].items():assert (v['sha256'],v['mode']) in known,(n,v)
nested=[]
for n,h in a['historical_archives'].items():
 assert sha(data[n])==h
 nd,nm,manifest=unpack(data[n]);nested.append({'archive':n,'sha256':h,'paths':len(nd),'tools':len(manifest.get('tools',{})),**packets(nd)})
 for k,v in manifest.get('tools',{}).items():
  assert (v['sha256'],v['mode']) in known,(n,k,v)
out={'result':'pass','scope':'All compiler archive payloads/hashes/modes and full942/946 source+tool maps; nested retained preparation and send-kind archives independently payload-audited, distinct phases/opcode profiles retained. No paired runtime inference.','archive':a['sha256'],'paths':len(data),'tools':len(m['tools']),'baseline':base['fingerprint'],'candidate':candidate['fingerprint'],**packets(data),'nested':nested,'gates':a['gates'],'raw_boundary':a['raw_boundary']}
(R/'.tools/review10-suppression-compiler-archive-audit.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
