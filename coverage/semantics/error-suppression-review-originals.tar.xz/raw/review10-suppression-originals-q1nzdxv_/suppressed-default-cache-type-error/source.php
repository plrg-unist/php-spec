<?php
const C="2x";function f(array $x=C+1){}
@f();echo "AFTER";