<?php
const C=1;function f($x=C/0){}
@f();echo "AFTER";