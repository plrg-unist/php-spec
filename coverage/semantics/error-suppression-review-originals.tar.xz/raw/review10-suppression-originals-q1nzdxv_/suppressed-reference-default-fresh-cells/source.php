<?php
const C="2x";function f(&$x=C+1){$x++;echo $x;}
@f();@f();echo $missing;