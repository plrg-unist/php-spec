from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile
R=Path.cwd();K=Path(sys.argv[1]).resolve(); repaired='--repaired' in sys.argv
sys.path.insert(0,str(K/'tests/semantics'))
import request_environment as q
import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-suppression-protocol-',dir=R/'.tools'));print(D,flush=True)
(D/'producer.py').write_bytes(Path(__file__).read_bytes());before=q.t.syntax_validation.implementation_fingerprint()
modules=[K/n for n in json.loads((K/'spec/semantics/modules.json').read_text())];runner=K/'tests/semantics/_build/default/numeric_runner.exe'
(D/'inputs.json').write_text(json.dumps({'fingerprint':before,'candidate':str(K)},indent=2))
old=json.loads((R/'.tools/review10-suppression-originals-q1nzdxv_/report.json').read_text())['records'][0]
f=ad=None
try:
 f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire');ad=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 parsed=f.request({'op':'parse','source':old['source_base64']});assert parsed['accepted'];checked=ad.request({'op':'check','ast':parsed['ast'],'fixture':True});(D/'checked.json').write_text(json.dumps(checked));(D/'original.json').write_text(json.dumps(old,indent=2))
finally:
 try:
  if f:f.close()
 finally:
  if ad:ad.close()
initial='$php_request_run('+checked['fixture']+', 0, '+json.dumps(q.b64(os.fsencode(old['context'])))+', '+rs.request_fixture(old['request'])+')'
PREFIX='''dec $review_stage(pstate) : bool
 def $review_stage(S) = true -- if S.TODO = (SILENCE_END porigin) :: ptask*
 def $review_stage(S) = false -- otherwise
 dec $review_find(pstate, nat) : pstate
 def $review_find(S, n) = S -- if $review_stage(S)
 def $review_find(S, n) = $review_find(S_next[.COMPLETION = NORMAL], n_rest)
   -- if ~$review_stage(S)
   -- if $(n > 0)
   -- if n_rest = $(n - 1)
   -- if S_next = $drive_steps(S, 1)
'''
common=['S_initial = '+initial,'S = $review_find(S_initial[.COMPLETION = NORMAL], 200)','S.TODO = (SILENCE_END porigin) :: ptask*','S.SILENCES = [SILENCE porigin i_saved]','S.REPORTING = 4437','i_saved = 30719','S.ORIGIN = (porigin)','porigin_child = $origin_child((porigin), [PCFIELD 0])','porigin_child = (porigin_bad)','$call_descriptors_valid(S)']
variants=[('control','S',True,30719),('missing-scope','S[.SILENCES = eps]',False,None),('wrong-scope-source','S[.SILENCES = [SILENCE porigin_bad i_saved]]',False,None),('wrong-end-source','S[.TODO = (SILENCE_END porigin_bad) :: ptask*]',False,None),('wrong-current-origin','S[.ORIGIN = (porigin_bad)]',False,None),('huge-current-mask','S[.REPORTING = 9223372036854775808]',False,None),('huge-saved-mask','S[.SILENCES = [SILENCE porigin 9223372036854775808]]',False,None),('arbitrary-live-mask','S[.REPORTING = 2]',True,2),('arbitrary-saved-mask','S[.SILENCES = [SILENCE porigin $(-1)]]',True,-1),('fatal-only-saved-mask','S[.SILENCES = [SILENCE porigin 0]]',True,4437),('arbitrary-owning-value','S[.RESULT = KNOWN (PINT 99)]',True,30719)]
if os.environ.get('FRAME'):
 PREFIX=PREFIX.replace('S.TODO = (SILENCE_END porigin) :: ptask*','S.TODO = (DEFAULT_BIND porigin n) :: ptask*')
 common=['S_initial = '+initial,'S = $review_find(S_initial[.COMPLETION = NORMAL], 200)','S.TODO = (DEFAULT_BIND porigin n) :: ptask*','S.SILENCES = eps','S.FRAMES = pframe :: pframe_tail*','pframe.SILENCES = [SILENCE porigin_silence i_saved]','S.REPORTING = 4437','i_saved = 30719','porigin_child = $origin_child((porigin_silence), [PCFIELD 0])','porigin_child = (porigin_bad)','$call_descriptors_valid(S)']
 variants=[('saved-control','S',True,None),('saved-missing-scope','S[.FRAMES = pframe[.SILENCES = eps] :: pframe_tail*]',False,None),('saved-wrong-source','S[.FRAMES = pframe[.SILENCES = [SILENCE porigin_bad i_saved]] :: pframe_tail*]',False,None),('saved-huge-mask','S[.FRAMES = pframe[.SILENCES = [SILENCE porigin_silence 9223372036854775808]] :: pframe_tail*]',False,None),('saved-arbitrary-mask','S[.FRAMES = pframe[.SILENCES = [SILENCE porigin_silence $(-1)]] :: pframe_tail*]',True,None),('cross-frame-scope','S[.SILENCES = pframe.SILENCES][.FRAMES = pframe[.SILENCES = eps] :: pframe_tail*]',False,None)]
records=[]
for name,change,valid,mask in variants:
 if os.environ.get("ONLY") and name not in os.environ["ONLY"].split(","):continue
 expected=valid or not repaired
 checks=common+['S_changed = '+change,'$heap_valid($heap_graph(S_changed))','$call_descriptors_valid(S_changed) = '+str(expected).lower(),'S_zero = $drive(S_changed, 0)','S_zero.COMPLETION = '+('BUDGET' if expected else 'UNSUPPORTED "invalid compiled function descriptor"')]
 if valid and mask is not None:
  checks+=['S_next = $drive_steps(S_changed, 1)','S_next.REPORTING = '+('$(%d)'%mask if mask<0 else str(mask)),'S_next.SILENCES = eps','S_full = $drive(S_changed, 10000)','S_full.COMPLETION = NORMAL','S_full.REPORTING = '+('$(%d)'%mask if mask<0 else str(mask)),'$heap_valid($heap_graph(S_full))']
 if valid and mask is None:
  checks+=['S_full = $drive(S_changed, 10000)','S_full.COMPLETION = NORMAL','S_full.REPORTING = '+('$(-1)' if name=='saved-arbitrary-mask' else '30719'),'$heap_valid($heap_graph(S_full))']
 fixture=D/(name+'.watsup');fixture.write_text(PREFIX+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+c+'\n' for c in checks));cmd=[str(runner),*map(str,modules),str(fixture)];(D/(name+'.command.json')).write_text(json.dumps(cmd))
 try:r=subprocess.run(cmd,capture_output=True,timeout=60)
 except subprocess.TimeoutExpired as e:
  (D/(name+'.stdout')).write_bytes(e.stdout or b'');(D/(name+'.stderr')).write_bytes(e.stderr or b'');(D/(name+'.status.json')).write_text(json.dumps({'status':'timeout'}));raise
 (D/(name+'.stdout')).write_bytes(r.stdout);(D/(name+'.stderr')).write_bytes(r.stderr);(D/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));row={'id':name,'contract_valid':valid,'original_admission':not repaired and not valid,'assertions':len(checks),'pass':r.returncode==0 and r.stdout.strip()==b'true' and not r.stderr};records.append(row);(D/'results.json').write_text(json.dumps(records,indent=2));print(row,flush=True)
assert before==q.t.syntax_validation.implementation_fingerprint()
(D/'report.json').write_text(json.dumps({'result':'pass' if all(r['pass'] for r in records) else 'fail','fingerprint':before,'raw':str(D),'repaired':repaired,'records':records},indent=2))
