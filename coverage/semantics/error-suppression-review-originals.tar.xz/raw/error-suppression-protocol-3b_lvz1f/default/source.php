<?php
const C="2x";function f($x=C+1){echo $x;}
@f();f();echo $missing;