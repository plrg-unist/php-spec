from pathlib import Path
import json,subprocess,tempfile,hashlib,sys
D=Path(__file__).resolve().parent
out=Path(tempfile.mkdtemp(prefix='compiler-check-',dir=D/'.tools'));print(out,flush=True)
modules=json.loads((D/'spec/semantics/modules.json').read_text())
inputs={p:hashlib.sha256((D/p).read_bytes()).hexdigest() for p in modules+['tests/semantics/_build/default/numeric_runner.exe']}
(out/'inputs.json').write_text(json.dumps(inputs,indent=2))
rows=[]
for dirname in ['protocol-originals-t4n3iup7','protocol-originals-bqqvhdd1','protocol-originals-tr3pg_vc']:
 original=D.parent/'compiler5-call-protocol/.tools'/dirname
 for path in sorted(original.glob('*/compiler-state.watsup')):
  case=out/path.parent.name;case.mkdir();command=[str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/p) for p in modules],str(path)]
  (case/'command.json').write_text(json.dumps(command));(case/'original.json').write_text(json.dumps({'fixture':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest()}))
  try:r=subprocess.run(command,capture_output=True,timeout=25)
  except subprocess.TimeoutExpired as e:
   (case/'stdout').write_bytes(e.stdout or b'');(case/'stderr').write_bytes(e.stderr or b'');(case/'status.json').write_text(json.dumps({'status':'timeout'}));raise
  (case/'stdout').write_bytes(r.stdout);(case/'stderr').write_bytes(r.stderr);(case/'status.json').write_text(json.dumps({'status':'exit','exit_status':r.returncode}))
  if r.returncode or r.stderr:print(path.parent.name,r.returncode,r.stderr.decode(),flush=True);sys.exit(1)
  completion=[s for s in r.stdout.decode().splitlines() if s.startswith('  COMPLETION')]
  rows.append({'id':path.parent.name,'completion':completion});(out/'results.json').write_text(json.dumps(rows,indent=2));print(path.parent.name,completion,flush=True)
assert all(hashlib.sha256((D/p).read_bytes()).hexdigest()==h for p,h in inputs.items())
