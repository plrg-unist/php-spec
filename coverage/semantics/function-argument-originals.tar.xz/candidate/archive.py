from pathlib import Path
import hashlib,io,json,tarfile,difflib
D=Path(__file__).resolve().parent;C=D.parents[1];O=D.parent/'compiler5-call-protocol'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
baseline=json.loads((D/'baseline-inputs.json').read_text())['files']
extra=['spec/semantics/25-builtin-argument-modes.watsup','scripts/generate-builtin-argument-modes.py','tests/semantics/function_argument_compiler.py','tests/semantics/function_argument_cases.json','tests/semantics/builtin_argument_modes.py','docs/semantics/FUNCTION-ARGUMENT-MODES.md','coverage/semantics/builtin-argument-modes.json','coverage/semantics/builtin-argument-modes-test.json','coverage/semantics/function-argument-compiler.json']
final={p:digest(D/p) for p in sorted(set(baseline)|set(extra))}
(D/'final-inputs.json').write_text(json.dumps(final,indent=2)+'\n')
delta={};patch=[]
for p,h in final.items():
 if h!=baseline.get(p) and not p.startswith('coverage/'):
  delta[p]={'before':baseline.get(p),'after':h}
  old=(O/p).read_text() if p in baseline else ''
  patch.extend(difflib.unified_diff(old.splitlines(True),(D/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p))
(D/'argument-delta.json').write_text(json.dumps(delta,indent=2)+'\n');(D/'argument-delta.patch').write_text(''.join(patch))
files={}
for p in baseline:files['initial/'+p]=O/p
for p in final:files['candidate/'+p]=D/p
for root,label in [(O,'initial'),(D,'candidate')]:
 for rel in ['baseline-inputs.json','semantics-reference-inputs.json','originals.py','NEXT-PROTOCOL-PREPARATION.md','check.py','builtin-check.py','final-inputs.json','argument-delta.json','argument-delta.patch','archive.py']:
  if (root/rel).is_file():files[label+'/'+rel]=root/rel
 for p in (root/'.tools').rglob('*'):
  if p.is_file() and p.relative_to(root/'.tools').parts[0].startswith(('protocol-originals-','compiler-check-','builtin-modes-check-','function-argument-compiler-')):files[label+'/'+str(p.relative_to(root))]=p
for p in (D/'retired-helper-declaration').rglob('*'):
 if p.is_file():files['candidate/'+str(p.relative_to(D))]=p
report=json.loads((D/'coverage/semantics/builtin-argument-modes.json').read_text())
for p,h in report['inputs'].items():
 assert digest(C/p)==h,p;files['producer/'+p]=C/p
files['producer/scripts/generate-builtin-functions.py']=C/'scripts/generate-builtin-functions.py'
for p in (C/report['raw']).rglob('*'):
 if p.is_file():files['producer/'+str(p.relative_to(C))]=p
# Exact executed binary bytes are already durable in the scope author archive.
external=json.loads((D.parent/'compiler5-function-final/coverage/semantics/function-compiler-originals.json').read_text())['executed_tools']
bindings={v['archive_path']:v['sha256'] for v in external['files'].values()}
archive=D.parent/'compiler5-superglobals'/external['archive'];assert digest(archive)==external['sha256']
with tarfile.open(archive,'r:xz') as tar:
 for p,h in bindings.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h
omitted={}
for p in list(files):
 rel=p.split('/',1)[1]
 if rel in bindings:
  assert digest(files[p])==bindings[rel],p;omitted[p]={'archive_path':rel,'sha256':bindings[rel]};del files[p]
hashes={p:digest(f) for p,f in sorted(files.items())}
manifest={'files':hashes,'external_tools':{'archive':external['archive'],'sha256':external['sha256'],'files':omitted}}
name='coverage/semantics/function-argument-originals.tar.xz';target=D/name;seen={}
with tarfile.open(target,'w:xz',preset=6) as tar:
 b=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(b);tar.addfile(info,io.BytesIO(b))
 for p,f in sorted(files.items()):
  h=hashes[p];info=tar.gettarinfo(str(f),arcname=p);info.uid=info.gid=0;info.uname=info.gname='';info.mtime=0
  if h in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[h];info.size=0;tar.addfile(info)
  else:
   seen[h]=p
   with f.open('rb') as stream:tar.addfile(info,stream)
with tarfile.open(target,'r:xz') as tar:
 for p,h in hashes.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h,p
out={'archive':name,'sha256':digest(target),'bytes':target.stat().st_size,'paths':len(files),'unique_contents':len(seen),'executed_tools':manifest['external_tools'],'scope':'114 retained preparation/original observations; compiler repair32 exact phases and21 context assertions; source-derived780 builtin argument rows and7508 pure checks. Runtime pairing and independent acceptance are separate.','notes':['SpecTec declaration-order load failure exact prior module retained with original recorded hash.','Two descriptor-fixture syntax failures remain exact fixtures and raw outputs; corrected only handwritten fixture binder syntax.','Print-expression preparation controls remain Unsupported; call-helper effect sources are separately retained and compile normally.']}
(D/'coverage/semantics/function-argument-originals.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
assert final=={p:digest(D/p) for p in final}
