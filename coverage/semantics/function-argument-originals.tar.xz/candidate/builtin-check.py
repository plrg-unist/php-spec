from pathlib import Path
import base64,hashlib,json,subprocess,sys,tempfile
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'));import static_types as t
out=Path(tempfile.mkdtemp(prefix='builtin-modes-check-',dir=D/'.tools'));print(out,flush=True)
report=json.loads((D/'coverage/semantics/builtin-argument-modes.json').read_text());records=report['arguments']
source=out/'metadata.php';source.write_text('''<?php
$r=[];
foreach(get_defined_functions()["internal"] as $n) {
 $f=new ReflectionFunction($n);$p=[];
 foreach($f->getParameters() as $a) $p[]=["name"=>$a->getName(),"send_mode"=>$a->isPassedByReference()?($a->canBePassedByValue()?2:1):0,"variadic"=>$a->isVariadic()];
 $r[$n]=$p;
}
echo json_encode($r);
''')
def run(command,label):
 (out/(label+'.command.json')).write_text(json.dumps(command))
 try:r=subprocess.run(command,capture_output=True,env=t.ENV,timeout=40)
 except subprocess.TimeoutExpired as e:
  (out/(label+'.stdout')).write_bytes(e.stdout or b'');(out/(label+'.stderr')).write_bytes(e.stderr or b'');(out/(label+'.status.json')).write_text(json.dumps({'status':'timeout'}));raise
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);(out/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}))
 assert r.returncode==0 and not r.stderr,(r.returncode,r.stderr)
 return r.stdout
native=json.loads(run([str(t.PHP),'-n',*t.FLAGS,str(source)],'native'))
assert native=={r['name']:r['parameters'] for r in records},[(r['name'],native.get(r['name']),r['parameters']) for r in records if native.get(r['name'])!=r['parameters']]
lines=[];count=0
for r in records:
 p=r['parameters']
 for i in range(len(p)+3):
  expected=bool(i and (p[i-1]['send_mode'] if i<=len(p) else p[-1]['send_mode'] if p and p[-1]['variadic'] else False))
  for name in [r['name'],r['name'].upper()]:
   lines.append('($pfunction_builtin_ref('+t.byte_expr(name)+', '+str(i)+') = '+str(expected).lower()+')');count+=1
fixture=out/'modes.watsup';fixture.write_text('dec $main() : bool\ndef $main() = '+' /\\\n '.join(lines)+'\n')
modules=json.loads((D/'spec/semantics/modules.json').read_text());actual=run([str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/p) for p in modules],str(fixture)],'spectec');assert actual.strip()==b'true',actual
(out/'result.json').write_text(json.dumps({'signatures':len(records),'assertions':count,'native_exact':True,'spectec':True},indent=2));print(len(records),count,flush=True)
