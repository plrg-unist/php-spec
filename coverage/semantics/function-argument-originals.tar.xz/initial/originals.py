from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,tempfile,signal
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'));import static_types as t
CASES={
'param-byref-alias':'function f(&$x){$x=3;} $a=1;f($a);echo $a;',
'param-byref-constant':'function f(&$x){echo "body";} f(1);',
'param-byref-call-value':'function g(){return 1;} function f(&$x){echo "body",$x;} f(g());',
'param-byref-call-reference':'$a=1;function &g(){global $a;return $a;}function f(&$x){$x=3;}f(g());echo $a;',
'param-byref-globals':'function f(&$x){echo "body";}f($GLOBALS);',
'param-byref-unset-later':'function f(&$a,$b){$a=3;echo $a;} $x=1; f($x, $x=2);echo $x;',
'return-ref-missing':'function &f(){return $x;} $a=&f();$a=2;echo $a;',
'return-ref-temporary':'function &f(){return 1;} $a=&f();echo $a;',
'return-ref-value-consumer':'$x=1;function &f(){global $x;return $x;} $a=f();$a=3;echo $x,$a;',
'return-void-value':'function f():void {return 1;}',
'return-void-null':'function f():void {return null;}',
'return-void-dead':'function f():void {if(false){return 1;}}',
'return-never-empty':'function f():never {return;}',
'return-never-fallthrough':'function f():never {} f();',
'return-int-empty':'function f():int {return;}',
'return-int-fallthrough':'function f():int {} f();',
'default-array-copy':'function f($a=[1+2]){$a[0]++;echo $a[0];} f();f();',
'default-invalid-key':'function f($a=[[]=>1]){break;}',
'default-undefined-unused':'function f($a=NOT_DEFINED){} echo "after";',
'default-undefined-called':'function f($a=NOT_DEFINED){echo "body";} f();',
'default-namespace-magic':'namespace N;function f($a=__FUNCTION__, $b=__NAMESPACE__){echo $a,"/",$b;} f();',
'default-typed-array':'function f(int $a=[1]) {break;}',
'default-typed-null':'function f(int $a=null){echo $a===null;}f();',
'default-required-after-optional':'function f($a=1,$b){echo $a,$b;}f(b:2);',
'default-null-before-required':'function f(int $a=null,$b){echo $a===null,$b;}f(b:2);',
'parameter-returntype-priority':'function f($x,$x):void|int {}',
'parameter-default-priority':'function f($a=[[]=>1],$a){}',
'parameter-autoglobal-default-priority':'function f($_ENV=[[]=>1]){}',
'variadic-positional':'function f($a,...$rest){echo $a,$rest[0],$rest[1];}f(1,2,3);',
'variadic-named':'function f($a,...$rest){echo $a,$rest["last"],$rest["first"];}f(first:2,a:1,last:3);',
'variadic-byref':'function f(&...$rest){$rest[0]=3;$rest["x"]=4;} $a=1;$b=2;f($a,x:$b);echo $a,$b;',
'variadic-default-invalid':'function f(...$a=[]){}',
'variadic-nonlast':'function f(...$a,$b){}',
'named-order':'function f($a,$b){echo $a,$b;}f(b:($x=2),a:($x=1));echo $x;',
'named-unknown-effects':'function f($a){echo "body";} f(wrong:print "arg");',
'named-duplicate-effects':'function f($a){echo "body";} f(a:print "one",a:print "two");',
'named-positional-priority':'f(a:1, [,2]);',
'named-prior-arg-fatal':'f([,1], a:2);',
'named-unpack-priority':'f(a:1,...[,2]);',
'named-unpack-valid':'function f($a,$b){echo $a,$b;}f(...[1],b:2);',
'unpack-positional-priority':'f(...[], [,2]);',
'unpack-string-then-int':'function f(...$v){echo "body";}f(...["x"=>1,0=>2]);',
'unpack-duplicate-name':'function f($x){echo "body";}f(...["x"=>1],x:print "later");',
'unpack-nonarray':'function f(...$v){echo "body";} f(...3);',
'unpack-byref-array':'function f(&$x){$x=3;} $a=[1];f(...$a);echo $a[0];',
'unpack-byref-temporary':'function f(&$x){$x=3;echo $x;} f(...[1]);',
'unpack-reference-member':'function f($x){$x=3;} $x=1;$a=[&$x];f(...$a);echo $x;',
'weak-parameter':'function f(int $x){echo $x;}f("12");',
'strict-parameter':'declare(strict_types=1);function f(int $x){echo $x;}f("12");',
'weak-return':'function f():int{return "12";}echo f();',
'strict-return':'declare(strict_types=1);function f():int{return "12";}echo f();',
'float-int-strict':'declare(strict_types=1);function f(float $x):float{return 3;}echo f(2);',
'weak-ref-coercion':'function f(int &$x){echo $x;} $x="2";f($x);echo $x===2;',
'weak-union-priority':'function f(int|bool $x){echo $x===true?"bool":"int";}f("2");',
'nullable-parameter':'function f(?int $x){echo $x===null;}f(null);',
'closure-value':'$x=1;$f=function()use($x){return $x;};$x=2;echo $f();',
'closure-reference':'$x=1;$f=function()use(&$x){return ++$x;};echo $f(),$x;',
'arrow-value':'$x=1;$f=fn()=>$x;$x=2;echo $f();',
'firstclass-function':'function f($x){return $x+1;}$c=f(...);echo $c(2);',
'dynamic-function-name':'function f($x){return $x+1;}$c="F";echo $c(2);',
'dynamic-namespace-name':'namespace N;function f(){echo "N";}$c="f";$c();',
'function-static':'function f(){static $x=0;return ++$x;}echo f(),f();',
}
CASES.update({'known-value-append': 'function f($x){} f($a[]);', 'forward-value-append': 'f($a[]);function f($x){}', 'known-reference-append': 'function f(&$x){$x=3;}f($a[]);echo $a[0];', 'forward-reference-append': 'f($a[]);function f(&$x){$x=3;}echo $a[0];', 'conditional-value-append': 'if(true){function f($x){}}f($a[]);', 'builtin-reference-append': 'sort($a[]);', 'builtin-value-append': 'strlen($a[]);', 'default-built-in-constant-type': 'function f(int $x=PHP_VERSION){echo $x;}echo "before";f();', 'default-built-in-constant-unused': 'function f(int $x=PHP_VERSION){}echo "after";', 'default-nonconstant': 'function f($x=(1+foo())){}', 'default-constant-array-invalid-key': 'function f($x=[PHP_VERSION=>1]){echo $x[PHP_VERSION];}f();', 'default-unresolved-array-key': 'function f($x=[UNKNOWN_CONSTANT=>1]){}echo "after";', 'default-reference-array-copy': 'function f(&$x=[1]){$x[0]++;echo $x[0];}f();f();', 'byref-variable-name-warning': 'function f(&$x){$x=3;}f($$u);echo ${""};', 'named-reference-append': 'function f(&$x){$x=3;}f(x:$a[]);echo $a[0];', 'named-unknown-append': 'function f(&$x){}f(wrong:$a[]);', 'byref-return-compile-read': 'function &f(){return $a[];} $x=&f();$x=3;echo $x;', 'byref-return-nullsafe': 'function &f(){return $a?->x;}', 'void-return-expression-priority': 'function f():void{return [,1];}', 'never-return-expression-priority': 'function f():never{return [,1];}'})
CASES.update({'deferred-direct': 'echo "before";f($a[]);function f($x){}', 'deferred-undefined-target': 'missing($a[]);', 'deferred-dynamic-name': 'f(${$n}[]);function f($x){}', 'deferred-name-effects': 'f(${print "name"}[]);function f($x){}', 'deferred-nested-outer-key': 'f($a[][print "key"]);function f($x){}', 'deferred-inner-key': 'f($a[print "key"][]);function f($x){}', 'deferred-call-base': 'function g(){echo "base";return [];}f(g()[]);function f($x){}', 'deferred-array-base': 'f([print "base"][]);function f($x){}', 'deferred-earlier-argument': 'f(print "first",$a[],print "last");function f($x,$y,$z){}', 'deferred-early-runtime-error': 'f(1/0,$a[]);function f($x,$y){}', 'deferred-later-static-error': 'f($a[],$GLOBALS=1);function f($x,$y){}', 'recursive-self': 'function f($x){if($x){f($a[]);}}f(1);', 'recursive-mutual': 'function f(){g($a[]);}function g($x){f($b[]);}f();', 'namespace-fallback': 'namespace N;function f($x){}f($a[]);', 'namespace-qualified': 'namespace N;function f($x){}\\N\\f($a[]);', 'deferred-header-direct': 'f($http_response_header);echo $http_response_header;function f($x){}', 'deferred-header-dimension': 'f($http_response_header[0]);echo $http_response_header;function f($x){}', 'deferred-header-computed': 'f(${"http_response_"."header"});echo $http_response_header;function f($x){}', 'known-header-computed': 'function f($x){}f(${"http_response_"."header"});echo $http_response_header;'})
CASES.update({'deferred-outer-key-call': 'function keyfn(){echo "key";return 0;}f($a[][keyfn()]);function f($x){}', 'deferred-inner-key-call': 'function keyfn(){echo "key";return 0;}f($a[keyfn()][]);function f($x){}', 'deferred-dynamic-name-call': 'function namefn(){echo "name";return "a";}f(${namefn()}[]);function f($x){}', 'deferred-array-base-call': 'function basefn(){echo "base";return 1;}f([basefn()][]);function f($x){}', 'deferred-argument-effects-call': 'function argfn($v){echo $v;return $v;}f(argfn("first"),$a[],argfn("last"));function f($x,$y,$z){}', 'deferred-header-magic': 'function http_response_header(){f(${__FUNCTION__});echo $http_response_header;}function f($x){}http_response_header();', 'known-header-magic': 'function f($x){}function http_response_header(){f(${__FUNCTION__});echo $http_response_header;}http_response_header();', 'builtin-header-ref': 'sort($http_response_header);echo $http_response_header;', 'builtin-prefer-ref': 'array_multisort($a[]);', 'builtin-reference-later-static': 'sort($a[], $GLOBALS=1);', 'deferred-skipped-self': 'function f(){if(false){f($a[]);}}echo "ok";', 'deferred-skipped-forward': 'function f(){if(false){g($a[]);}}function g($x){}echo "ok";', 'known-import-target': 'namespace N;function f($x){}use function N\\f as g;g($a[]);'})
if len(sys.argv)>1:CASES={k:v for k,v in CASES.items() if k in sys.argv[1:]}

def invoke(command,out,label):
 (out/(label+'.command.json')).write_text(json.dumps(command))
 try:r=subprocess.run(command,capture_output=True,env=t.ENV,timeout=20)
 except subprocess.TimeoutExpired as e:
  (out/(label+'.stdout')).write_bytes(e.stdout or b'');(out/(label+'.stderr')).write_bytes(e.stderr or b'');(out/(label+'.status.json')).write_text(json.dumps({'status':'timeout','seconds':20}));raise
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);(out/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}))
 return {'stdout':base64.b64encode(r.stdout).decode(),'stderr':base64.b64encode(r.stderr).decode(),'exit_status':r.returncode,'command':command}

out=Path(tempfile.mkdtemp(prefix='protocol-originals-',dir=D/'.tools'));rows=[];manifest=json.loads((D/'baseline-inputs.json').read_text())
for rel,h in manifest['files'].items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==h,rel
f=t.Worker([str(t.PHP),'-n',*t.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')]);a=t.Worker([str(D/'_build/default/adapter/main.exe'),str(D)])
print(out,flush=True)
try:
 for name,body in CASES.items():
  case=out/name;case.mkdir();source=('<?php '+body).encode();path=case/'source.php';path.write_bytes(source)
  row={'id':name,'source_base64':base64.b64encode(source).decode(),'file':str(path),'lint':invoke([str(t.PHP),'-n',*t.FLAGS,'-l',str(path)],case,'lint'),'native':invoke([str(t.PHP),'-n',*t.FLAGS,str(path)],case,'native')}
  parsed=f.request({'op':'parse','source':row['source_base64']});(case/'parsed.json').write_text(json.dumps(parsed));row['parsed']=parsed.get('accepted',False)
  if parsed.get('accepted'):
   checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(case/'checked.json').write_text(json.dumps(checked));assert checked['ok'],checked
   fixture=case/'compiler-state.watsup';fixture.write_text('dec $main() : ppstate\ndef $main() = $ppstart(91, '+checked['fixture']+', '+t.byte_expr(str(path))+')\n')
   row['compiler']=invoke([str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/r) for r in json.loads((D/'spec/semantics/modules.json').read_text())],str(fixture)],case,'compiler')
   request={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':base64.b64encode(str(path).encode()).decode()};(case/'execute-input.json').write_text(json.dumps(request));result=a.request(request);(case/'runtime-state.json').write_text(json.dumps(result));row['runtime_state']=str(case/'runtime-state.json')
  rows.append(row);(out/'records.json').write_text(json.dumps({'scope':'Original source/compile/runtime states before next call-protocol implementation; Unsupported and tool failures are not agreements.','baseline':manifest,'records':rows},indent=2));print(name,'lint',row['lint']['exit_status'],'native',row['native']['exit_status'],flush=True)
finally:f.close();a.close()
assert all(hashlib.sha256((D/rel).read_bytes()).hexdigest()==h for rel,h in manifest['files'].items())
