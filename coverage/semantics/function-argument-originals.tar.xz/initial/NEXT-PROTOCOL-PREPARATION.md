# Next callable protocol preparation

Preparation only. First plain-call publication must first repair deferred
argument fetch compilation and pair it with actual runtime behavior. No next-stage
signature or callable source activation has been made here.

Originals are preserved with exact source, native lint and execution commands,
raw stdout/stderr/status, checked AST, full old ppstate and full old runtime state:
62 initial cases in `.tools/protocol-originals-4j2q4qo4`, 20 additional cases in
`.tools/protocol-originals-t4n3iup7`, 19 timing/ordering cases in
`.tools/protocol-originals-bqqvhdd1`, and 13 admitted call-helper effect controls in
`.tools/protocol-originals-tr3pg_vc`. The producer root is this private directory;
`baseline-inputs.json` binds 872 original watched files. These are observations,
not an agreement count. Some print-expression probes are explicitly Unsupported
by the old compiler; call-helper controls retain the corresponding effects using
already admitted source forms.

Proposed coherent milestones after first-call acceptance:

1. Positional references, default materialization and parameter/return types.
   Keep the existing `pssignature`/`psparam` normalization and declared original
   default syntax. Extend the shared default staging interface with the actual
   constant compiler result rather than copying its type or constant rules.
   The compiler must visit return expressions before return-type static checks,
   preserve declaration-time parameter diagnostic priority, and retain returned
   value versus reference modes. Runtime sends actual location/reference roots,
   binds in parameter order, evaluates omitted defaults in callee context, then
   enforces types. Caller strictness controls scalar arguments; body strictness
   controls returns. Default arrays must be fresh containers per invocation,
   including reference defaults. Undefined default constants throw only when
   materialized. Literal bad defaults may fail compilation; even known named
   constants such as PHP_VERSION remain deferred under the pinned no-substitution
   flags. Required-after-optional parameters lose their defaults at normalization.

2. Named arguments, unpacking and variadics on the same send/receive protocol.
   Preserve syntactic named/unpack ordering errors before compiling the current
   offending operand, and preserve earlier operand errors. Duplicate or unknown
   names can throw only after that argument's effects. Preserve array insertion
   order, integer/string key rules and by-reference array-member behavior during
   unpack. Variable arrays separate before creating required member references;
   temporary arrays create fresh references. Callable target remains selected
   before all sends. Iterator-object unpack belongs to the object protocol.

3. Closures/arrows, captures, dynamic and first-class function callables, statics.
   Keep an actual callable identity and owned capture roots, with fresh invocation
   locals. Closure capture copies and aliases follow existing heap ownership.
   Source function statics persist through invocations and need actual reference
   storage. Dynamic string names do not inherit lexical namespace fallback.
   Object-bound callables remain tied to object activation, with exact pending
   originals, rather than fabricated object lookup.

Pinned source routes: zend_compile.c compile_params/compile_return/compile_args/
compile_call; zend_execute.c check_type_slow and scalar enforcement;
zend_vm_def.h SEND_REF/SEND_VAR_NO_REF/SEND_UNPACK/RECV_INIT/VERIFY_RETURN_TYPE.
The first-scope CODEARG descriptor stores compiler fetch choice separately from
runtime selected callable identity; it is reusable for the later reference modes.
The source-audited builtin arginfo prerequisite exposes positional flags now;
name/required/default/type metadata should extend that same provenance when the
later named and intrinsic work needs it.

Unresolved implementation interface to settle before step 1: represent known
constant default values and unresolved constant-expression continuations in the
existing psdefault result without bypassing original source unit/path, magic
context, diagnostics or request-wide constant pools. Preserve full old state
before any correction. All milestones need actual source compilation, invocation,
return/error cleanup and suspension tests, not helper-only acceptance.
