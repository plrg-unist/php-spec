<?php
function g():int{return 2;}
function f():int{return g();}
echo f();