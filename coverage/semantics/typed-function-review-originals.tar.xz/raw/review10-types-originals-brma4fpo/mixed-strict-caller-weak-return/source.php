<?php
declare(ticks=0){function weak():int{return "2";}}
declare(strict_types=1);
echo weak();