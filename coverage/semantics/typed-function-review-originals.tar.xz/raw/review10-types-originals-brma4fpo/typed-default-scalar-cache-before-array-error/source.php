<?php
const C=3;
function f(array $x=C){echo "BODY";}
f();