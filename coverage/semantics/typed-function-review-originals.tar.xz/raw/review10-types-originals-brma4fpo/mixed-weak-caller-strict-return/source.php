<?php
declare(ticks=0){function weak(){return f();}}
declare(strict_types=1);
function f():int{return "2";}
echo weak();