<?php
function f():int{$a=[1];$b=&$a[0];return $a;}
f();