<?php
const C=[];
function f(int $x=C[0]){echo "BODY";}
f();