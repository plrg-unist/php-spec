<?php
function f():int{global $a;$a=[1];$b=&$a[0];return $a;}
f();