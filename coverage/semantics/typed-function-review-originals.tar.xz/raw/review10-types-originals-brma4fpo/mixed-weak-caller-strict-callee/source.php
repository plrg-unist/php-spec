<?php
declare(ticks=0){function weak(){return f("2");}}
declare(strict_types=1);
function f(int $x){return $x;}
echo weak();