from pathlib import Path
import argparse,hashlib,json,subprocess,sys,tempfile
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--original',action='store_true');ap.add_argument('--match',default='');ap.add_argument('--variant',default='');a=ap.parse_args();R=Path.cwd();K=a.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q;import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-types-protocol-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes());rows={}
for p in ['.tools/review10-types-nested-originals-4jnh3zul/report.json','.tools/review10-types-originals-brma4fpo/report.json','.tools/review10-types-return-alias-originals-ixu_0zfk/report.json','.tools/runtime6-typed-calls/.tools/typed-runtime-originals-yhkn18j6/report.json']:
 for r in json.load(open(p))['records']:rows[r['id']]=r
before=q.t.syntax_validation.implementation_fingerprint();modules=[K/p for p in json.load(open(K/'spec/semantics/modules.json'))];runner=K/'tests/semantics/_build/default/numeric_runner.exe';paths=[*modules,runner,K/'_build/default/adapter/main.exe',q.t.PHP,K/'.tools/php-file.so',K/'tests/semantics/recorded_worker.py'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();direct={str(p.relative_to(K)):sha(p) for p in paths};(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'closure':before,'direct':direct},indent=2))
for p in paths:
 o=D/'original-inputs'/p.relative_to(K);o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(p.read_bytes())
f=ad=None;records=[];fixtures=[]
selections=[('typed-default-scalar-cache-before-array-error','receive','TYPE_RECEIVE porigin n'),('return-mixed-fallthrough','fallthrough','TYPE_FALLTHROUGH porigin'),('typed-value-return-global-alias-copy','return','RETURN_VALUE z'),('typed-return-array-global-owner','return','RETURN_VALUE z'),('typed-nested-return-context','return','RETURN_VALUE z')]
selections=[r for r in selections if a.match in r[0]]
try:
 f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire');ad=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for name,stage,pattern in selections:
  row=rows[name];d=D/name;d.mkdir();(d/'original.json').write_text(json.dumps(row));p=f.request({'op':'parse','source':row['source_base64']});assert p['accepted'];c=ad.request({'op':'check','ast':p['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(c));out=ad.request({'op':'execute','ast':p['ast'],'steps':10000,'filename':q.b64(row['context'].encode()),'request':row['request']});(d/'state.json').write_text(json.dumps(out));actual=q.cli.observe(out['state'],row['context']);assert all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  initial='$php_request_run('+c['fixture']+', 0, '+json.dumps(q.b64(row['context'].encode()))+', '+rs.request_fixture(row['request'])+')'
  prefix='dec $review_type_stage(pstate) : bool\ndef $review_type_stage(S) = true\n  -- if S.TODO = ('+pattern+') :: ptask*\ndef $review_type_stage(S) = false -- otherwise\ndec $review_type_find(pstate, nat) : pstate\ndef $review_type_find(S, n) = S -- if $review_type_stage(S)\ndef $review_type_find(S, n) = $review_type_find(S_next[.COMPLETION = NORMAL], n_rest)\n  -- if ~$review_type_stage(S)\n  -- if $(n > 0)\n  -- if n_rest = $(n - 1)\n  -- if S_next = $drive_steps(S, 1)\n'
  prefix += 'dec $review_type_return_record(pstate, nat, pcodeexpr) : bool\ndef $review_type_return_record(S, n_unit, CODEEXPR pcpath z b) = true\n  -- if $origin_node(S.SOURCES, (PORIGIN n_unit pcpath)) = (NStmtReturn expression metadata)\ndef $review_type_return_record(S, n_unit, pcodeexpr) = false -- otherwise\ndec $review_type_unit_return(pstate, nat, pcodeexpr*) : pcodeexpr*\ndef $review_type_unit_return(S, n_unit, eps) = eps\ndef $review_type_unit_return(S, n_unit, (CODEEXPR pcpath z b) :: pcodeexpr*) = (CODEEXPR pcpath $(z + 100) b) :: pcodeexpr*\n  -- if $origin_node(S.SOURCES, (PORIGIN n_unit pcpath)) = (NStmtReturn expression metadata)\ndef $review_type_unit_return(S, n_unit, pcodeexpr :: pcodeexpr_tail*) = pcodeexpr :: $review_type_unit_return(S, n_unit, pcodeexpr_tail*)\n  -- if ~$review_type_return_record(S, n_unit, pcodeexpr)\n'
  common=['S_initial = '+initial,'S = $review_type_find(S_initial[.COMPLETION = NORMAL], 200)','S.TODO = ('+pattern+') :: ptask*','S.CODE = [pcode]','$call_descriptors_valid(S)']
  if name=='typed-nested-return-context':common += ['S.FRAMES = pframe :: pframe_tail*','pframe.TODO = (ORIGIN_RETURN porigin_saved?) :: (RETURN_VALUE z_saved) :: ptask_saved*']
  variants=[('control','S',True)]
  if stage=='receive':variants += [('wrong-callee','S[.TODO = [TYPE_RECEIVE (PORIGIN 999 eps) n]]',False),('index-outside-params','S[.TODO = [TYPE_RECEIVE porigin 99]]',False),('trailing-task','S[.TODO = [TYPE_RECEIVE porigin n, DISCARD]]',False)]
  if stage=='fallthrough':variants += [('wrong-callee','S[.TODO = (TYPE_FALLTHROUGH (PORIGIN 999 eps)) :: ptask*]',False)]
  if stage=='return':
   variants += [('unit-return-line','S[.CODE = [pcode[.EXPRESSIONS = $review_type_unit_return(S, pcode.UNIT, pcode.EXPRESSIONS)]]]',False),('wrong-return-line','S[.TODO = (RETURN_VALUE $(z + 100)) :: ptask*]',False)]
   if name=='typed-value-return-global-alias-copy':variants += [('arbitrary-result','S[.RESULT = KNOWN (PINT 99)]',True)]
  if name=='typed-nested-return-context':variants += [('saved-return-line','S[.FRAMES = pframe[.TODO = (ORIGIN_RETURN porigin_saved?) :: (RETURN_VALUE $(z_saved + 100)) :: ptask_saved*] :: pframe_tail*]',False)]
  variants=[v for v in variants if a.variant in v[0]]
  for kind,term,valid in variants:
   accepted=valid or a.original;checks=common+['S_changed = '+term,'$call_descriptors_valid(S_changed) = '+str(accepted).lower(),'S_zero = $drive(S_changed, 0)']
   checks += ['S_zero.COMPLETION = BUDGET'] if accepted else ['S_zero.COMPLETION = UNSUPPORTED "invalid compiled function descriptor"']
   if valid or not a.original:
    checks += ['S_full = $drive(S_changed, 10000)']
    checks += ['S_full.COMPLETION = $drive(S, 10000).COMPLETION'] if valid else ['S_full.COMPLETION = S_zero.COMPLETION']
   fixtures.append((d,kind,prefix,checks,valid,common+['S_changed = '+term]))
finally:
 try:
  if f:f.close()
 finally:
  if ad:ad.close()
for d,kind,prefix,checks,valid,rawchecks in fixtures:
 for raw in ([False,True] if a.original and not valid else [False]):
  suffix=kind+('-full' if raw else '');p=d/(suffix+'.watsup');p.write_text(prefix+'\ndec $main() : '+('pcompletion' if raw else 'bool')+'\ndef $main() = '+('$drive(S_changed, 10000).COMPLETION' if raw else 'true')+'\n'+''.join('  -- if '+c+'\n' for c in (rawchecks if raw else checks)));cmd=[str(runner),*map(str,modules),str(p)];(d/(suffix+'.command.json')).write_text(json.dumps(cmd))
  try:r=subprocess.run(cmd,capture_output=True,timeout=60)
  except subprocess.TimeoutExpired as e:
   (d/(suffix+'.stdout')).write_bytes(e.stdout or b'');(d/(suffix+'.stderr')).write_bytes(e.stderr or b'');(d/(suffix+'.status.json')).write_text(json.dumps({'status':'timeout'}));raise
  (d/(suffix+'.stdout')).write_bytes(r.stdout);(d/(suffix+'.stderr')).write_bytes(r.stderr);(d/(suffix+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));row={'id':d.name+'/'+suffix,'pass':r.returncode==0 and (raw or r.stdout.strip()==b'true') and not r.stderr,'assertions':len(rawchecks if raw else checks),'raw_completion':r.stdout.decode() if raw else None};records.append(row);(D/'results.json').write_text(json.dumps(records,indent=2));print(row,flush=True)
assert before==q.t.syntax_validation.implementation_fingerprint();assert all(sha(K/p)==h for p,h in direct.items());(D/'report.json').write_text(json.dumps({'result':'pass' if all(r['pass'] for r in records) else 'fail','original_guard_gaps':a.original,'fingerprint':before,'records':records,'assertions':sum(r['assertions'] for r in records)},indent=2))
