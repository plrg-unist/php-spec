<?php
function f(&$x):int{return $x;}
$x="2";$y=&$x;echo f($x),$x==="2",$y==="2";