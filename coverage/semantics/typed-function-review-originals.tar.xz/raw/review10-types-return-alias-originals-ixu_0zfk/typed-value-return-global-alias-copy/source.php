<?php
$x="2";$y=&$x;
function f():int{global $x;$z=&$x;return $z;}
echo f(),$x==="2",$y==="2";