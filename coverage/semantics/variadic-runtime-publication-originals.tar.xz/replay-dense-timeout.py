from pathlib import Path
import json,hashlib,stat,subprocess,tempfile,time
P=Path(__file__).resolve().parent;R=P.parent/'runtime7-variadic-state-timeout';A=P.parent/'runtime7-variadic-final';O=Path(tempfile.mkdtemp(prefix='dense-timeout-replay-',dir=P));N=A/'.tools/variadic-state-xn74afvb';m=json.loads((R/'inputs.json').read_text());old=json.loads((A/'inputs.json').read_text());print(O,flush=True)
assert (R/'tests/semantics/variadic_state.py').read_bytes().replace(b'timeout=900',b'timeout=300').replace(b"'seconds': 900",b"'seconds': 300")==(A/'tests/semantics/variadic_state.py').read_bytes()
modules=json.loads((R/'spec/semantics/modules.json').read_text());binary='tests/semantics/_build/default/numeric_runner.exe'
for name in [*modules,binary]:assert m['files'][name]==old['files'][name] and m['modes'][name]==old['modes'][name]
(O/'inputs.json').write_text(json.dumps(m,indent=2));(O/'producer.py').write_bytes(Path(__file__).read_bytes());rows=json.loads((N/'originals.json').read_text())
for row in rows:
 name=row['id'];d=O/name;d.mkdir();fixture=N/name/'state.watsup';copy=d/'state.watsup';copy.write_bytes(fixture.read_bytes());assert copy.read_bytes()==fixture.read_bytes();cmd=[str(R/binary),*[str(R/n) for n in modules],str(copy)];(d/'runner.command.json').write_text(json.dumps(cmd));start=time.monotonic()
 try:
  r=subprocess.run(cmd,capture_output=True,timeout=900);(d/'runner.stdout').write_bytes(r.stdout);(d/'runner.stderr').write_bytes(r.stderr);status={'status':'exit','exit_status':r.returncode,'seconds':time.monotonic()-start};good=r.returncode==0 and r.stdout.strip()==b'true' and not r.stderr
 except subprocess.TimeoutExpired as e:
  (d/'runner.stdout').write_bytes(e.stdout or b'');(d/'runner.stderr').write_bytes(e.stderr or b'');status={'status':'timeout','seconds':900};good=False
 (d/'runner.status.json').write_text(json.dumps(status));row.update({'pass':good,'fixture':str(copy),'fixture_sha256':hashlib.sha256(copy.read_bytes()).hexdigest(),'original_fixture':str(fixture),'assertions':copy.read_text().split('\ndef $main() = true\n',1)[1].count('  -- if '),'runner':str(d),'native_original':str(N/name)});(O/'results.json').write_text(json.dumps(rows,indent=2));print(name,status,good,flush=True);assert good,status
for n,h in m['files'].items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h and stat.S_IMODE((R/n).stat().st_mode)==m['modes'][n]
report={'result':'pass','fingerprint':m['fingerprint'],'prepared_fingerprint':old['fingerprint'],'raw':str(O),'original_raw':str(N),'scope':'Exact two original prepared dense fixtures rerun with900s per-case allowance; no assertion/native/request changes or native reruns. Original300s timeout and prepared/unrun second case retained. Runtime modules and actual runner binaries byte/mode equal; new state producer differs onlytimeout.','records':rows,'assertions':sum(r['assertions'] for r in rows)}
(O/'report.json').write_text(json.dumps(report,indent=2));(R/'coverage/semantics/variadic-state.json').write_text(json.dumps(report,indent=2));print('PASS',report['assertions'],flush=True)
