from pathlib import Path
import hashlib,json,stat,tarfile,io
P=Path(__file__).resolve().parent;R=P.parent/'runtime7-variadic-candidate';D=R/'publication/coverage/semantics';names=['archive-author.py','verify-author-archive.py','author-archive-audit.json','audit-final-gates.py','final-gate-audit.json','install-canonical.py','canonical-installation.json','code-commit.json','publication-cli.py','publication-cli.json','publication-supplement.py','report-author.py','setup-history.json','replay-dense-timeout.py'];files={n:P/n for n in names}
for n in ['installation-delta.json','protocol-cleanup-bridge.json','semantic-test-bridge.json','state-timeout-bridge.json']:files[n]=R/n
files['final-inputs.json']=P.parent/'runtime7-variadic-state-timeout/inputs.json';pub=json.loads((P/'publication-cli.json').read_text());raw=Path(pub['raw'])
for p in raw.rglob('*'):
 if p.is_file():files[str(p.relative_to(P))]=p
manifest={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'mode':stat.S_IMODE(p.stat().st_mode),'bytes':p.stat().st_size} for n,p in sorted(files.items())};history=json.loads((D/'variadic-runtime-originals.json').read_text());body=(json.dumps({'files':manifest,'scope':'Exact canonical959 installation and eight public CLI envelopes/native comparisons, archive validation and publication producers; main history archive remains immutable.'},indent=2)+'\n').encode();archive=D/'variadic-runtime-publication-originals.tar.xz';assert not archive.exists();seen={}
with tarfile.open(archive,'w:xz') as t:
 z=tarfile.TarInfo('MANIFEST.json');z.size=len(body);z.mode=0o644;t.addfile(z,io.BytesIO(body))
 for n,p in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=manifest[n]['mode'];key=(manifest[n]['sha256'],z.mode)
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:
   b=p.read_bytes();z.size=len(b);t.addfile(z,io.BytesIO(b));seen[key]=n
j={'archive':'coverage/semantics/'+archive.name,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'bytes':archive.stat().st_size,'payload_files':len(files),'members':len(files)+1,'manifest_sha256':hashlib.sha256(body).hexdigest(),'fingerprint':pub['fingerprint'],'history_archive_sha256':history['sha256']};(D/'variadic-runtime-publication-originals.json').write_text(json.dumps(j,indent=2)+'\n');print(j)
