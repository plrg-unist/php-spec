from pathlib import Path
import hashlib,json,stat,sys,shutil,subprocess
P=Path(__file__).resolve().parent;D=P.parent/'runtime7-variadic-state-timeout';R=P.parents[1];sys.path.insert(0,str(R/'tests'));import validate
before=json.loads((P.parent/'runtime7-variadic-baseline-parser951/inputs.json').read_text());after=json.loads((D/'inputs.json').read_text());names=json.loads((P.parent/'runtime7-variadic-candidate/installation-delta.json').read_text());delta=[{'path':n,'after':after['files'][n],'after_mode':after['modes'][n]} for n in names]
def verify(j):
 assert validate.implementation_fingerprint()==j['fingerprint']
 assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h and stat.S_IMODE((R/n).stat().st_mode)==j['modes'][n] for n,h in j['files'].items())
assert not subprocess.check_output(['git','status','--porcelain'],cwd=R);verify(before);assert len(delta)==19
for change in delta:
 n=change['path'];p=D/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==change['after'];assert stat.S_IMODE(p.stat().st_mode)==change['after_mode'];q=R/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
verify(after);result={**after,'scope':'All959 canonical paths/bytes/modes equal independently reviewed frozen candidate; all951 baseline paths retained.','delta':delta};(P/'canonical-installation.json').write_text(json.dumps(result,indent=2)+'\n');print(result['fingerprint'],'exact canonical paths/modes')
