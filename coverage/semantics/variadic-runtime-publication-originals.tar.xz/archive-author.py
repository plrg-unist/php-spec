from pathlib import Path
import hashlib,json,stat,tarfile,io
P=Path(__file__).resolve().parent;R=P.parent/'runtime7-variadic-candidate';TOP=P.parents[1];D=R/'publication/coverage/semantics';D.mkdir(parents=True,exist_ok=True);files={}
def add(p,name):
 assert p.is_file(),p
 assert name not in files or files[name]==p,(name,p)
 files[name]=p
labels=['baseline951','baseline-parser951','first','task-pattern','repaired','trace','guarded','integration','final','accepted-tests','state-timeout'];snapshots=[]
for label in labels:
 root=P.parent/('runtime7-variadic-'+label);mp=root/'inputs.json';j=json.loads(mp.read_text());snapshots.append((label,root,mp));assert len(j['files'])==j['fingerprint']['files'];add(mp,'snapshots/'+label+'/INPUTS.json')
 for n,h in j['files'].items():
  p=root/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h,(label,n);assert stat.S_IMODE(p.stat().st_mode)==j['modes'][n],(label,n);add(p,'snapshots/'+label+'/'+n)
raw_roots=[P]
for root in [R,*[row[1] for row in snapshots]]:
 if (root/'.tools').exists():raw_roots.append(root/'.tools')
 for p in root.iterdir():
  if p.is_file() and p.suffix in ('.py','.json','.md','.watsup','.stdout','.stderr'):add(p,'preparation/'+str(p.relative_to(TOP)))
 for p in (root/'coverage/semantics').glob('*.json'):add(p,'reports/'+str(p.relative_to(TOP)))
for root in raw_roots:
 for p in root.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc':add(p,'raw/'+str(p.relative_to(TOP)))
for n in ['Zend/zend_compile.c','Zend/zend_vm_def.h','Zend/zend_execute.c','Zend/zend_builtin_functions.c','Zend/zend_errors.h','Zend/zend_globals.h','main/main.c']:add(TOP/'vendor/php-src'/n,'pinned-source/'+n)
manifest={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for n,p in sorted(files.items())}
meta={'scope':'Eleven complete snapshots: accepted suppression951/c650 and parser951/440f, first/task-pattern structural failures953, trace/arity mismatch953, runnable trace953 and guarded953, integration959, semantic959/cee5, compiler-test959/4d69 and timeout-only959/4854. Author9 original native/full-request sources, retained16 and32 replays, exact failed and successful gates, portable20 protocol preflight/final, selected8 regressions and original300s timeout plus exact prepared900s rerun are retained. Compiler archives separately own earlier16/new7 native sources and SL rule isolation; independent review archives own source/stage counterexamples. Setup/tool failures and four explicit named/unpack/catch dependencies are not agreement.','files':manifest}
payload=(json.dumps(meta,indent=2)+'\n').encode();target=D/'variadic-runtime-originals.tar.xz';assert not target.exists();seen={}
with tarfile.open(target,'w:xz',preset=6) as t:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(payload);info.mode=0o644;t.addfile(info,io.BytesIO(payload))
 for name,p in sorted(files.items()):
  e=manifest[name];info=tarfile.TarInfo(name);info.mode=e['mode'];key=(e['sha256'],e['mode'])
  if key in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[key];t.addfile(info)
  else:
   raw=p.read_bytes();info.size=len(raw);t.addfile(info,io.BytesIO(raw));seen[key]=name
a={'archive':'coverage/semantics/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'payload_files':len(files),'members':len(files)+1,'manifest_sha256':hashlib.sha256(payload).hexdigest(),'snapshots':{label:json.loads(mp.read_text())['fingerprint'] for label,root,mp in snapshots},'scope':meta['scope'],'compiler_archives':['coverage/semantics/variadic-compiler-originals.tar.xz','coverage/semantics/variadic-compiler-final-originals.tar.xz']};(D/'variadic-runtime-originals.json').write_text(json.dumps(a,indent=2)+'\n');print(a,flush=True)
