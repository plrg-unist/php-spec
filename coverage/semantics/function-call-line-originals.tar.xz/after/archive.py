from pathlib import Path
import hashlib,json,tarfile,difflib,io
D=Path(__file__).resolve().parent;S=D.parent/'compiler5-argument-mode';R=D.parent/'runtime5-calls-guarded';O=R/'.tools/call-line-originals-d_f75xqw'
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
changes=['spec/semantics/78-function-compiler.watsup','tests/semantics/function_argument_cases.json']
delta={p:{'before':digest(S/p),'after':digest(D/p)} for p in changes};(D/'call-line-delta.json').write_text(json.dumps(delta,indent=2)+'\n');(D/'call-line-delta.patch').write_text(''.join(''.join(difflib.unified_diff((S/p).read_text().splitlines(True),(D/p).read_text().splitlines(True),fromfile='a/'+p,tofile='b/'+p)) for p in changes))
files={}
original=json.loads((O/'inputs.json').read_text())
for p,h in original['modules'].items():assert digest(R/p)==h,p;files['runtime-original-modules/'+p]=R/p
for p in O.rglob('*'):
 if p.is_file():files['runtime-originals/'+str(p.relative_to(O))]=p
for prefix,root in [('before',S),('after',D)]:
 for p in json.loads((root/'spec/semantics/modules.json').read_text())+['spec/semantics/modules.json','tests/semantics/function_argument_compiler.py','tests/semantics/function_argument_cases.json','tests/semantics/static_types.py','tests/semantics/source_compiler.py','tests/semantics/source_context.py','tests/semantics/profile.json','tests/validate.py','tests/corpus.py','frontend/wire.py']:
  files[prefix+'/'+p]=root/p
for rel in ['copied-inputs.json','semantics-reference-inputs.json','check.py','archive.py','call-line-delta.json','call-line-delta.patch','coverage/semantics/function-argument-compiler.json']:files['after/'+rel]=D/rel
for p in (D/'.tools').rglob('*'):
 if p.is_file():files['after/'+str(p.relative_to(D))]=p
hashes={p:digest(f) for p,f in sorted(files.items())};baseline=json.loads((S/'final-inputs.json').read_text());tools={p:h for p,h in baseline.items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p,h in tools.items():assert digest(D/p)==h and digest(S/p)==h,p
for p in list(files):
 if p.startswith('after/') and p.removeprefix('after/') in tools:del files[p]
hashes={p:digest(f) for p,f in sorted(files.items())}
out=D/'coverage/semantics/function-call-line-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as tar:
 b=(json.dumps({'files':hashes,'tools':tools},indent=2)+'\n').encode();i=tarfile.TarInfo('SHA256.json');i.size=len(b);tar.addfile(i,io.BytesIO(b))
 for p,f in sorted(files.items()):
  h=hashes[p];i=tar.gettarinfo(str(f),arcname=p)
  if h in seen:i.type=tarfile.LNKTYPE;i.linkname=seen[h];i.size=0;tar.addfile(i)
  else:
   seen[h]=p
   with f.open('rb') as stream:tar.addfile(i,stream)
with tarfile.open(out,'r:xz') as tar:
 for p,h in hashes.items():assert hashlib.sha256(tar.extractfile(p).read()).hexdigest()==h,p
report={'archive':str(out.relative_to(D)),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':tools,'scope':'Call emitted-line reset; four original compiler emission checks false before / true after;39 exact lint phases including seven multiline controls and21 prior context assertions. Runtime originals are retained; runtime repair acceptance is separate.','notes':['First handwritten line helper omitted the test-only pprecord dependency; exact failed fixture and stderr retained.','Old and new complete compiler states and all used semantic module bytes retained; no PHP diagnostic mismatch is treated as a tool failure or agreement.']}
(D/'coverage/semantics/function-call-line-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
