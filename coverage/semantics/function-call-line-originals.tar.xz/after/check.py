from pathlib import Path
import json,subprocess,tempfile,sys,hashlib
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'));import static_types as t
source=D.parent/'runtime5-calls-guarded/.tools/call-line-originals-d_f75xqw'
out=Path(tempfile.mkdtemp(prefix='call-line-check-',dir=D/'.tools'));print(out,flush=True)
modules=json.loads((D/'spec/semantics/modules.json').read_text());inputs={p:hashlib.sha256((D/p).read_bytes()).hexdigest() for p in modules};(out/'inputs.json').write_text(json.dumps(inputs,indent=2))
a=t.Worker([str(D/'_build/default/adapter/main.exe'),str(D)]);fixtures=[]
try:
 for case in sorted(source.glob('*/parsed.json')):
  parsed=json.loads(case.read_text());checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});assert checked['ok'];name=case.parent.name;(out/(name+'-checked.json')).write_text(json.dumps(checked))
  definition='$ppstart(91, '+checked['fixture']+', '+t.byte_expr(str(case.parent/'source.php'))+')'
  fixture=out/(name+'.watsup');fixture.write_text('dec $main() : ppstate\ndef $main() = '+definition+'\n');command=[str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/p) for p in modules],str(fixture)];(out/(name+'-command.json')).write_text(json.dumps(command))
  try:r=subprocess.run(command,capture_output=True,timeout=25)
  except subprocess.TimeoutExpired as e:
   (out/(name+'.stdout')).write_bytes(e.stdout or b'');(out/(name+'.stderr')).write_bytes(e.stderr or b'');(out/(name+'-status.json')).write_text(json.dumps({'status':'timeout'}));raise
  (out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr);(out/(name+'-status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));assert not r.returncode and not r.stderr
  fixtures.append('dec $case'+str(len(fixtures))+'() : bool\ndef $case'+str(len(fixtures))+'() = $call_lines(P, P.FOLD.SOURCE.OCCURRENCES)\n  -- if P = '+definition+'\n  -- if P.COMPLETION = PPCNORMAL\n')
finally:a.close()
fixture=out/'lines.watsup';fixture.write_text(r'''dec $call_lines(ppstate, pcoccurrence*) : bool
dec $call_line(ppstate, pcpath, pcnode) : bool
def $call_line(P, pcpath, NExprFuncCall name phpType6 metadata) = (z = $source_line(metadata))
  -- if $code_expression($compiled_operands(P, P.EXPRESSIONS), pcpath) = ((z, b))
def $call_line(P, pcpath, pcnode) = true -- otherwise
def $call_lines(P, eps) = true
def $call_lines(P, (PCOCCURRENCE pcpath pcnode) :: pcoccurrence*) = ($call_line(P, pcpath, pcnode) /\ $call_lines(P, pcoccurrence*))
'''+'\n'.join(fixtures)+'dec $main() : bool\ndef $main() = '+' /\\ '.join('$case'+str(i)+'()' for i in range(len(fixtures)))+'\n')
command=[str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/p) for p in modules],str(fixture)];(out/'assertion-command.json').write_text(json.dumps(command));r=subprocess.run(command,capture_output=True,timeout=25);(out/'assertion.stdout').write_bytes(r.stdout);(out/'assertion.stderr').write_bytes(r.stderr);(out/'assertion-status.json').write_text(json.dumps({'status':'exit','exit_status':r.returncode}));print(r.returncode,r.stdout,r.stderr,flush=True)
assert inputs=={p:hashlib.sha256((D/p).read_bytes()).hexdigest() for p in inputs}
