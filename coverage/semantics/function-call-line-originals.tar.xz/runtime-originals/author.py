from pathlib import Path
import base64,hashlib,json,sys,tempfile,os
R=Path(__file__).resolve().parents[2];D=R/'.tools/runtime5-calls-guarded';sys.path.insert(0,str(D/'tests/semantics'));import request_environment as q
O=Path(tempfile.mkdtemp(prefix='call-line-originals-',dir=D/'.tools'));cases={
'call-lines':'<?php function f($x){1/0;}f(\n7\n);',
'count-lines':'<?php function f($x,$y){}f(\n7\n);',
'nested-lines':'<?php function f($x){1/0;}function g(){return 7;}f(\ng()\n);',
'argument-lines':'<?php function f($x){}f(\n1/0\n);',}

inputs=q.t.syntax_validation.implementation_fingerprint();mods=[D/n for n in json.load(open(D/'spec/semantics/modules.json'))];(O/'inputs.json').write_text(json.dumps({'fingerprint':inputs,'modules':{str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in mods}},indent=2)+'\n');(O/'author.py').write_bytes(Path(__file__).read_bytes())
for p in mods:
 out=O/'original-inputs'/p.relative_to(D);out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(p.read_bytes())
packet=O/'request.input';packet.write_bytes(q.packet(0,0,[b'LC_ALL=C',b'TZ=UTC']));records=[]
for name,text in cases.items():
 directory=O/name;directory.mkdir();p=directory/'source.php';p.write_text(text);Q={'env':[[q.b64(k),q.b64(v)] for k,v in [(b'LC_ALL',b'C'),(b'TZ',b'UTC')]],'argv':[q.b64(str(p).encode())],'file':q.b64(str(p).encode()),'seconds':'0','microseconds':0,'variables':q.b64(b'EGPCS'),'jit':True,'cwd':q.b64(str(O).encode())};row={'id':name,'source_base64':q.b64(text.encode()),'context':str(p),'request':Q};(directory/'input.json').write_text(json.dumps(row,indent=2)+'\n');row['native']=q.invoke(p,packet,[],[],O);records.append(row);(O/'originals.json').write_text(json.dumps({'records':records},indent=2)+'\n');print(name,base64.b64decode(row['native']['stdout']),flush=True)
f=q.t.Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')]);a=q.t.Worker([str(D/'_build/default/adapter/main.exe'),str(D)])
try:
 for row in records:
  directory=O/row['id'];parsed=f.request({'op':'parse','source':row['source_base64']});(directory/'parsed.json').write_text(json.dumps(parsed)+'\n');req={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':q.b64(row['context'].encode()),'request':row['request']};(directory/'execute.json').write_text(json.dumps(req)+'\n');state=a.request(req);(directory/'state.json').write_text(json.dumps(state)+'\n');row['actual']=q.cli.observe(state['state'],row['context']);row['agreement']=all(row['actual'][k]==row['native'][k] for k in ['stdout','stderr','exit_status']);print(row['id'],row['agreement'],base64.b64decode(row['actual']['stdout']),flush=True);(O/'results.json').write_text(json.dumps({'records':records},indent=2)+'\n')
finally:f.close();a.close()
assert inputs==q.t.syntax_validation.implementation_fingerprint();print(O,flush=True)
