from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as fs
fs.main({'used-then-unused-reference-call':b'<?php $x=1;function &f(){global $x;return $x;}$r=&f();f();$r=2;echo $x;'},'review10-demand-context-original',Path(__file__))
