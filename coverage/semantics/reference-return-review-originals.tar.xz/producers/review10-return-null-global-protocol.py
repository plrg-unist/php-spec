from pathlib import Path
import argparse,base64,hashlib,json,subprocess,sys,tempfile
p=argparse.ArgumentParser();p.add_argument('candidate',type=Path);a=p.parse_args();R=Path.cwd();K=a.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'))
import request_environment as q
import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-return-null-global-protocol-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes());print(D,flush=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();modules=[K/n for n in json.loads((K/'spec/semantics/modules.json').read_text())];runner=K/'tests/semantics/_build/default/numeric_runner.exe';before=q.t.syntax_validation.implementation_fingerprint();inputs={str(p.relative_to(K)):sha(p) for p in [*modules,runner,K/'tests/semantics/recorded_worker.py']};(D/'inputs.json').write_text(json.dumps({'fingerprint':before,'direct':inputs},indent=2))
rows={}
for n in ['.tools/review10-reference-originals-njtxxlzj/report.json','.tools/review10-reference-final/.tools/review10-return-demand-originals-dori_xf6/report.json','.tools/runtime6-strict-directive/.tools/reference-return-originals-la6j_ffx/report.json','.tools/compiler6-reference-demand/baseline933/.tools/reference-return-class-gaps-mmgoubon/report.json']:
 for r in json.loads((R/n).read_text())['records']:rows[r['id']]={**r,'original_report':n,'original_report_sha256':sha(R/n)}
records=[]
for case,stage in [('ref-return-implicit','RETURN_REF_NULL'),('return-whole-globals-copy','RETURN_REF_VALUE')]:
 d=D/case;d.mkdir();row=rows[case];(d/'original.json').write_text(json.dumps(row,indent=2));assert Path(row['context']).read_bytes()==base64.b64decode(row['source_base64']);f=ad=None
 try:
  f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],d/'frontend-wire');ad=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],d/'adapter-wire')
  parsed=f.request({'op':'parse','source':row['source_base64']});checked=ad.request({'op':'check','ast':parsed['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(checked))
  result=ad.request({'op':'execute','ast':parsed['ast'],'steps':10000,'filename':q.b64(row['context'].encode()),'request':row['request']});(d/'state.json').write_text(json.dumps(result));actual=q.cli.observe(result['state'],row['context']);assert all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
 finally:
  try:
   if f:f.close()
  finally:
   if ad:ad.close()
 initial='$php_request_run('+checked['fixture']+', 0, '+json.dumps(q.b64(row['context'].encode()))+', '+rs.request_fixture(row['request'])+')'
 prefix='''dec $review_stage(pstate) : bool
 def $review_stage(S) = true -- if S.TODO = (STAGE z) :: ptask*
 def $review_stage(S) = false -- otherwise
 dec $review_find(pstate, nat) : pstate
 def $review_find(S, n) = S -- if $review_stage(S)
 def $review_find(S, n) = $review_find(S_next[.COMPLETION = NORMAL], n_rest)
   -- if ~$review_stage(S)
   -- if $(n > 0)
   -- if n_rest = $(n - 1)
   -- if S_next = $drive_steps(S, 1)
 '''.replace('STAGE',stage)
 common=['S_initial = '+initial,'S = $review_find(S_initial[.COMPLETION = NORMAL], 200)',f'S.TODO = ({stage} z) :: ptask*','$call_descriptors_valid(S)']
 for name,change in [('control','S'),('wrong-line',f'S[.TODO = ({stage} $(z + 100)) :: ptask*]'),('absent-origin','S[.ORIGIN = eps]'),('wrong-class','S[.TODO = (RETURN_REF_FETCH z) :: ptask*]' if stage=='RETURN_REF_VALUE' else 'S[.TODO = RETURN_NULL :: ptask*]')]:
  checks=common+['S_changed = '+change,'$heap_valid($heap_graph(S_changed))','$call_descriptors_valid(S_changed)','S_zero = $drive(S_changed, 0)','S_zero.COMPLETION = BUDGET','S_full = $drive(S_changed, 10000)']
  checks+=['S_full.COMPLETION = THROWN "TypeError" n_message* '+('$(z + 100)' if name=='wrong-line' else 'z')] if stage=='RETURN_REF_FETCH' else ['S_full.COMPLETION = NORMAL']
  fixture=d/(name+'.watsup');fixture.write_text(prefix+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+x+'\n' for x in checks));cmd=[str(runner),*map(str,modules),str(fixture)];(d/(name+'.command.json')).write_text(json.dumps(cmd))
  try:r=subprocess.run(cmd,capture_output=True,timeout=60)
  except subprocess.TimeoutExpired as e:
   (d/(name+'.stdout')).write_bytes(e.stdout or b'');(d/(name+'.stderr')).write_bytes(e.stderr or b'');(d/(name+'.status.json')).write_text(json.dumps({'status':'timeout'}));raise
  (d/(name+'.stdout')).write_bytes(r.stdout);(d/(name+'.stderr')).write_bytes(r.stderr);(d/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));rec={'id':case+'/'+name,'assertions':len(checks),'observed_admitted':r.returncode==0 and r.stdout.strip()==b'true' and not r.stderr};records.append(rec);(D/'results.json').write_text(json.dumps(records,indent=2));print(rec,flush=True)
assert before==q.t.syntax_validation.implementation_fingerprint();assert all(sha(K/n)==h for n,h in inputs.items());(D/'report.json').write_text(json.dumps({'scope':'First935 actual-source preguard admission witnesses; not final protocol acceptance','fingerprint':before,'records':records,'raw':str(D)},indent=2))
