from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'unused-refreturn-undefined-cv':b'<?php\nfunction &f(){return $missing;}\nf();echo "DONE";',
 'unused-refreturn-undefined-global-dim':b'<?php\nfunction &f(){return $GLOBALS["missing"];}\nf();echo $missing,"DONE";',
 'unused-typed-refreturn-undefined-cv':b'<?php\nfunction &f():int{return $missing;}\nf();echo "DONE";',
 'unused-mixed-refreturn-undefined-cv':b'<?php\nfunction &f():mixed{return $missing;}\nf();echo "DONE";',
 'unused-typed-refreturn-undefined-global-dim':b'<?php\nfunction &f():int{return $GLOBALS["missing"];}\nf();echo "DONE";',
 'unused-refreturn-array-leaf-cow':b'<?php\n$a=[1];function &f(){global $a;return $a[0];}\nf();$b=$a;$b[0]=2;echo $a[0],$b[0];',
 'unused-typed-refreturn-global-coercion':b'<?php\n$x="2";$alias=&$x;function &f():int{global $x;return $x;}\nf();echo $x===2,$alias===2;',
}
if __name__=='__main__':scope.main(CASES,'review10-return-demand-originals',Path(__file__))
