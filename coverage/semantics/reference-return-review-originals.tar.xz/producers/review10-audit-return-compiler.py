from pathlib import Path
import hashlib,json,stat,sys,tarfile
R=Path.cwd();D=R/'.tools/compiler6-reference-return98';sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((D/'archive.json').read_text());assert sha((D/'originals.tar.xz').read_bytes())==a['sha256'];data={};modes={}
with tarfile.open(D/'originals.tar.xz',mode='r|xz') as t:
 for e in t:
  if e.name=='SHA256.json':m=json.load(t.extractfile(e));continue
  b=data[e.linkname] if e.islnk() else t.extractfile(e).read();assert sha(b)==m['files'][e.name] and e.mode==m['modes'][e.name];data[e.name]=b;modes[e.name]=e.mode
assert len(data)==5383 and set(data)==set(m['files'])
f=json.loads((R/'.tools/review10-reference-final/inputs.json').read_text())
for prefix,manifest in [('baseline933',f),('compiler936',json.loads(data['compiler936/final-inputs.json']))]:
 for n,h in manifest['files'].items():
  k=prefix+'/'+n
  if k in data:assert sha(data[k])==h and modes[k]==manifest['modes'][n]
  else:assert m['tools'][k]=={'sha256':h,'mode':manifest['modes'][n]}
for n,v in m['tools'].items():
 rel=next(p for p in f['files'] if n.endswith('/'+p));assert v['sha256']==f['files'][rel]
for n,v in m['historical_native_tool_aliases'].items():assert v['sha256']==m['tools'][v['current_binding']]['sha256'] and v['mode']==m['tools'][v['current_binding']]['mode']
responses=closures=0
for n,b in data.items():
 if n.endswith('/close.json'):
  p=n[:-10];assert json.loads(b)=={'status':'exit','exit_status':0,'final_exit_status':0};assert not data[p+'stderr'] and not data[p+'trailing.stdout']
  requests=[k for k in data if k.startswith(p) and k.endswith('.request')]
  for i in range(len(requests)):wire.loads(data[p+str(i)+'.request'].decode());assert wire.loads(data[p+str(i)+'.response'].decode())['ok']
  responses+=len(requests);closures+=1
out={'result':'pass','scope':'Every5383 compiler archive payload/hash/mode, exact933 and936 source/tool closures and full recorded packets/clean closures. Compiler phases remain separate from paired runtime acceptance.','sha256':a['sha256'],'baseline':f['fingerprint'],'candidate':a['candidate'],'paths':len(data),'tools':len(m['tools']),'native_aliases':len(m['historical_native_tool_aliases']),'responses':responses,'clean_closures':closures,'gates':a['gates'],'preparation_archive':a['preparation_archive']};(R/'.tools/review10-return-compiler-archive-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(out)
