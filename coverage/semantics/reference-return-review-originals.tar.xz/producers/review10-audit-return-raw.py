from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
groups={
 'native933-originals':['review10-reference-final/.tools/review10-return-demand-originals-dori_xf6','review10-reference-final/.tools/review10-demand-context-original-hqeihzik'],
 'early935-source':['review10-return-reference-replay-92iak2h2'],
 'early935-protocol-and-setup':['review10-return-protocol-dev9thpk','review10-return-task-protocol-xi76ruas','review10-return-demand-protocol-h6krlj5n','review10-return-demand-protocol-h4tduxf4','review10-return-demand-protocol-zinjjtzw','review10-return-values-protocol-t_dd4hlk','review10-return-result-protocol-c92123c0','review10-return-null-global-protocol-0cnrmenj'],
 'semantic942-7951':['review10-return-reference-replay-zst3vujo','review10-return-reference-state-54nl9dfl','review10-return-compatibility-ip2od3yf','review10-return-integration/.tools/reference-return-protocol-q3exwmf0'],
}
records=[]
for category,names in groups.items():
 for name in names:
  root=R/'.tools'/name;workers=[]
  for p in root.rglob('close.json'):
   d=p.parent;assert json.loads(p.read_text())=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes()
   requests=list(d.glob('*.request'));assert len(requests)==len(list(d.glob('*.response')))
   for n in range(len(requests)):
    wire.loads((d/f'{n}.request').read_text());assert wire.loads((d/f'{n}.response').read_text())['ok']
   workers.append({'path':str(d),'responses':len(requests),'clean_closure':True})
  records.append({'root':str(root),'category':category,'workers':workers,'responses':sum(w['responses'] for w in workers)})
result={'result':'pass','records':records,'responses':sum(r['responses'] for r in records),'clean_closures':sum(len(r['workers']) for r in records),'scope':'Complete original933, early935 and semantic942/7951 recorded packets/clean closures. Final942/3c differs only in author state-test generator; audited separately. Native mismatch, Unsupported, malformed-state interpreter failures and standalone fixture setup failures remain distinct categories; successful transport is not semantic agreement.'}
(R/'.tools/review10-return-raw-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(result['responses'],result['clean_closures'])
