from pathlib import Path
import hashlib,json,tarfile
R=Path.cwd();D=R/'.tools/runtime7-return-candidate/publication/coverage/semantics';report=json.loads((D/'reference-return-runtime-originals.json').read_text());a=D/'reference-return-runtime-originals.tar.xz';sha=lambda b:hashlib.sha256(b).hexdigest();assert sha(a.read_bytes())==report['sha256']
verified={};snapshots={};sizes={}
with tarfile.open(a,mode='r|xz') as t:
 for z in t:
  if z.name=='MANIFEST.json':
   b=t.extractfile(z).read();assert sha(b)==report['manifest_sha256'];m=json.loads(b)
   wanted={m['files'][f'snapshots/{label}/INPUTS.json']['sha256']:label for label in report['snapshots']};continue
  if z.islnk():h=verified[z.linkname];length=sizes[z.linkname]
  else:
   b=t.extractfile(z).read();h=sha(b);length=len(b)
   if h in wanted:snapshots[wanted[h]]=json.loads(b)
  assert m['files'][z.name]=={'sha256':h,'bytes':length,'mode':z.mode},z.name
  verified[z.name]=h;sizes[z.name]=length
assert set(verified)==set(m['files']) and len(verified)==report['payload_files']
for label,fp in report['snapshots'].items():
 snapshot=snapshots[label];assert snapshot['fingerprint']==fp
 for p,h in snapshot['files'].items():
  key=f'snapshots/{label}/'+p;assert verified[key]==h and m['files'][key]['mode']==snapshot['modes'][p]
final=json.loads((R/'.tools/review10-return-final/inputs.json').read_text());assert snapshots['final942']['files']==final['files'] and snapshots['final942']['modes']==final['modes']
baseline=json.loads((R/'.tools/review10-reference-final/inputs.json').read_text());assert snapshots['baseline933']['files']==baseline['files'] and snapshots['baseline933']['modes']==baseline['modes']
for p,h in verified.items():
 if p.startswith('pinned-source/'):assert h==sha((R/'vendor/php-src'/p.removeprefix('pinned-source/')).read_bytes())
result={'result':'pass','archive_sha256':report['sha256'],'payload_paths':len(verified),'snapshots':report['snapshots'],'binary_payloads':'Actual retained bytes, hashes and modes verified in each full snapshot.','pinned_sources':7,'scope':'Every compact author archive payload/hardlink/hash/length/mode and all seven complete manifests. Exact independently held baseline933 and final942 files/modes match; seven authoritative pinned C sources match. First935, guarded935, integrated7951 and three state-test repair snapshots retain their identities.'}
(R/'.tools/review10-return-runtime-archive-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(report['sha256'],len(verified),'pass')
