from pathlib import Path
import hashlib,io,json,lzma,stat,sys,tarfile
R=Path.cwd();sys.path.insert(0,str(R/'tests/semantics'));import static_types as types
sha=lambda b:hashlib.sha256(b).hexdigest();files={};modes={};tools={};responses=closures=0
rawdirs=['review10-parameter-reproduce-g7jfn6tq','review10-parameter-phase-replay-it328f78','review10-parameter-cli-jr23dr3q','review10-parameter-phpt-avqoph3n']
for name in rawdirs:
 for p in sorted((R/'.tools'/name).rglob('*')):
  if not p.is_file() or '__pycache__' in p.parts:continue
  n='raw/'+name+'/'+str(p.relative_to(R/'.tools'/name));raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
  if p.name in ('php','php-file.so','request-clock.so','main.exe','numeric_runner.exe'):tools[n]={'sha256':sha(raw),'mode':mode};continue
  files[n]=raw;modes[n]=mode
  if p.suffix=='.response':assert types.wire.loads(raw.decode())['ok'];types.wire.loads(p.with_suffix('.request').read_text());responses+=1
  if p.name=='close.json':
   c=json.loads(raw);assert c['status']=='exit' and c['exit_status']==c['final_exit_status']==0;assert (p.parent/'stderr').read_bytes()==(p.parent/'trailing.stdout').read_bytes()==b'';closures+=1
for name in ['review10-parameter-phase-cli.py','review10-parameter-phase-copy-reproduce.py','review10-parameter-phase-replay.py','review10-parameter-phpt.py','review10-audit-parameter-phase.py','review10-package-parameter-phase.py','review10-publish-parameter-phase.py','review10-parameter-phase-reproduction.json','review10-parameter-phase-archive-audit.json']:
 p=R/'.tools'/name;files['producers-audits/'+name]=p.read_bytes();modes['producers-audits/'+name]=stat.S_IMODE(p.stat().st_mode)
for n,p in [('baseline-inputs.json',R/'.tools/compiler7-parameter-phase/baseline951/baseline-inputs.json'),('candidate-inputs.json',R/'.tools/review10-parameter-phase-first/inputs.json')]:files[n]=p.read_bytes();modes[n]=stat.S_IMODE(p.stat().st_mode)
m={'files':{n:sha(v) for n,v in files.items()},'modes':modes,'tools':tools};out=R/'.tools/review10-parameter-phase-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz') as t:
 raw=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,raw in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(sha(raw),modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(raw);t.addfile(z,io.BytesIO(raw))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in m['files'].items():assert sha(t.extractfile(n).read())==h and t.getmember(n).mode==modes[n]
report={'archive':'coverage/semantics/parameter-phase-review-originals.tar.xz','sha256':sha(out.read_bytes()),'paths':len(files),'bytes':out.stat().st_size,'tools':tools,'decoded_responses':responses,'clean_worker_closures':closures,'scope':'Independent exact951 candidate copy and five-file zero-fuzz reproduction; fourteen retained source replays and eight CLI controls; two exact retired PHPT FILE sources with fresh native/parser/lint and baseline/repaired CLI observations. Full raw packets and closures, exact producers/audits, original source/provider contexts. Tools bound by hash/mode; source closures depend on compiler archive0f6bea05. No runtime implementation change or variadic activation.'};(R/'.tools/review10-parameter-phase-originals.json').write_text(json.dumps(report,indent=2)+'\n');print(report)
