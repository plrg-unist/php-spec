from pathlib import Path
import hashlib,json,re,shutil,stat,subprocess,tempfile
R=Path.cwd();S=R/'.tools/compiler7-parameter-phase/candidate';K=R/'.tools/review10-parameter-phase-first';m=json.loads((S/'first-inputs.json').read_text());b=json.loads((R/'.tools/review10-suppression-final/inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert set(m['files'])==set(b['files'])
delta=[n for n in m['files'] if m['files'][n]!=b['files'][n]];assert set(delta)=={'vendor/php-parser/lib/PhpParser/ParserAbstract.php','tests/phase-discrepancies.json','tests/semantics/signatures.py'};assert m['modes']==b['modes']
for n,h in m['files'].items():
 p=S/n;assert sha(p)==h and stat.S_IMODE(p.stat().st_mode)==m['modes'][n];q=K/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copy2(S/'first-inputs.json',K/'inputs.json')
D=Path(tempfile.mkdtemp(prefix='review10-parameter-reproduce-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes());patch=S/'patches/php-parser-printer.patch';shutil.copy2(patch,D/'patch.input')
paths=re.findall(r'^--- a/(.+)$',patch.read_text(),re.M);assert len(paths)==5
sourcefiles={}
for n in paths:
 p=R/'vendor/php-parser-source'/Path(n).relative_to('vendor/php-parser');q=D/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q);sourcefiles[n]=sha(p)
cmd=['patch','--batch','--fuzz=0','--directory='+str(D),'-p1'];r=subprocess.run(cmd,input=patch.read_bytes(),capture_output=True,timeout=30);(D/'command.json').write_text(json.dumps(cmd));(D/'stdout').write_bytes(r.stdout);(D/'stderr').write_bytes(r.stderr);(D/'status.json').write_text(json.dumps({'status':'exit','exit_status':r.returncode}));assert r.returncode==0 and not r.stderr
for n in paths:assert sha(D/n)==sha(S/n),(n,sha(D/n),sha(S/n))
old=json.loads((R/'tests/phase-discrepancies.json').read_text());new=json.loads((S/'tests/phase-discrepancies.json').read_text());removed=[x for x in old if x not in new];assert [x for x in old if x not in removed]==new and {x['restriction'] for x in removed}=={'void_parameter','variadic_default'}
out={'result':'pass','baseline':b['fingerprint'],'candidate':m['fingerprint'],'watched_delta':delta,'all_modes_unchanged':True,'upstream_sources':sourcefiles,'patch_sha256':sha(patch),'reproduced_paths':paths,'raw':str(D),'retired_exceptions':removed,'scope':'Three watched changes, same951path set and every mode. Full five-file runtime/printer patch applies with fuzz0 to unchanged pinned upstream source and exactly reproduces candidate files; checked AST/schema/generated parser/runtime semantics stay byte-identical.'};(D/'report.json').write_text(json.dumps(out,indent=2));(R/'.tools/review10-parameter-phase-reproduction.json').write_text(json.dumps(out,indent=2));print(out)
