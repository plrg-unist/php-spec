from pathlib import Path
import base64,hashlib,json,subprocess,sys,tempfile
R=Path.cwd();K=Path(sys.argv[1]).resolve();D=Path(tempfile.mkdtemp(prefix='review10-parameter-cli-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes());m=json.loads((K/'inputs.json').read_text());p=R/'.tools/compiler7-parameter-phase/baseline951/.tools/parameter-phase-originals-su28fevt/report.json';rows=json.loads(p.read_text())['records'];ids=['variadic-default-literal','variadic-default-multiline','variadic-default-before-later-void','variadic-default-before-same-void','void-plain','void-multiline','valid-parameter-control','valid-variadic-boundary'];records=[]
for row in rows:
 if row['id'] not in ids:continue
 d=D/row['id'];d.mkdir();(d/'original.json').write_text(json.dumps(row,indent=2));(d/'request.json').write_text(json.dumps(row['request']));source=Path(row['context']);assert source.read_bytes()==base64.b64decode(row['source_base64']);cmd=[str(K/'bin/php-semantics'),str(source),'--request-context',str(d/'request.json')];(d/'command.json').write_text(json.dumps(cmd));r=subprocess.run(cmd,capture_output=True,timeout=60);(d/'stdout').write_bytes(r.stdout);(d/'stderr').write_bytes(r.stderr);(d/'status.json').write_text(json.dumps({'status':'exit','exit_status':r.returncode}));out=json.loads(r.stdout);assert not r.stderr
 boundary=row['id']=='valid-variadic-boundary'
 if boundary:assert r.returncode==1 and out['status']=='unsupported'
 else:assert r.returncode==0 and out['status'] in ('normal','static_rejection') and all(out[k]==row['native'][k] for k in ('stdout','stderr','exit_status'))
 records.append({'id':row['id'],'native_agreement':not boundary,'pending_variadic_boundary':boundary,'actual':out,'process_exit':r.returncode});print(row['id'],out['status'],flush=True)
for n,h in m['files'].items():assert hashlib.sha256((K/n).read_bytes()).hexdigest()==h
report={'result':'pass','fingerprint':m['fingerprint'],'raw':str(D),'records':records,'native_agreements':7,'pending_controls':1,'scope':'Exact source/context/provider native observations through public CLI; unsupported valid variadic is a boundary, never agreement.'};(D/'report.json').write_text(json.dumps(report,indent=2));print(D)
