from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,tempfile
R=Path.cwd();K=R/'.tools/review10-parameter-phase-first';sys.path.insert(0,str(R/'tests'));import corpus
sys.path.insert(0,str(R/'tests/semantics'));import function_scope as fs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-parameter-phpt-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes());before=fs.q.t.syntax_validation.implementation_fingerprint();records=[]
paths=['vendor/php-src/Zend/tests/return_types/void_parameter.phpt','vendor/php-src/Zend/tests/variadic/no_default_error.phpt'];ledger=json.loads((R/'tests/phase-discrepancies.json').read_text());(D/'ledger.json').write_text(json.dumps(ledger,indent=2))
frontends=[]
try:
 for root in [R,K]:frontends.append(Worker([str(root/'.tools/php/bin/php'),'-n',*fs.q.t.FLAGS,'-d','extension='+str(root/'.tools/php-file.so'),str(root/'frontend/worker.php')],D/('baseline-wire' if root==R else 'candidate-wire')))
 for rel in paths:
  item=corpus.phpt(R/rel);source=base64.b64decode(item['source_b64']);assert item['ini']=={};name=Path(rel).stem;d=D/name;d.mkdir();p=d/'source.php';p.write_bytes(source);(d/'extracted.json').write_text(json.dumps(item,indent=2));(d/'original.phpt').write_bytes((R/rel).read_bytes());assert item['sha256'] in (R/'tests/phase-discrepancies.json').read_text()
  entries=[b'LC_ALL=C',b'TZ=UTC',b'FIRST=one'];payload=d/'request.input';payload.write_bytes(fs.q.packet(1700000000,125000,entries));request={'env':[[fs.q.b64(k),fs.q.b64(v)] for k,v in(e.split(b'=',1)for e in entries)],'argv':[fs.q.b64(os.fsencode(p))],'file':fs.q.b64(os.fsencode(p)),'seconds':'1700000000','microseconds':125000,'variables':fs.q.b64(b'EGPCS'),'jit':True,'cwd':fs.q.b64(os.fsencode(d))};(d/'request.json').write_text(json.dumps(request));native=fs.native(p,payload,d)
  cmd=[str(fs.q.t.PHP),'-n',*fs.q.t.FLAGS,'-l',str(p)];z=subprocess.run(cmd,capture_output=True,env=fs.q.t.ENV,timeout=10);(d/'lint.command.json').write_text(json.dumps(cmd));(d/'lint.stdout').write_bytes(z.stdout);(d/'lint.stderr').write_bytes(z.stderr);(d/'lint.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}));assert z.returncode==255
  row={'id':name,'phpt':rel,'extracted':item,'source_base64':fs.q.b64(source),'context':str(p),'request':request,'native':native,'results':[]}
  for root,f in zip([R,K],frontends):
   tag='baseline' if root==R else 'candidate';oracle=f.request({'op':'oracle','source':fs.q.b64(source)});parsed=f.request({'op':'parse','source':fs.q.b64(source)});assert oracle['accepted'];assert parsed['accepted']==(root==K)
   cmd=[str(root/'bin/php-semantics'),str(p),'--request-context',str(d/'request.json')];z=subprocess.run(cmd,capture_output=True,timeout=60);(d/(tag+'.command.json')).write_text(json.dumps(cmd));(d/(tag+'.stdout')).write_bytes(z.stdout);(d/(tag+'.stderr')).write_bytes(z.stderr);(d/(tag+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':z.returncode}));actual=json.loads(z.stdout);assert not z.stderr
   if root==R:assert actual['status']=='frontend_failure' and z.returncode==1
   else:assert actual['status']=='static_rejection' and z.returncode==0 and all(actual[k]==native[k] for k in ('stdout','stderr','exit_status'))
   row['results'].append({'profile':tag,'oracle':oracle,'parsed':parsed,'actual':actual});print(name,tag,actual['status'],flush=True)
  records.append(row);(D/'records.json').write_text(json.dumps(records,indent=2))
finally:
 for f in frontends:f.close()
assert fs.q.t.syntax_validation.implementation_fingerprint()==before
report={'result':'pass','baseline':before,'candidate':json.loads((K/'inputs.json').read_text())['fingerprint'],'raw':str(D),'records':records,'scope':'Exact two retired ledger PHPT FILE bytes, native parser and lint, original frontend failures, repaired checked parser and public CLI native static agreement.'};(D/'report.json').write_text(json.dumps(report,indent=2));print(D,flush=True)
