<?php
$a="1";$bad=[];function f(int &...$xs){echo "BODY";}
@f($a,$a,$bad);echo "AFTER";