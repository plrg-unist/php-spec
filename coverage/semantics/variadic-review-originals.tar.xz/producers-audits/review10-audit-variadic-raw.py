from pathlib import Path
import json,sys
R=Path.cwd();sys.path.insert(0,str(R/'tests/semantics'));import static_types as types
names=['review10-variadic-originals-lalv_ymm','review10-return-reference-replay-i2p53eit','review10-return-reference-replay-_v_mlvca','review10-variadic-protocol-srwkibqy','review10-variadic-protocol-v_tqr3w_','review10-variadic-protocol-_q4q_e27','review10-variadic-protocol-azmdgcmf','review10-variadic-protocol-qb64qx36','review10-variadic-protocol-zvyl3fd3','review10-variadic-protocol-wr0adgye','review10-variadic-protocol-otohwdyj','review10-variadic-protocol-5pdiths0','review10-variadic-state-drda55ua','review10-variadic-compatibility-umre80ld'];rows=[];failed=[];fixture_failures=[]
for name in names:
 root=R/'.tools'/name;nr=nc=ns=nf=0
 for f in root.rglob('*.response'):
  if 'original-inputs' in f.parts:continue
  x=types.wire.loads(f.read_text());types.wire.loads(f.with_suffix('.request').read_text());nr+=1
  if not x['ok']:assert 'casify.ml' in x['message'];failed.append({'path':str(f),'packet':x})
 for f in root.rglob('close.json'):
  if 'original-inputs' in f.parts:continue
  x=json.load(open(f));assert x['status']=='exit' and x['exit_status']==x['final_exit_status']==0;assert (f.parent/'stderr').read_bytes()==(f.parent/'trailing.stdout').read_bytes()==b'';nc+=1
 for f in root.rglob('*.command.json'):
  if 'original-inputs' in f.parts:continue
  cmd=json.load(open(f))
  if not isinstance(cmd,list) or not cmd[0].endswith('/numeric_runner.exe'):continue
  prefix=str(f).removesuffix('command.json');status=json.load(open(prefix+'status.json'));stdout=Path(prefix+'stdout').read_bytes();stderr=Path(prefix+'stderr').read_bytes()
  if name in ['review10-variadic-protocol-v_tqr3w_','review10-variadic-protocol-_q4q_e27']:
   assert status['status']=='exit' and status['exit_status']!=0 and b'syntax error' in stderr;fixture_failures.append({'path':str(f),'status':status,'stderr':stderr.decode()});nf+=1
  else:assert status['status']=='exit' and status['exit_status']==0 and stdout.strip()==b'true' and not stderr,(name,f,status,stdout,stderr);ns+=1
 rows.append({'raw':name,'responses':nr,'clean_closures':nc,'standalone_true':ns,'fixture_failures':nf})
report={'result':'pass','rows':rows,'decoded_responses':sum(r['responses'] for r in rows),'clean_worker_closures':sum(r['clean_closures'] for r in rows),'standalone_true':sum(r['standalone_true'] for r in rows),'retained_runner_failures':failed,'retained_fixture_failures':fixture_failures,'scope':'Actual original951 sources, first953 SL failure, repaired5157 sources and finite mutation originals, guarded953 controls, final semantic959 dense4 and two exact951 bridges. Failed SL response and four event-literal fixture syntax errors remain distinct from agreements.'};(R/'.tools/review10-variadic-raw-audit.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k not in ['rows','retained_runner_failures','retained_fixture_failures']})
