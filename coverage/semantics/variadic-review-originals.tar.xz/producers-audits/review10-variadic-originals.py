from pathlib import Path
import sys
R=Path.cwd();sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as fs
CASES={
 'variadic-empty-return-reference-cells':b'<?php function &f(int &...$xs){return $xs;}$a=&f();$b=&f();$a[]=1;echo $a[0],$b[0]??"N";',
 'variadic-suppressed-late-alias-error':b'<?php\n$a="1";$bad=[];function f(int &...$xs){echo "BODY";}\n@f($a,$a,$bad);echo "AFTER";',
}
fs.main(CASES,'review10-variadic-originals',Path(__file__))
