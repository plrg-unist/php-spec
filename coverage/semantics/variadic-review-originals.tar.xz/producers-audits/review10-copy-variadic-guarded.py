from pathlib import Path
import hashlib,json,shutil,stat
R=Path.cwd();S=R/'.tools/runtime7-variadic-guarded';K=R/'.tools/review10-variadic-guarded';m=json.loads((S/'inputs.json').read_text());b=json.loads((R/'.tools/review10-parameter-phase-first/inputs.json').read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for n,h in m['files'].items():
 p=S/n;assert sha(p)==h and stat.S_IMODE(p.stat().st_mode)==m['modes'][n],n;q=K/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copy2(S/'inputs.json',K/'inputs.json');print(m['fingerprint']);print('Changed', [n for n in b['files'] if m['files'][n]!=b['files'][n]]);print('Added',set(m['files'])-set(b['files']))
