from pathlib import Path
import hashlib,json,os,subprocess,sys,tempfile
R=Path.cwd();K=Path(sys.argv[1]).resolve();repaired='--repaired' in sys.argv;sys.path.insert(0,str(K/'tests/semantics'))
import request_environment as q
import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-variadic-protocol-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes());before=q.t.syntax_validation.implementation_fingerprint();print(D,flush=True)
row=json.loads((R/'.tools/review10-variadic-originals-lalv_ymm/report.json').read_text())['records'][1];(D/'original.json').write_text(json.dumps(row,indent=2));(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'fingerprint':before},indent=2));f=a=None
try:
 f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire');a=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire');parsed=f.request({'op':'parse','source':row['source_base64']});assert parsed['accepted'];checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(D/'checked.json').write_text(json.dumps(checked))
finally:
 try:
  if f:f.close()
 finally:
  if a:a.close()
initial='$php_request_run('+checked['fixture']+', 0, '+json.dumps(q.b64(os.fsencode(row['context'])))+', '+rs.request_fixture(row['request'])+')'
prefix='''dec $review_stage(pstate) : bool
def $review_stage(S) = true -- if S.TODO = [VARIADIC_RECEIVE porigin 2]
def $review_stage(S) = false -- otherwise
dec $review_find(pstate, nat) : pstate
def $review_find(S, n) = S -- if $review_stage(S)
def $review_find(S, n) = $review_find(S_next[.COMPLETION = NORMAL], n_rest)
  -- if ~$review_stage(S)
  -- if $(n > 0)
  -- if n_rest = $(n - 1)
  -- if S_next = $drive_steps(S, 1)
'''
common=['S_initial = '+initial,'S = $review_find(S_initial[.COMPLETION = NORMAL], 200)','S.TODO = [VARIADIC_RECEIVE porigin 2]','S.CURRENT = (pcallcontext)','pcallcontext.FUNCTION = porigin','pcallcontext.CALLSITE = (porigin_call)','pcallcontext.EXTRA = [REFERENCE n_shared, REFERENCE n_shared, REFERENCE n_bad]','S.STORE[n_shared] = DEFINED (PINT 1)','$lookup(S.ENV, [120, 115]) = (n_tail)','S.STORE[n_tail] = DEFINED (PARRAY n_array)','$call_descriptors_valid(S)']
variants=[('control','S',True),('receive-wrong-function','S[.TODO = [VARIADIC_RECEIVE porigin_call 2]]',False),('receive-wrong-origin','S[.ORIGIN = (porigin_call)]',False),('receive-skip-last','S[.TODO = [VARIADIC_RECEIVE porigin 3]]',False),('receive-outside-arguments','S[.TODO = [VARIADIC_RECEIVE porigin 99]]',False),('receive-rewind-tail','S[.TODO = [VARIADIC_RECEIVE porigin 0]]',False),('receive-reset-tail','S[.TODO = [VARIADIC_BEGIN porigin]]',False),('receive-tail-not-array','S[.STORE = $set_cell(S.STORE, n_tail, DEFINED (PINT 99))]',False),('receive-arbitrary-result','S[.RESULT = KNOWN (PINT 99)]',True),('receive-shared-value-evolution','S[.STORE = $set_cell(S.STORE, n_shared, DEFINED (PINT 7))]',True)]
variants += [('receive-nonpacked-key','S[.ARRAYS = $array_replace(S.ARRAYS, n_array, $array_insert($array_insert($array_empty(), KINT 0, ALIAS n_shared), KINT 2, ALIAS n_shared))]',False),('receive-wrong-next','S[.ARRAYS = $array_replace(S.ARRAYS, n_array, S.ARRAYS[n_array][.NEXT = 3])]',False),('receive-arbitrary-collected-value','S[.ARRAYS = $array_replace(S.ARRAYS, n_array, $array_insert(S.ARRAYS[n_array], KINT 0, DIRECT (PINT 99)))]',True),('receive-extra-queue','S[.TODO = [(VARIADIC_RECEIVE porigin 2), DISCARD]]',False)]
if os.environ.get('BEGIN'):
 prefix=prefix.replace('S.TODO = [VARIADIC_RECEIVE porigin 2]','S.TODO = [VARIADIC_BEGIN porigin]')
 common=['S_initial = '+initial,'S = $review_find(S_initial[.COMPLETION = NORMAL], 200)','S.TODO = [VARIADIC_BEGIN porigin]','S.CURRENT = (pcallcontext)','pcallcontext.FUNCTION = porigin','pcallcontext.CALLSITE = (porigin_call)','$call_descriptors_valid(S)']
 variants=[('begin-control','S',True),('begin-wrong-function','S[.TODO = [VARIADIC_BEGIN porigin_call]]',False),('begin-wrong-origin','S[.ORIGIN = (porigin_call)]',False),('begin-tail-already-defined','$write_name(S, [120, 115], PINT 99)',False),('begin-before-array','S[.TODO = [VARIADIC_RECEIVE porigin 0]]',False),('begin-arbitrary-result','S[.RESULT = KNOWN (PINT 99)]',True)]
modules=[K/p for p in json.loads((K/'spec/semantics/modules.json').read_text())];runner=K/'tests/semantics/_build/default/numeric_runner.exe';records=[]
for name,change,valid in variants:
 if os.environ.get('ONLY') and name not in os.environ['ONLY'].split(','):continue
 expected=valid or not repaired;checks=common+['S_changed = '+change,'$heap_valid($heap_graph(S_changed))','$call_descriptors_valid(S_changed) = '+str(expected).lower(),'S_zero = $drive(S_changed, 0)','S_zero.COMPLETION = '+('BUDGET' if expected else 'UNSUPPORTED "invalid compiled function descriptor"')]
 if not repaired and name in ['receive-skip-last','receive-outside-arguments']:
  checks+=['S_bypass = $drive(S_changed, 10000)','S_bypass.COMPLETION = NORMAL','S_bypass.REPORTING = 30719']
 if valid or repaired:
  checks+=['S_full = $drive(S_changed, 10000)','S_full.COMPLETION = '+('THROWN "TypeError" n_message* 2' if valid else 'UNSUPPORTED "invalid compiled function descriptor"')]
  if valid:checks+=['S_full.REPORTING = 30719','S_full.FRAMES = eps','S_full.CURRENT = eps','S_full.HELD = eps','S_full.SILENCES = eps','$heap_valid($heap_graph(S_full))']
 fixture=D/(name+'.watsup');fixture.write_text(prefix+'\ndec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+c+'\n' for c in checks));cmd=[str(runner),*map(str,modules),str(fixture)];(D/(name+'.command.json')).write_text(json.dumps(cmd));z=subprocess.run(cmd,capture_output=True,timeout=60);(D/(name+'.stdout')).write_bytes(z.stdout);(D/(name+'.stderr')).write_bytes(z.stderr);(D/(name+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':z.returncode}));item={'id':name,'valid':valid,'assertions':len(checks),'pass':z.returncode==0 and z.stdout.strip()==b'true' and not z.stderr};records.append(item);(D/'results.json').write_text(json.dumps(records,indent=2));print(item,flush=True)
assert before==q.t.syntax_validation.implementation_fingerprint();(D/'report.json').write_text(json.dumps({'result':'pass' if all(r['pass'] for r in records) else 'fail','fingerprint':before,'raw':str(D),'repaired':repaired,'records':records},indent=2))
