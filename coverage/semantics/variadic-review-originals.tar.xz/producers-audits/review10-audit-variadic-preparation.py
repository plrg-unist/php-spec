from pathlib import Path
import hashlib,json,sys,tarfile
R=Path.cwd();D=R/'.tools/compiler7-callable-next';sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda b:hashlib.sha256(b).hexdigest();a=json.loads((D/'archive.json').read_text());blob=D/'originals.tar.xz';assert sha(blob.read_bytes())==a['sha256'];data={}
with tarfile.open(blob,'r|xz') as t:
 for e in t:
  if e.name=='SHA256.json':m=json.load(t.extractfile(e));continue
  b=data[e.linkname] if e.islnk() else t.extractfile(e).read();assert sha(b)==m['files'][e.name] and e.mode==m['modes'][e.name];data[e.name]=b
assert set(data)==set(m['files']) and len(data)==592
assert sha(data['baseline-suppression-compiler-2cb.tar.xz'])==a['baseline_archive']=='2cb921c7788ab453380f79aeb2259977efec3532d45f89edaa3091d7769ccae7'
f=json.loads((R/'.tools/review10-return-final/inputs.json').read_text());known={f['files'][n] for n in ['.tools/php/bin/php','.tools/php-file.so','.tools/request-clock.so','_build/default/adapter/main.exe','tests/semantics/_build/default/numeric_runner.exe']}
for n,v in m['tools'].items():assert v['sha256'] in known and v['mode']==436,(n,v)
responses=closures=0
for n,b in data.items():
 if n.endswith('/close.json'):
  p=n[:-10];assert json.loads(b)=={'status':'exit','exit_status':0,'final_exit_status':0};assert not data[p+'stderr'] and not data[p+'trailing.stdout']
  for i in range(len([k for k in data if k.startswith(p) and k.endswith('.request')])):wire.loads(data[p+str(i)+'.request'].decode());assert wire.loads(data[p+str(i)+'.response'].decode())['ok'];responses+=1
  closures+=1
out={'result':'pass','archive':a['sha256'],'paths':len(data),'tools':len(m['tools']),'responses':responses,'clean_closures':closures,'baseline_archive':a['baseline_archive'],'baseline942_observations':a['baseline942'],'native_originals':a['native_originals'],'separate_opcode_profiles':a['separate_opcode_profiles'],'scope':'Full592 archived payload hashes/modes and snapshot tool-copy bindings; nested2cb exacthash uses accepted independent audit. Native16, same-source lint16 and separate instrumentation14 remain distinct. LaterSTARTUP/parser-boundary sidecar is outside this archive; no next implementation acceptance.'};(R/'.tools/review10-variadic-preparation-audit.json').write_text(json.dumps(out,indent=2));print(out)
