from pathlib import Path
import hashlib,io,json,lzma,stat,tarfile
R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();files={};modes={};tools={}
def add(n,p):
 raw=p.read_bytes();mode=stat.S_IMODE(p.stat().st_mode)
 if p.name in ['php','php-file.so','request-clock.so','main.exe','numeric_runner.exe']:tools[n]={'sha256':sha(raw),'mode':mode};return
 files[n]=raw;modes[n]=mode
def tree(n,p):
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':add(n+'/'+str(f.relative_to(p)),f)
raw=json.load(open(R/'.tools/review10-variadic-raw-audit.json'))
for row in raw['rows']:tree('raw/'+row['raw'],R/'.tools'/row['raw'])
snapshots={}
for name,root in [('original951-c650','review10-suppression-final'),('baseline951-440f','review10-parameter-phase-first'),('failed953-7791','review10-variadic-first'),('runnable953-5157','review10-variadic-trace'),('guarded953-c47c','review10-variadic-guarded'),('semantic959-cee5','review10-variadic-final'),('expectation959-4d69','review10-variadic-accepted-tests')]:
 p=R/'.tools'/root;m=json.load(open(p/'inputs.json'));snapshots[name]=m['fingerprint'];add('snapshots/'+name+'/inputs.json',p/'inputs.json')
 for rel,h in m['files'].items():assert sha((p/rel).read_bytes())==h and stat.S_IMODE((p/rel).stat().st_mode)==m['modes'][rel];add('snapshots/'+name+'/'+rel,p/rel)
for pattern in ['review10*variadic*.py','review10-variadic-*-audit.json']:
 for p in sorted((R/'.tools').glob(pattern)):add('producers-audits/'+p.name,p)
m={'files':{n:sha(b) for n,b in files.items()},'modes':modes,'tools':tools};out=R/'.tools/review10-variadic-review-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 raw=(json.dumps(m,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,b in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(sha(b),modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(b);t.addfile(z,io.BytesIO(b))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in m['files'].items():assert sha(t.extractfile(n).read())==h and t.getmember(n).mode==modes[n]
report={'archive':str(out),'sha256':sha(out.read_bytes()),'paths':len(files),'bytes':out.stat().st_size,'snapshots':snapshots,'tool_bindings':tools,'decoded_responses':70,'clean_worker_closures':29,'standalone_true':46,'retained_SL_failures':1,'retained_fixture_syntax_failures':4,'scope':'Seven exact source/tool maps; independent original951 sources, failed953 SL request, runnable/guarded actual-source protocol controls and bypasses, semantic959 source4/dense4/1322 and two exact951 state bridges. Compilerd286/56f retain separately linked historical known/deferred source origins; tool bytes bound by SHA/mode, active binaries in separately archived runtime evidence. Nonexecuted original-input copies retain0664 mode. Subsequent allowance/publication changes require their own explicit bridge.'};(R/'.tools/review10-variadic-review-originals.json').write_text(json.dumps(report,indent=2));print(report['sha256'],report['paths'],report['bytes'])
