from pathlib import Path
import hashlib,json,os,sys,tempfile
R=Path.cwd();K=Path(sys.argv[1]).resolve();B=R/'.tools/review10-parameter-phase-first';sys.path.insert(0,str(K/'tests/semantics'))
import request_environment as q
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-variadic-compatibility-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();before=q.t.syntax_validation.implementation_fingerprint()
reports=[R/'.tools/review10-types-originals-brma4fpo/report.json',R/'.tools/review10-reference-originals-njtxxlzj/report.json']
rows={r['id']:r for p in reports for r in json.loads(p.read_text())['records']}
selected=['typed-default-scalar-cache-before-array-error','valuecall-nested-array-owner'];budgets=[0,8,16,32,64,128,10000]
(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'fingerprint':before,'baseline':json.loads((B/'inputs.json').read_text()),'reports':{str(p):sha(p) for p in reports}},indent=2))
records=[];f=old=new=None
try:
 f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire')
 old=Worker([str(B/'_build/default/adapter/main.exe'),str(B)],D/'baseline-wire');new=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'candidate-wire')
 for name in selected:
  row=rows[name];d=D/name;d.mkdir();(d/'original.json').write_text(json.dumps(row,indent=2))
  parsed=f.request({'op':'parse','source':row['source_base64']});assert parsed['accepted']
  cuts=[]
  for budget in budgets:
   req={'op':'execute','ast':parsed['ast'],'steps':budget,'filename':q.b64(os.fsencode(row['context'])),'request':row['request']}
   left=old.request(req);right=new.request(req)
   (d/(str(budget)+'.baseline.json')).write_text(json.dumps(left));(d/(str(budget)+'.candidate.json')).write_text(json.dumps(right))
   assert left==right,(name,budget)
   cuts.append({'budget':budget,'all_existing_fields_equal':True,'saved_frames':len(right['state']['FRAMES'])})
  actual=q.cli.observe(right['state'],row['context']);assert all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  records.append({'id':name,'cuts':cuts});print(name,'exact',flush=True)
finally:
 try:
  if f:f.close()
 finally:
  try:
   if old:old.close()
  finally:
   if new:new.close()
assert before==q.t.syntax_validation.implementation_fingerprint()
result={'result':'pass','fingerprint':before,'raw':str(D),'records':records,'scope':'Two existing951/440f nonvariadic programs at seven budgets: every complete response/state field is exactly equal, with no projection. Exact retained source/native/request contexts; cached default type failure and nested call-result reference-assignment ownership.'}
(D/'report.json').write_text(json.dumps(result,indent=2));print('pass',flush=True)
