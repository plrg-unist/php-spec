from pathlib import Path
import hashlib,io,json,lzma,stat,sys,tarfile
R=Path.cwd();A=R/'.tools/compiler7-variadic';sys.path.insert(0,str(R/'tests/semantics'));import static_types as types
sha=lambda b:hashlib.sha256(b).hexdigest();meta=json.loads((A/'archive.json').read_text());p=A/'originals.tar.xz';assert sha(p.read_bytes())==meta['sha256'];data={}
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(p.read_bytes())),mode='r:') as t:
 m=json.load(t.extractfile('SHA256.json'));assert len(m['files'])==meta['paths'];assert set(t.getnames())==set(m['files'])|{'SHA256.json'}
 for n,h in m['files'].items():
  raw=t.extractfile(n).read();assert sha(raw)==h and t.getmember(n).mode==m['modes'][n],n
  if n.endswith(('.response','.request','close.json','stderr','trailing.stdout','report.json')):data[n]=raw
for n,v in m['tools'].items():
 label,rel=n.split('/',1);root={'baseline951':R/'.tools/runtime7-variadic-baseline-parser951','first953':R/'.tools/runtime7-variadic-first'}.get(label,A/label);p=root/rel;assert sha(p.read_bytes())==v['sha256'] and stat.S_IMODE(p.stat().st_mode)==v['mode'],n
responses=closures=0;failures=[]
for n,raw in data.items():
 if n.endswith('.response'):
  packet=types.wire.loads(raw.decode());assert n[:-9]+'.request' in data;types.wire.loads(data[n[:-9]+'.request'].decode());responses+=1
  if not packet['ok']:failures.append({'path':n,'response':packet});assert packet['category']=='runner_failure' and 'casify.ml' in packet['message'],(n,packet)
 if n.endswith('/close.json'):
  x=json.loads(raw);assert x['status']=='exit' and x['exit_status']==x['final_exit_status']==0,n;stem=n[:-10];assert data[stem+'stderr']==data[stem+'trailing.stdout']==b'',n;closures+=1
report={'result':'pass','archive':meta['sha256'],'paths':len(m['files']),'tool_bindings':len(m['tools']),'decoded_responses':responses,'clean_worker_closures':closures,'retained_failed_responses':failures,'compiler_manifest':meta,'raw_reports':{n:json.loads(v) for n,v in data.items() if n.endswith('/report.json')}};(R/'.tools/review10-variadic-compiler-archive-audit.json').write_text(json.dumps(report,indent=2));print({k:v for k,v in report.items() if k not in ['raw_reports','compiler_manifest']})
