from pathlib import Path
import base64,hashlib,json,sys
R=Path.cwd();K=R/'.tools/runtime7-variadic-final';sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q
m=json.load(open(K/'inputs.json'));reports=['variadic.json','variadic-compiler.json','variadic-protocol.json','variadic-regressions.json','variadic-state.json'];rows=[];responses=closures=standalone=natives=0
for name in reports:
 p=K/'coverage/semantics'/name
 if not p.exists():continue
 x=json.load(open(p));assert x['result']=='pass';raw=Path(x['raw']);raw=raw if raw.is_absolute() else K/raw;nr=nc=ns=nn=0
 for f in raw.rglob('*.response'):
  if 'original-inputs' in f.parts:continue
  out=q.t.wire.loads(f.read_text());assert out['ok'],f;q.t.wire.loads(f.with_suffix('.request').read_text());nr+=1
 for f in raw.rglob('close.json'):
  if 'original-inputs' in f.parts:continue
  out=json.load(open(f));assert out['status']=='exit' and out['exit_status']==out['final_exit_status']==0;assert (f.parent/'stderr').read_bytes()==(f.parent/'trailing.stdout').read_bytes()==b'';nc+=1
 for f in raw.rglob('*.command.json'):
  if 'original-inputs' in f.parts:continue
  cmd=json.load(open(f))
  if not isinstance(cmd,list) or not cmd[0].endswith('/numeric_runner.exe'):continue
  prefix=str(f).removesuffix('command.json');status=json.load(open(prefix+'status.json'));assert status['status']=='exit' and status['exit_status']==0;assert Path(prefix+'stdout').read_bytes().strip()==b'true' and Path(prefix+'stderr').read_bytes()==b'';ns+=1
 for row in x.get('records',[]):
  if 'native' not in row:continue
  source=base64.b64decode(row['source_base64']);d=Path(row['context']).parent;assert Path(row['context']).read_bytes()==source
  native=row['native'];assert (d/'native.stdout').read_bytes()==base64.b64decode(native['stdout']);assert (d/'native.stderr').read_bytes()==base64.b64decode(native['stderr']);assert json.load(open(d/'native.status.json'))['exit_status']==native['exit_status'];assert row.get('pass',True)
  req=row['request'];entries=[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in req['env']];assert (d/'request.input').read_bytes()==q.packet(int(req['seconds']),req['microseconds'],entries);assert all(row['actual'][k]==native[k] for k in ['stdout','stderr','exit_status']);nn+=1
 rows.append({'report':name,'raw':str(raw),'responses':nr,'closures':nc,'standalone':ns,'native_runtime_agreements':nn});responses+=nr;closures+=nc;standalone+=ns;natives+=nn
for n,h in m['files'].items():assert hashlib.sha256((K/n).read_bytes()).hexdigest()==h
report={'result':'pass','fingerprint':m['fingerprint'],'reports':rows,'decoded_responses':responses,'clean_worker_closures':closures,'standalone_true':standalone,'native_runtime_agreements':natives,'scope':'Source28 and selected8 regression native packets verified; protocol fresh native separately retained in its original/state packet. Compiler native lint phases remain distinct; counts overlap. Final semantic959/cee5 inputs unchanged.'};(R/'.tools/review10-variadic-author-audit.json').write_text(json.dumps(report,indent=2));print(report)
