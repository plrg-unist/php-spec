from pathlib import Path
import hashlib,io,json,lzma,stat,tarfile
R=Path(__file__).resolve().parent;B=R.parents[1];C=R/'candidate';files={};modes={};bindings={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,p):
 m=stat.S_IMODE(p.stat().st_mode)
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  bindings[n]={'sha256':sha(p),'mode':m};return
 files[n]=p.read_bytes();modes[n]=m
def tree(n,p):
 for f in sorted(p.rglob('*')):
  if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':add(n+'/'+str(f.relative_to(p)),f)
def snapshot(label,root,manifest):
 m=json.loads(manifest.read_text());add(label+'/inputs.json',manifest)
 for n,h in m['files'].items():assert sha(root/n)==h and stat.S_IMODE((root/n).stat().st_mode)==m['modes'][n],n;add(label+'/'+n,root/n)
 return m
base=B/'.tools/runtime7-variadic-baseline-parser951';baseline=snapshot('baseline951',base,base/'inputs.json')
first=B/'.tools/runtime7-variadic-first';snapshot('first953',first,first/'inputs.json')
m=snapshot('candidate',C,C/'compiler-inputs.json');tree('candidate',C)
for p in sorted(R.iterdir()):
 if p.is_dir() and p not in [C,R/'publication']:tree(p.name,p)
 elif p.is_file() and p.suffix in ['.py','.md','.json','.watsup'] and p.name!='archive.json':add(p.name,p)
tree('new-originals951',base/'.tools/compiler7-variadic-originals-bgs9yf2q')
add('historical/preparation56f.tar.xz',B/'.tools/compiler7-callable-next/originals.tar.xz')
hashes={n:hashlib.sha256(v).hexdigest() for n,v in files.items()};out=R/'originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 raw=(json.dumps({'files':hashes,'modes':modes,'tools':bindings},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,raw in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(hashes[n],modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(raw);t.addfile(z,io.BytesIO(raw))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
report={'archive':'variadic-compiler-originals.tar.xz','sha256':sha(out),'bytes':out.stat().st_size,'paths':len(files),'tools':bindings,'baseline':baseline['fingerprint'],'candidate':m['fingerprint'],'pairing_base':json.loads((C/'paired-trace-inputs.json').read_text())['fingerprint'],'gates':{'new_originals':7,'preoptimizer_profiles':7,'compiler_phase_agreements':23,'pending_catch_boundaries':2,'source_projections':194,'reference_return_phases':58,'reference_return_projections':49,'suppression_phases':17,'suppression_projections':131,'signature_comparisons':359,'signature_descriptors':28,'signature_return_reference_checks':174,'send_kind_phases':12,'send_kind_projections':36},'history':{'preparation56f':hashes['historical/preparation56f.tar.xz']},'scope':'Compiler102 positional variadic signature admission and known reference-tail send classification. Source/runtime ordinary replays and guarded final pairing are separately recorded by runtime/review. Full maps, source requests, native/lint/preoptimizer output, worker packets/closures and failed producer versions retained. Executable tools bound by hash/mode. Signature build request explicitly not run: unchanged executable build inputs, dynamic semantic modules supplied. No named/unpack/catch activation or callable-family closure.'}
(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
