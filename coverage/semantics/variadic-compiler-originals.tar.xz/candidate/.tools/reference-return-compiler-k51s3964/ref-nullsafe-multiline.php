<?php
function &f(){
 return
 $x?->a;
}