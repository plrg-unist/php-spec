<?php
function &f(){return $GLOBALS["missing"];}
f();echo $missing,"DONE";