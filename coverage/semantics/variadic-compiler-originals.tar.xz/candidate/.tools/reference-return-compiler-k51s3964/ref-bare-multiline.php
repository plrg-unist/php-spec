<?php
function &f()
{
 return;
}
f();