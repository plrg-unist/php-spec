<?php
function g(){return [];}
function &f():int {
 return
 g();
}
f();