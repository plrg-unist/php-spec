<?php $x=1;$c=1;function &f(){global $x;return $x;}function h($v){return $v;}
false?0:f();