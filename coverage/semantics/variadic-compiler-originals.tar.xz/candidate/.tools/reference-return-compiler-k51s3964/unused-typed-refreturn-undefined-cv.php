<?php
function &f():int{return $missing;}
f();echo "DONE";