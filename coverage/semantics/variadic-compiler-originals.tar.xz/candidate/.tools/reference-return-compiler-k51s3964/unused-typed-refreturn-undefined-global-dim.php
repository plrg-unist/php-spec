<?php
function &f():int{return $GLOBALS["missing"];}
f();echo "DONE";