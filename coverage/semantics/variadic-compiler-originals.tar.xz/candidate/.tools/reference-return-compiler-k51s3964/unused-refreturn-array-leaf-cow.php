<?php
$a=[1];function &f(){global $a;return $a[0];}
f();$b=$a;$b[0]=2;echo $a[0],$b[0];