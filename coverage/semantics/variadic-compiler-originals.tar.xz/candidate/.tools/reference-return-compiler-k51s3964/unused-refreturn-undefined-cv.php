<?php
function &f(){return $missing;}
f();echo "DONE";