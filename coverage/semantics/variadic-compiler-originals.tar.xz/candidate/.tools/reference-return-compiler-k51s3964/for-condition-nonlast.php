<?php $x=1;$c=1;function &f(){global $x;return $x;}function h($v){return $v;}
for(;f(),false;){}