<?php
$x="2";$alias=&$x;function &f():int{global $x;return $x;}
f();echo $x===2,$alias===2;