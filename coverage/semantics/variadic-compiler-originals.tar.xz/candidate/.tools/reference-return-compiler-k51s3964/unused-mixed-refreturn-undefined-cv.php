<?php
function &f():mixed{return $missing;}
f();echo "DONE";