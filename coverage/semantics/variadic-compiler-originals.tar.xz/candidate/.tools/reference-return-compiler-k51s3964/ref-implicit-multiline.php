<?php
function &f()
{
 $x=1;
}
f();