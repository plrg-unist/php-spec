<?php
function &f():void {
 return
 $x?->a;
}