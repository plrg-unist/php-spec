<?php $x=1;$c=1;function &f(){global $x;return $x;}function h($v){return $v;}
for($i=0;$i<1;f(),$i++){}