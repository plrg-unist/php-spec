<?php
function f(): static {}
