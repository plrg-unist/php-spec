#!/usr/bin/env php
<?php echo 1;