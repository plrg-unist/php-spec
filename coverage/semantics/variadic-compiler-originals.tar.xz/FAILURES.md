# Preserved compiler preparation failures

The immutable first pairing953/77919aed failed actual source execution in the
SpecTec SL casify pass (assertion at83), despite an AL numeric-runner true fixture.
`failed-first102` retains its two compiler files. A minimal accepted951 plus
compiler102 and pure lookup reproducer (`isolate-compiler-only`, producer
`isolate-source-original.py`, raw `source-isolate-eifkfgw9`) isolates the issue.
Reference lookup alone passes (`isolate-reference-only`, `source-isolate-1_bhjwtq`).
The repaired matching head/tail patterns pass (`isolate-compiler-repaired`,
`source-isolate-rwnudacb`). No framework edit was made. A preliminary attempt to
reuse the first diagnostic copy stopped before execution on a read-only copied
runner file; that setup exception has only the retained tool transcript, not a
claimed standalone raw diagnostic capture.

Compiler phase fixture7wzyvk30 used expression_var where NParam requires phpType10;
SpecTec elaboration rejected it before any semantic assertions ran. Fixture
wctm5rhp corrected that domain but accidentally counted two native-only catch
sidecars as ordinary compiler comparisons. The expected Unsupported boundary
caused that gate to fail. Their exact original producer/cases and native lint,
worker and runner outputs remain in each raw directory. Corrected maintained gate
d5ki4fty passes23 source compiler phase comparisons and194 projections, keeping
both catch cases explicit pending controls. These fixture repairs did not change
semantic code or silently remove original sources.
