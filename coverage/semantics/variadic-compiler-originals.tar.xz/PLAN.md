# Positional variadic compiler102

Proceed after reviewed parameter source-phase prerequisite commit and exact fresh
baseline capture. Earlier 951/c650 evidence remains historical; the parser
candidate is 951/440f. Existing immutable preparation56f retains sixteen original
controls, including known/deferred send kind, defaults/priority and partial alias
coercion. Runtime7 owns103; reviewer10 owns independent source/task/state guards.

Compiler102 will admit only a final supported-type variadic parameter through
`ppsupported_params`, preserving existing fixed-prefix recursion and static
signature17/90 priority. An additional known-parameter-reference rule covers
indices beyond the final source descriptor using runtime's pure zero-based
`call_parameter_at`; existing in-range78 behavior remains unchanged. Runtime103
exports lookup and fixed-prefix helpers, receives tails sequentially, preserves
references in EXTRA, and supplies actual-index diagnostics without ($xs).

Retain new native multiline known and deferred typed-tail failures: declaration
line is param_ast->lineno at zend_compile.c7791; RECV_VARIADIC is emitted at7820.
Call instruction line and later multiline bad argument remain distinct. Include
known and deferred by-reference tail lvalues beyond descriptor length, empty
zero-tail/prefix default, fixed typed prefix, reference return and @ wrapping in
focused compiler projections. Use source-derived signature/send metadata, not
runtime-shape inference. Static defaulted/nonfinal variadic failures precede
source activation after prerequisite, retaining exact native priorities.

Freeze each runnable compiler/runtime pairing before source/protocol gates. Run
maintained affected signature/return/send classifications with honest exact
identities; add a bounded maintained variadic compiler gate, not a broad duplicate
suite. Preserve raw original requests, frontend/adapter packets and closures,
native/lint/preoptimizer observations and any failed producers. Review before
canonical activation and coordinate shared index.

Following required slices remain named mapping with explicit omitted required
slots and source evaluation order, then array unpack with numeric/string binding
order; Traversable requires the later object protocol. No callable closure claim.
