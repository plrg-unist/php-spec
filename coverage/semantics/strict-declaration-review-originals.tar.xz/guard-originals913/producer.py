from pathlib import Path
import argparse,base64,hashlib,json,subprocess,sys,tempfile
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);ap.add_argument('--original',action='store_true');a=ap.parse_args();R=Path.cwd();K=a.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'));import request_environment as q;import request_environment_state as rs
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-strict-protocol-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes());rows={r['id']:r for r in json.load(open(R/'.tools/review10-strict-originals-kb3qdtc1/report.json'))['records']};before=q.t.syntax_validation.implementation_fingerprint();modules=[K/p for p in json.load(open(K/'spec/semantics/modules.json'))];runner=K/'tests/semantics/_build/default/numeric_runner.exe';paths=[*modules,runner,K/'_build/default/adapter/main.exe',q.t.PHP,K/'.tools/php-file.so',K/'tests/semantics/recorded_worker.py'];sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();direct={str(p.relative_to(K)):sha(p) for p in paths};(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'closure':before,'direct':direct},indent=2))
for p in paths:
 o=D/'original-inputs'/p.relative_to(K);o.parent.mkdir(parents=True,exist_ok=True);o.write_bytes(p.read_bytes())
f=ad=None;records=[];fixtures=[]
try:
 f=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire');ad=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for name in ['strict-no-function','zero-no-function','weak-no-function-control','strict-cache-skip','sticky-multilist']:
  row=rows[name];d=D/name;d.mkdir();(d/'original.json').write_text(json.dumps(row));p=f.request({'op':'parse','source':row['source_base64']});assert p['accepted'];c=ad.request({'op':'check','ast':p['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(c));out=ad.request({'op':'execute','ast':p['ast'],'steps':10000,'filename':q.b64(row['context'].encode()),'request':row['request']});(d/'state.json').write_text(json.dumps(out));actual=q.cli.observe(out['state'],row['context']);assert all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
  initial='$php_request_run('+c['fixture']+', 0, '+json.dumps(q.b64(row['context'].encode()))+', '+rs.request_fixture(row['request'])+')'
  common=['S_initial = '+initial,'S = S_initial[.COMPLETION = NORMAL]','S.CODE = [pcode]','$call_descriptors_valid(S)']
  for kind,term,valid in [('control','S',True),('unit-strict-flip','S[.CODE = [pcode[.STRICT = ~pcode.STRICT]]]',a.original),('arbitrary-result','S[.RESULT = KNOWN (PINT 99)]',True)]:
   checks=common+['S_changed = '+term,'$call_descriptors_valid(S_changed) = '+str(valid).lower(),'S_zero = $drive(S_changed, 0)','S_full = $drive(S_changed, 10000)']
   checks += ['S_zero.COMPLETION = BUDGET','S_full.COMPLETION = NORMAL'] if valid else ['S_zero.COMPLETION = UNSUPPORTED "invalid compiled function descriptor"','S_full.COMPLETION = S_zero.COMPLETION']
   fixtures.append((d,kind,checks))
  if out['state']['FUNCTIONS']:
   checks=common+['S.FUNCTIONS = [pfunction]','S_changed = S[.FUNCTIONS = [pfunction[.CODE.STRICT = ~pfunction.CODE.STRICT]]]','~$call_descriptors_valid(S_changed)','$drive(S_changed, 0).COMPLETION = UNSUPPORTED "invalid compiled function descriptor"','$drive(S_changed, 10000).COMPLETION = UNSUPPORTED "invalid compiled function descriptor"'];fixtures.append((d,'function-strict-flip',checks))
finally:
 try:
  if f:f.close()
 finally:
  if ad:ad.close()
for d,kind,checks in fixtures:
 p=d/(kind+'.watsup');p.write_text('dec $main() : bool\ndef $main() = true\n'+''.join('  -- if '+c+'\n' for c in checks));cmd=[str(runner),*map(str,modules),str(p)];(d/(kind+'.command.json')).write_text(json.dumps(cmd));r=subprocess.run(cmd,capture_output=True,timeout=60);(d/(kind+'.stdout')).write_bytes(r.stdout);(d/(kind+'.stderr')).write_bytes(r.stderr);(d/(kind+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));row={'id':d.name+'/'+kind,'pass':r.returncode==0 and r.stdout.strip()==b'true' and not r.stderr,'assertions':len(checks)};records.append(row);(D/'results.json').write_text(json.dumps(records,indent=2));print(row,flush=True)
assert before==q.t.syntax_validation.implementation_fingerprint();assert all(sha(K/p)==h for p,h in direct.items());(D/'report.json').write_text(json.dumps({'result':'pass' if all(r['pass'] for r in records) else 'fail','original_guard_gaps':a.original,'fingerprint':before,'records':records,'assertions':sum(r['assertions'] for r in records)},indent=2))
