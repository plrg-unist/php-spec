from pathlib import Path
import json,sys,hashlib
R=Path.cwd();sys.path.insert(0,str(R/'frontend'));import wire
roots=[R/p for p in ['.tools/review10-strict-originals-kb3qdtc1','.tools/review10-strict-protocol-ijda206t','.tools/review10-strict-replay-wmz21t47','.tools/review10-strict-replay-5z_7wjr3','.tools/review10-strict-state-77n5f5qu','.tools/review10-strict-weak-bridge-351wef8_','.tools/review10-strict-protocol-628cefb5','.tools/review10-strict-final/.tools/strict-declaration-protocol-e3m_czab']]
records=[]
for root in roots:
 workers=[]
 for p in root.rglob('close.json'):
  d=p.parent;close=json.load(open(p));assert close=={'status':'exit','exit_status':0,'final_exit_status':0},p;assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes();requests=list(d.glob('*.request'));assert len(requests)==len(list(d.glob('*.response')))
  for n in range(len(requests)):
   req=(d/(str(n)+'.request')).read_bytes();res=(d/(str(n)+'.response')).read_bytes();assert req.endswith(b'\n') and res.endswith(b'\n');decoded=wire.loads(res.decode());assert decoded['ok'];wire.loads(req.decode())
  workers.append({'directory':str(d),'responses':len(requests),'clean_closure':True})
 records.append({'root':str(root),'workers':workers,'responses':sum(w['responses'] for w in workers)})
r={'result':'pass','records':records,'responses':sum(x['responses'] for x in records),'clean_closures':sum(len(x['workers']) for x in records),'scope':'Complete recorded worker request/response packets, parseability, ok flags, stderr, trailing stdout and process closures. Includes historical909 originals,913 guard defects and15db partial tool attempt; categories are not semantic agreement counts.'};(R/'.tools/review10-strict-raw-audit.json').write_text(json.dumps(r,indent=2));print(r['responses'],r['clean_closures'])
