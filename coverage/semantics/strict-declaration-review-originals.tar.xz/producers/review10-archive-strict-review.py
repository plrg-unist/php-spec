from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path.cwd();files={};tools={};sha=lambda b:hashlib.sha256(b).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':sha(p.read_bytes()),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
def tree(n,p):
 for f in p.rglob('*'):
  if f.is_file() and '__pycache__' not in f.parts:add(n+'/'+str(f.relative_to(p)),f)
for n,p in [('final917',R/'.tools/review10-strict-final'),('first913',R/'.tools/review10-strict-first')]:
 m=json.load(open(p/'inputs.json'));add(n+'/inputs.json',p/'inputs.json')
 for rel,h in m['files'].items():
  f=p/rel;assert sha(f.read_bytes())==h and stat.S_IMODE(f.stat().st_mode)==m['modes'][rel],rel;add(n+'/'+rel,f)
for label,suffix in [('originals909','originals-kb3qdtc1'),('guard-originals913','protocol-ijda206t'),('partial-precleanup917','replay-wmz21t47'),('source-final','replay-5z_7wjr3'),('state-final','state-77n5f5qu'),('weak-bridge','weak-bridge-351wef8_'),('retained-protocol-final','protocol-628cefb5')]:tree(label,R/('.tools/review10-strict-'+suffix))
tree('fresh-protocol-final',R/'.tools/review10-strict-final/.tools/strict-declaration-protocol-e3m_czab')
for p in R.glob('.tools/review10-*.py'):add('producers/'+p.name,p)
for name in ['strict-archive-audit','strict-raw-audit','strict-author-audit','types-preparation-audit']:
 p=R/('.tools/review10-'+name+'.json');add('audits/'+p.name,p)
for name in ['final-inputs.pre-cleanup.json','protocol-cleanup.json','guard-repair.json']:
 add('runtime-metadata/'+name,R/'.tools/runtime6-strict-directive'/name)
add('baseline909/inputs.json',R/'.tools/review9-defaults-final/inputs.json')
manifest={'files':{n:sha(p.read_bytes()) for n,p in files.items()},'modes':{n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()},'tools':tools};out=R/'.tools/review10-strict-originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 b=(json.dumps(manifest,indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(b);t.addfile(z,io.BytesIO(b))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);key=(manifest['files'][n],manifest['modes'][n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];z.size=0;t.addfile(z)
  else:
   seen[key]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(out) as t:
 for n,h in manifest['files'].items():assert sha(t.extractfile(n).read())==h and t.getmember(n).mode==manifest['modes'][n]
report={'archive':str(out),'sha256':sha(out.read_bytes()),'paths':len(files),'bytes':out.stat().st_size,'tools':tools,'scope':'Independent strict declaration originals909, five accepted forged unit flags913, exact final917 source/state/protocol gates, complete weak909 state bridges, raw audits and producer sources. 15db partial setup replay and driver report-shape failure remain historical; no failed setup or Unsupported counts as semantic agreement. Excluded tool bytes bind exact accepted909 and final917 artifacts by SHA256; copied raw evidence modes remain distinct from invoked tool modes.','baseline':json.load(open(R/'.tools/review9-defaults-final/inputs.json'))['fingerprint'],'final':json.load(open(R/'.tools/review10-strict-final/inputs.json'))['fingerprint']};(R/'.tools/review10-strict-originals-archive.json').write_text(json.dumps(report,indent=2));print(report['sha256'],len(files),report['bytes'])
