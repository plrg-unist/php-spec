from pathlib import Path
import hashlib,json,stat,tarfile
R=Path.cwd();sha=lambda b:hashlib.sha256(b).hexdigest();records=[]
for n,p in [('main',R/'.tools/compiler6-strict-paired/archive.json'),('builtins',R/'.tools/compiler6-strict-paired/builtin-archive.json'),('tests',R/'.tools/compiler6-strict-tests/archive.json')]:
 info=json.loads(p.read_text());a=Path(info['archive']);assert sha(a.read_bytes())==info['sha256'];
 with tarfile.open(a) as t:
  m=json.load(t.extractfile('SHA256.json'));assert len(m['files'])==info['paths'];assert set(t.getnames())==set(m['files'])|{'SHA256.json'}
  for name,h in m['files'].items():assert sha(t.extractfile(name).read())==h and t.getmember(name).mode==m['modes'][name],name
  for name,tool in m.get('tools',{}).items():
   # Tool bytes omitted from compressed originals are bound to the accepted909 runtime artifacts.
   suffix=next(x for x in ['.tools/php/bin/php','.tools/php-file.so','.tools/request-clock.so','_build/default/adapter/main.exe','tests/semantics/_build/default/numeric_runner.exe'] if name.endswith(x))
   f=R/'.tools/review9-defaults-final'/suffix;assert sha(f.read_bytes())==tool['sha256'],name
  records.append({'id':n,'archive':str(a),'sha256':info['sha256'],'paths':len(m['files']),'tools_bound':len(m.get('tools',{})),'all_bytes_modes':True})
old=json.load(open(R/'.tools/review9-defaults-final/inputs.json'));new=json.load(open(R/'.tools/compiler6-strict-paired/final-inputs.json'));delta={p for p in old['files'].keys()|new['files'].keys() if old['files'].get(p)!=new['files'].get(p) or old['modes'].get(p)!=new['modes'].get(p)};assert delta=={'spec/semantics/30-storage.watsup','spec/semantics/33-runtime-compiler.watsup','spec/semantics/78-function-compiler.watsup','spec/semantics/92-strict-compiler.watsup','spec/semantics/modules.json'}
for p,h in new['files'].items():f=R/'.tools/compiler6-strict-paired'/p;assert sha(f.read_bytes())==h and stat.S_IMODE(f.stat().st_mode)==new['modes'][p],p
report={'result':'pass','records':records,'minimal_delta':sorted(delta),'baseline':old['fingerprint'],'compiler':new['fingerprint'],'tool_mode_note':'Preparation copied tool modes checked by candidate manifests; raw original-inputs tool captures deliberately retain copied nonexecutable mode436 and are evidence bytes, not invoked runtime artifacts.'};(R/'.tools/review10-strict-archive-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
