from pathlib import Path
import argparse,copy,hashlib,json,sys,tempfile,stat
ap=argparse.ArgumentParser();ap.add_argument('candidate',type=Path);a=ap.parse_args();R=Path.cwd();new=a.candidate.resolve();old=R/'.tools/review9-defaults-final';sys.path.insert(0,str(new/'tests/semantics'));import request_environment as q
from recorded_worker import Worker
D=Path(tempfile.mkdtemp(prefix='review10-strict-weak-bridge-',dir=R/'.tools'));print(D,flush=True);(D/'producer.py').write_bytes(Path(__file__).read_bytes());manifests={kind:json.load(open(k/'inputs.json')) for kind,k in [('old',old),('new',new)]}
def audit():
 for kind,k in [('old',old),('new',new)]:
  for p,h in manifests[kind]['files'].items():assert hashlib.sha256((k/p).read_bytes()).hexdigest()==h and stat.S_IMODE((k/p).stat().st_mode)==manifests[kind]['modes'][p],(kind,p)
audit();(D/'inputs.json').write_text(json.dumps(manifests,indent=2));rows={r['id']:r for r in json.load(open(R/'.tools/review10-strict-originals-kb3qdtc1/report.json'))['records']};selection=[rows['weak-cache-control'],rows['weak-no-function-control'],json.load(open(R/'.tools/review9-reference-state-0tj_17y7/saved-param-owner/original.json'))];records=[]
def strip(x):
 if isinstance(x,dict):
  if set(x)=={'STRICT','GLOBALS','UNIT','EXPRESSIONS','NAMES','REDIRECTS'}:assert x.pop('STRICT') is False
  for v in x.values():strip(v)
 elif isinstance(x,list):
  for v in x:strip(v)
for row in selection:
 name=row['id'];d=D/name;d.mkdir();(d/'original.json').write_text(json.dumps(row));states={}
 f=Worker([str(new/'.tools/php/bin/php'),'-n',*q.t.FLAGS,'-d','extension='+str(new/'.tools/php-file.so'),str(new/'frontend/worker.php')],d/'frontend-wire')
 try:parsed=f.request({'op':'parse','source':row['source_base64']});assert parsed['accepted']
 finally:f.close()
 for kind,k in [('old',old),('new',new)]:
  w=Worker([str(k/'_build/default/adapter/main.exe'),str(k)],d/(kind+'-wire'))
  try:
   for budget in [0,8,16,32,64,128,10000]:
    out=w.request({'op':'execute','ast':parsed['ast'],'steps':budget,'filename':q.b64(row['context'].encode()),'request':row['request']});(d/(kind+'-'+str(budget)+'.json')).write_text(json.dumps(out));states[kind,budget]=out['state']
  finally:w.close()
 for budget in [0,8,16,32,64,128,10000]:
  projected=copy.deepcopy(states['new',budget]);strip(projected);assert projected==states['old',budget],(name,budget)
 actual=q.cli.observe(states['new',10000],row['context']);assert actual['status'] in ('normal','php_error') and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status']);records.append({'id':name,'budgets':[0,8,16,32,64,128,10000],'max_saved_frames':max(len(states['new',n]['FRAMES']) for n in [0,8,16,32,64,128,10000]),'entire_state_equal_after_only_false_code_strict_removal':True,'native_agreement':True})
audit();report={'result':'pass','old':manifests['old']['fingerprint'],'new':manifests['new']['fingerprint'],'records':records,'scope':'Three exact no-directive sources: ordinary no-function, default cache before abrupt failure, and saved reference owner. Only new false pcode.STRICT fields removed; all other state fields compare entirely at seven cuts.'};(D/'report.json').write_text(json.dumps(report,indent=2));print(report)
