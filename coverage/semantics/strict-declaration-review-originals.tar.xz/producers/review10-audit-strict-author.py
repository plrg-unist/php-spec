from pathlib import Path
import json,hashlib,stat,sys
R=Path.cwd();K=R/'.tools/runtime6-strict-directive';sys.path.insert(0,str(R/'frontend'));import wire
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.load(open(K/'final-inputs.json'));f=json.load(open(R/'.tools/review10-strict-final/inputs.json'));assert m==f
for p,h in m['files'].items():assert sha(K/p)==h and stat.S_IMODE((K/p).stat().st_mode)==m['modes'][p],p
pre=json.load(open(K/'final-inputs.pre-cleanup.json'));changed=[p for p in m['files'] if m['files'][p]!=pre['files'][p] or m['modes'][p]!=pre['modes'][p]];assert changed==['tests/semantics/strict_declaration_protocol.py'];old=(R/'.tools/review10-strict-precleanup'/changed[0]).read_text();new=(K/changed[0]).read_text();assert old.replace(';rows={};before=', ';before=')==new
bridge=json.load(open(R/'.tools/compiler6-strict-tests/paired917-bridge.json'))
for p,x in bridge['copied_exact_files'].items():assert sha(K/p)==x['sha256'] and stat.S_IMODE((K/p).stat().st_mode)==x['mode'],p
reports={n:json.load(open(K/'coverage/semantics'/p)) for n,p in [('source','strict-declarations.json'),('protocol','strict-declaration-protocol.json'),('compiler','strict-declaration-compiler.json')]}
assert reports['source']['result']=='pass' and len(reports['source']['records'])==8 and reports['source']['fingerprint']==m['fingerprint'];assert reports['protocol']['result']=='pass' and reports['protocol']['assertions']==168 and reports['protocol']['fingerprint']==m['fingerprint'];assert reports['compiler']['result']=='pass' and reports['compiler']['compared']==37 and len(reports['compiler']['pending'])==2 and reports['compiler']['context_assertions']==47
for p,h in reports['compiler']['inputs'].items():assert sha(K/p)==h,p
workers=[]
for report in reports.values():
 root=Path(report['raw']);root=root if root.is_absolute() else K/root
 for p in root.rglob('close.json'):
  d=p.parent;assert json.load(open(p))=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (d/'stderr').read_bytes() and not (d/'trailing.stdout').read_bytes();rs=list(d.glob('*.request'));assert len(rs)==len(list(d.glob('*.response')))
  for i in range(len(rs)):
   req=wire.loads((d/(str(i)+'.request')).read_text());res=wire.loads((d/(str(i)+'.response')).read_text());assert res['ok']
  workers.append({'directory':str(d),'responses':len(rs)})
report={'result':'pass','fingerprint':m['fingerprint'],'precleanup':pre['fingerprint'],'one_path_cleanup':changed,'compiler_bridge_exact':list(bridge['copied_exact_files']),'source':8,'protocol':17,'protocol_assertions':168,'compiler_exact_phases':37,'other_directive_boundaries':2,'compiler_projections':47,'workers':workers,'responses':sum(x['responses'] for x in workers),'closures':len(workers),'dense_state':'separate pending report'};(R/'.tools/review10-strict-author-audit.json').write_text(json.dumps(report,indent=2));print(report)
