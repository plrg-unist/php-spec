from pathlib import Path
import argparse,hashlib,json,os,sys,tempfile
parser=argparse.ArgumentParser();parser.add_argument('candidate',type=Path);parser.add_argument('reports',nargs='+',type=Path);args=parser.parse_args()
R=Path.cwd();K=args.candidate.resolve();sys.path.insert(0,str(K/'tests/semantics'))
import request_environment as q
from recorded_worker import Worker
sha=lambda b:hashlib.sha256(b).hexdigest()
D=Path(tempfile.mkdtemp(prefix='review10-strict-replay-',dir=R/'.tools'));(D/'producer.py').write_bytes(Path(__file__).read_bytes())
inputs=[K/p for p in json.loads((K/'spec/semantics/modules.json').read_text())]
inputs += [K/p for p in ['.tools/php/bin/php','.tools/php-file.so','.tools/request-clock.so','_build/default/adapter/main.exe','tests/semantics/_build/default/numeric_runner.exe','tests/semantics/recorded_worker.py','tests/semantics/request_environment.py','bin/php-semantics']]
hashes={str(p.relative_to(K)):sha(p.read_bytes()) for p in inputs};before=q.t.syntax_validation.implementation_fingerprint()
(D/'inputs.json').write_text(json.dumps({'candidate':str(K),'closure':before,'direct':hashes},indent=2)+'\n')
for p in inputs:
 dest=D/'original-inputs'/p.relative_to(K);dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(p.read_bytes())
records=[];frontend=adapter=None
print(D,flush=True)
try:
 frontend=Worker([str(q.t.PHP),'-n',*q.t.FLAGS,'-d','extension='+str(K/'.tools/php-file.so'),str(K/'frontend/worker.php')],D/'frontend-wire')
 adapter=Worker([str(K/'_build/default/adapter/main.exe'),str(K)],D/'adapter-wire')
 for reportpath in args.reports:
  original=json.loads(reportpath.read_text());rows=original['records'] if 'records' in original else json.loads((Path(original['raw'])/'report.json').read_text())['records']
  for old in rows:
   row={'id':old['id'],'original_report':str(reportpath),'original_report_sha256':sha(reportpath.read_bytes()),'source_base64':old['source_base64'],'source_sha256':sha(q.t.base64.b64decode(old['source_base64'])),'context':old['context'],'request':old['request'],'native':old['native']}
   directory=D/str(len(records));directory.mkdir();(directory/'input.json').write_text(json.dumps(row,indent=2)+'\n')
   source=q.t.base64.b64decode(row['source_base64']);assert Path(row['context']).read_bytes()==source
   parsed=frontend.request({'op':'parse','source':row['source_base64']});assert parsed['accepted'];(directory/'parsed.json').write_text(json.dumps(parsed)+'\n')
   request={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':q.b64(os.fsencode(row['context'])),'request':row['request']}
   (directory/'execute.json').write_text(json.dumps(request)+'\n');result=adapter.request(request);(directory/'state.json').write_text(json.dumps(result)+'\n')
   actual=q.cli.observe(result['state'],row['context']);row['actual']=actual
   row['pending_core']=row['id'] in {'encoding-literal-boundary','strict-typed-boundary','weak-typed-boundary'} or 'builtin-originals' in str(reportpath)
   row['semantic_agreement']=actual['status'] in ('normal','php_error','static_rejection') and all(actual[k]==row['native'][k] for k in ['stdout','stderr','exit_status'])
   row['boundary_retained']=row['pending_core'] and actual['status']=='unsupported'
   records.append(row);(D/'results.json').write_text(json.dumps(records,indent=2)+'\n');print(row['id'],actual['status'],row['semantic_agreement'],flush=True)
finally:
 try:
  if frontend is not None:frontend.close()
 finally:
  if adapter is not None:adapter.close()
assert before==q.t.syntax_validation.implementation_fingerprint()
assert all(sha((K/p).read_bytes())==h for p,h in hashes.items())
report={'result':'pass' if all(r['semantic_agreement'] or r['boundary_retained'] for r in records) else 'fail','candidate':str(K),'fingerprint':before,'direct_inputs':hashes,'raw':str(D),'records':records,'source_agreements':sum(r['semantic_agreement'] for r in records),'pending_core_controls':sum(r['boundary_retained'] for r in records)}
(D/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(D,report['result'],flush=True)
