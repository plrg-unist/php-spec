<?php
function f($x=(1+"2a"),$y=MISSING){echo "BODY";}
function g(){f();}
g();