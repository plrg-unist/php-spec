<?php
declare(strict_types=1);
function f($x=(1+"2a"),$y=MISSING){echo "BODY";}
function g(){f();}
g();