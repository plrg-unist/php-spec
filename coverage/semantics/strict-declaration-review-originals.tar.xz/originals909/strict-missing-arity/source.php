<?php
declare(strict_types=1);function f(
$x
){}
f();