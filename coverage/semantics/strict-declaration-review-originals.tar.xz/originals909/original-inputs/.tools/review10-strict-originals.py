from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(R/'tests/semantics'))
import function_scope as scope
CASES={
 'strict-cache-error': b'<?php\ndeclare(strict_types=1);\nfunction f($x=(1+"2a"),$y=MISSING){echo "BODY";}\nfunction g(){f();}\ng();',
 'strict-cache-string': b'<?php\ndeclare(strict_types=1);namespace N;\nconst C="abc";function f($x=C){return $x;}echo f(),f();',
 'strict-cache-skip': b'<?php declare(strict_types=1);function f($x=MISSING){return $x;}echo f(8);',
 'strict-no-function': b'<?php declare(strict_types=1);$a=1;echo ++$a;',
 'zero-no-function': b'<?php declare(strict_types=0);echo 3;',
 'sticky-multilist': b'<?php declare(strict_types=1,STRICT_TYPES=0);;;declare(strict_types=0);function f($x="a"){return $x;}echo f();',
 'leading-comments': b'<?php /* comment */\n;/** doc */;declare(STRICT_TYPES=(1));echo 4;',
 'zero-reference': b'<?php declare(strict_types=0);function f(&$x){$x+=2;} $a=1;f($a);echo $a;',
 'strict-reference-default': b'<?php declare(strict_types=1);function f(&$x=[1]){$a=&$x;$a[0]++;return $x;} $a=f();$b=f();echo $a[0],$b[0];',
 'strict-conditional-nested': b'<?php declare(strict_types=1);function f(){if(true){function g($x=7){return $x;}}return g();}echo f(),g();',
 'strict-missing-arity': b'<?php\ndeclare(strict_types=1);function f(\n$x\n){}\nf();',
 'strict-top-return': b'<?php declare(strict_types=1);echo 1;return 2;echo "bad";',
 'misplaced-null': b'<?php echo "BAD";declare(strict_types=null);',
 'nested-invalid-block': b'<?php function f(){declare(strict_types=2){}}',
 'multiline-second-case': b'<?php\ndeclare(\nstrict_types=1,\nStRiCt_TyPeS=\nfalse);',
 'encoding-literal-boundary': b'<?php declare(encoding="UTF-8");declare(strict_types=1);echo 1;',
 'ticks-nonliteral': b'<?php declare(ticks=1+0);declare(strict_types=1);',
 'strict-typed-boundary': b'<?php declare(strict_types=1);function f(int $x){return $x;}echo f("2");',
 'weak-typed-boundary': b'<?php function f(int $x){return $x;}echo f("2");',
 'weak-cache-control': b'<?php\nfunction f($x=(1+"2a"),$y=MISSING){echo "BODY";}\nfunction g(){f();}\ng();',
 'weak-no-function-control': b'<?php $a=1;echo ++$a;',
}
if __name__=='__main__':scope.main(CASES,'review10-strict-originals',Path(__file__))
