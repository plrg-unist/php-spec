<?php
declare(
strict_types=1,
StRiCt_TyPeS=
false);