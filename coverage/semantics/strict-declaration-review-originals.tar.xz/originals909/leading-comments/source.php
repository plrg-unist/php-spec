<?php /* comment */
;/** doc */;declare(STRICT_TYPES=(1));echo 4;