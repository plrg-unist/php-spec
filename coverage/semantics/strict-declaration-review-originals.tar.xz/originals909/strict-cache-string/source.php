<?php
declare(strict_types=1);namespace N;
const C="abc";function f($x=C){return $x;}echo f(),f();