from pathlib import Path
import hashlib,json,shutil,stat
R=Path(__file__).resolve().parent;B=R.parent/'runtime7-variadic-final';D=R/'candidate';m=json.loads((B/'inputs.json').read_text())
for n,h in m['files'].items():
 p=B/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h;q=D/n;q.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,q)
shutil.copy2(B/'inputs.json',D/'baseline-inputs.json');p=D/'vendor/php-src/Zend/zend_compile.c';p.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(R.parents[1]/'vendor/php-src/Zend/zend_compile.c',p)
