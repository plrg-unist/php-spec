from pathlib import Path
import hashlib,json,stat,subprocess,sys,tempfile,traceback
R=Path(__file__).resolve().parent;D=R/'candidate';sys.path.insert(0,str(D/'tests/semantics'));import function_compiler as test
from recorded_worker import Worker
out=Path(tempfile.mkdtemp(prefix='function-',dir=R));print(out,flush=True);baseline=json.loads((D/'baseline-inputs.json').read_text());before={'fingerprint':test.types.syntax_validation.implementation_fingerprint(),'files':{n:hashlib.sha256((D/n).read_bytes()).hexdigest()for n in baseline['files']},'modes':{n:stat.S_IMODE((D/n).stat().st_mode)for n in baseline['files']}};(out/'inputs.json').write_text(json.dumps(before,indent=2)+'\n');(out/'original-producer.py').write_bytes((D/'tests/semantics/function_compiler.py').read_bytes());oldrun=subprocess.run;count=0;workers=0

def worker(command):
 global workers
 n=workers;workers+=1;return Worker(command,out/f'worker-{n}')
def run(command,*args,**kwargs):
 global count
 n=count;count+=1;p=out/f'process-{n}';p.with_suffix('.command.json').write_text(json.dumps(command));z=oldrun(command,*args,**kwargs);p.with_suffix('.stdout').write_bytes(z.stdout or b'');p.with_suffix('.stderr').write_bytes(z.stderr or b'');p.with_suffix('.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}));return z
test.types.Worker=worker;subprocess.run=run
try:test.main();result='pass'
except BaseException:
 (out/'failure.txt').write_text(traceback.format_exc());result='fail'
finally:subprocess.run=oldrun
assert before['fingerprint']==test.types.syntax_validation.implementation_fingerprint();(out/'report.json').write_text(json.dumps({'result':result,'inputs':before,'workers':workers,'processes':count,'scope':'Exact maintained function compiler gate and explicit stale expectation failure/repair, with full worker and subprocess capture.'},indent=2)+'\n');print(result,flush=True);sys.exit(result!='pass')
