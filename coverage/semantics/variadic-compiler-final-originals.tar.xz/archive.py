from pathlib import Path
import hashlib,io,json,lzma,stat,tarfile
R=Path(__file__).resolve().parent;C=R/'candidate';files={};modes={};bindings={}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,p):
 m=stat.S_IMODE(p.stat().st_mode)
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  bindings[n]={'sha256':sha(p),'mode':m};return
 files[n]=p.read_bytes();modes[n]=m
for p in sorted(R.rglob('*')):
 if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['archive.json','originals.tar.xz']:add(str(p.relative_to(R)),p)
m=json.loads((C/'final-inputs.json').read_text());a=json.loads((C/'baseline-inputs.json').read_text());changed=[n for n in m['files']if a['files'][n]!=m['files'][n]];assert changed==['tests/semantics/function_compiler.py'] and a['modes']==m['modes']
for n,h in m['files'].items():assert sha(C/n)==h and stat.S_IMODE((C/n).stat().st_mode)==m['modes'][n],n
hashes={n:hashlib.sha256(v).hexdigest()for n,v in files.items()};out=R/'originals.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 raw=(json.dumps({'files':hashes,'modes':modes,'tools':bindings},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(raw);z.mode=0o644;t.addfile(z,io.BytesIO(raw))
 for n,raw in sorted(files.items()):
  z=tarfile.TarInfo(n);z.mode=modes[n];key=(hashes[n],modes[n])
  if key in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[key];t.addfile(z)
  else:seen[key]=n;z.size=len(raw);t.addfile(z,io.BytesIO(raw))
with tarfile.open(fileobj=io.BytesIO(lzma.decompress(out.read_bytes())),mode='r:') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
report={'archive':'variadic-compiler-final-originals.tar.xz','sha256':sha(out),'bytes':out.stat().st_size,'paths':len(files),'tools':bindings,'failed_inputs':a['fingerprint'],'corrected_inputs':m['fingerprint'],'changed':changed,'unchanged':958,'all_modes_equal':True,'compiler_phase_comparisons':46,'pending':0,'scope':'Original maintained function compiler variadic Unsupported expectation fails on959/cee5; unchanged source moves to normal CASES and46 phases pass on959/4d69. No semantic/runtime change. Full actual tool/producer versions, maps, original failure and corrected raw worker/subprocess streams retained. These supplement immutable compiler archive d286; prior source/protocol gates retaincee5 identity.'};(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
