from pathlib import Path
import json,sys,tempfile,subprocess,base64,hashlib
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import static_types as t,source_compiler as c,source_context as sc
cases={
'weak':'<?php function f($x){return $x;} f(1);',
'strict':'<?php declare(strict_types=1);function f($x){return $x;} f(1);',
'bare':'<?php\nfunction f(){\n return;\n}\nf();',
'multiline':'<?php\nfunction f(){\n return\n 1 +\n 2;\n}\nf();',
'nested':'<?php declare(strict_types=1);function f(){function g(){return 2;}return g();}f();',
'namespace':'<?php declare(strict_types=1);namespace N;function f(){return 1;}f();',
'fallthrough':'<?php\nfunction f($x){\n echo $x;\n}\nf(1);',
'dead-return-error':'<?php function f(){if(false){return [,1];}}',
'parameter-type-pending':'<?php function f(int $x){return $x;}f(1);',
'return-type-pending':'<?php function f():int{return 1;}f();'}
O=Path(tempfile.mkdtemp(prefix='metadata-',dir=R/'.tools'));print(O,flush=True);mods=[str(R/p) for p in json.loads((R/'spec/semantics/modules.json').read_text())];f=t.Worker([str(t.PHP),'-n',*t.FLAGS,'-d','extension='+str(R/'.tools/php-file.so'),str(R/'frontend/worker.php')]);a=t.Worker([str(R/'_build/default/adapter/main.exe'),str(R)]);assertions=[];records=[]
try:
 for name,src in cases.items():
  d=O/name;d.mkdir();p=d/'source.php';p.write_text(src);parsed=f.request({'op':'parse','source':base64.b64encode(src.encode()).decode()});checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(checked));cmd=[str(t.PHP),'-n',*t.FLAGS,'-l',str(p)];r=subprocess.run(cmd,capture_output=True,env=t.ENV,timeout=30);(d/'lint.command.json').write_text(json.dumps(cmd));(d/'lint.stdout').write_bytes(r.stdout);(d/'lint.stderr').write_bytes(r.stderr);(d/'lint.status.json').write_text(json.dumps({'exit_status':r.returncode}));assert r.returncode in [0,255]
  body=f'  -- if P = $ppstart(91, {checked["fixture"]}, {t.byte_expr(str(p))})\n'
  if name.endswith('pending'):body+='  -- if P.COMPLETION = PPCABRUPT (UNSUPPORTED "function type, reference return or variadic activation")\n'
  else:
   body+='  -- if $pptrace(P) = '+sc.expected_events(sc.events(r),p)+'\n'
   if r.returncode==0:
    body+='  -- if P.COMPLETION = PPCNORMAL\n';strict='true' if 'strict_types=1' in src else 'false';body+=f'  -- if $ppfunction_code(P).STRICT = {strict}\n'
    if name=='weak':body+='  -- if $ppfunction_code(P[.ENV.STRICT = true]).STRICT\n'
    if name!='nested':
     body+='  -- if P.FUNCTIONS = [pfunction]\n'+f'  -- if pfunction.CODE.STRICT = {strict}\n  -- if pfunction.CODE.STRICT = pfunction.ENV.STRICT\n'
     endline={'bare':4,'multiline':6,'fallthrough':4}.get(name,1);body+=f'  -- if pfunction.ENDLINE = {endline}\n'
     idx=1 if name=='strict' else 0
     if name not in ['fallthrough','namespace']:
      line={'bare':3,'multiline':5}.get(name,1);body+=f'  -- if $code_expression(pfunction.CODE.EXPRESSIONS, [PCINDEX {idx},PCFIELD 5,PCINDEX 0]) = (({line},false))\n'
    else:body+='  -- if P.FUNCTIONS = [pfunction_g,pfunction_f]\n  -- if pfunction_g.CODE.STRICT /\\ pfunction_f.CODE.STRICT\n  -- if pfunction_f.CODE.EXPRESSIONS = $ppownexpr([pfunction_g], pfunction_f.CODE.EXPRESSIONS)\n'
  n=len(assertions);assertions.append(f'dec $case{n}() : bool\ndef $case{n}() = true\n'+body);records.append({'id':name,'source_file':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'checks':body})
 w=O/'metadata.watsup';w.write_text(c.PREFIX+'\n'.join(assertions)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(assertions))));cmd=[str(R/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(w)];r=subprocess.run(cmd,capture_output=True,timeout=120);(O/'command.json').write_text(json.dumps(cmd));(O/'stdout').write_bytes(r.stdout);(O/'stderr').write_bytes(r.stderr);(O/'status.json').write_text(json.dumps({'exit_status':r.returncode}));assert r.returncode==0 and r.stdout==b'true\n' and not r.stderr,r
finally:f.close();a.close()
(O/'report.json').write_text(json.dumps({'scope':'Private compiler-only metadata prototype; typed execution remains Unsupported. No runtime validation/admission claimed.','cases':records,'result':'pass'},indent=2)+'\n');print('8source phase observations,2typed Unsupported controls; actual source strictness and return metadata passed')
