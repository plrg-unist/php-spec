from pathlib import Path
import json,sys,hashlib,subprocess,base64
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import static_types as t
m=json.loads((R/'baseline-inputs.json').read_text());assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in m['files'].items());O=R/'.tools/originals';O.mkdir();cases=json.loads((R/'cases.json').read_text());mods=[str(R/p) for p in json.loads((R/'spec/semantics/modules.json').read_text())];f=t.Worker([str(t.PHP),'-n',*t.FLAGS,'-d','extension='+str(R/'.tools/php-file.so'),str(R/'frontend/worker.php')]);a=t.Worker([str(R/'_build/default/adapter/main.exe'),str(R)]);rows=[]
try:
 for name,source in cases.items():
  d=O/name;d.mkdir();p=d/'source.php';p.write_text(source);parsed=f.request({'op':'parse','source':base64.b64encode(source.encode()).decode()});(d/'parsed.json').write_text(json.dumps(parsed));assert parsed['accepted'],(name,parsed);checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(d/'checked.json').write_text(json.dumps(checked));w=d/'compiler-state.watsup';w.write_text(f'dec $main() : ppstate\ndef $main() = $ppstart(91, {checked["fixture"]}, {t.byte_expr(str(p))})\n')
  for label,cmd in [('lint',[str(t.PHP),'-n',*t.FLAGS,'-l',str(p)]),('compiler',[str(R/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(w)])]:
   (d/(label+'.command.json')).write_text(json.dumps(cmd));z=subprocess.run(cmd,capture_output=True,env=t.ENV,timeout=60);(d/(label+'.stdout')).write_bytes(z.stdout);(d/(label+'.stderr')).write_bytes(z.stderr);(d/(label+'.status.json')).write_text(json.dumps({'exit_status':z.returncode}));assert z.returncode in ([0,255] if label=='lint' else [0]),(name,label,z.stderr)
  rows.append({'id':name,'source_file':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()});print(name,flush=True)
finally:f.close();a.close()
assert all(hashlib.sha256((R/p).read_bytes()).hexdigest()==h for p,h in m['files'].items());(O/'manifest.json').write_text(json.dumps({'baseline':m,'records':rows,'scope':'Original native lint/current metadata-prototype compiler states; not source-runtime agreement.'},indent=2)+'\n')
