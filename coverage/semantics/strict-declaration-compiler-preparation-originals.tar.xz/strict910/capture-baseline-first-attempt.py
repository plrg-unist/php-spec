from pathlib import Path
import json,hashlib,stat,subprocess
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-parameter-defaults';T=R.parent/'compiler6-strict-compiler';m=json.loads((R/'baseline-inputs.json').read_text());O=R/'.tools/baseline909-originals';O.mkdir();mods=[str(B/p) for p in json.loads((B/'spec/semantics/modules.json').read_text())];rows=[]
def verify():
 for p,h in m['files'].items():
  assert hashlib.sha256((B/p).read_bytes()).hexdigest()==h,p
  assert stat.S_IMODE((B/p).stat().st_mode)==m['modes'][p],p
verify()
for name in json.loads((R/'cases.json').read_text()):
 d=O/name;d.mkdir();original=T/'.tools/originals'/name;w=original/'compiler-state.watsup';cmd=[str(B/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(w)];z=subprocess.run(cmd,capture_output=True,timeout=60);(d/'command.json').write_text(json.dumps(cmd));(d/'stdout').write_bytes(z.stdout);(d/'stderr').write_bytes(z.stderr);(d/'status.json').write_text(json.dumps({'exit_status':z.returncode}));assert z.returncode==0 and not z.stderr,(name,z.stderr);assert b'UNSUPPORTED "ordinary statement compilation"' in z.stdout,(name,z.stdout[-1000:]);rows.append({'id':name,'original':str(original),'source_sha256':hashlib.sha256((original/'source.php').read_bytes()).hexdigest(),'fixture_sha256':hashlib.sha256(w.read_bytes()).hexdigest()});print(name,flush=True)
verify();(O/'manifest.json').write_text(json.dumps({'baseline':m['fingerprint'],'records':rows,'scope':'39 current909 full-compiler Unsupported originals using exact retained native source file and fixture. No native rerun or runtime agreement.'},indent=2)+'\n')
