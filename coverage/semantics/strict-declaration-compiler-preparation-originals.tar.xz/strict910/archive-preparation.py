from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path(__file__).resolve().parent;C=R.parent.parent;files={};tools={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(name,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:
  tools[name]={'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[name]=p
def candidate(label,p):
 m=json.loads((p/'final-inputs.json').read_text())
 for n,h in m['files'].items():
  f=p/n;assert digest(f)==h,n;assert stat.S_IMODE(f.stat().st_mode)==m['modes'][n],n;add(label+'/'+n,f)
 for f in p.iterdir():
  if f.is_file() and f.suffix in ['.json','.py','.md'] and f.name!='archive.json':add(label+'/'+f.name,f)
 for f in (p/'.tools').rglob('*'):
  if f.is_file() and f.suffix!='.pyc' and '__pycache__' not in f.parts:add(label+'/'+str(f.relative_to(p)),f)
for label,name in [('metadata902','compiler6-type-descriptors'),('strict903','compiler6-strict-compiler'),('strict910','compiler6-strict-paired')]:candidate(label,R.parent/name)
B=R.parent/'runtime6-parameter-defaults';m=json.loads((R/'baseline-inputs.json').read_text())
for n,h in m['files'].items():
 p=B/n;assert digest(p)==h,n;assert stat.S_IMODE(p.stat().st_mode)==m['modes'][n],n;add('baseline909/'+n,p)
for name in ['Zend/zend_compile.c','Zend/zend_execute.c','Zend/zend_vm_def.h']:
 add('vendor/php-src/'+name,C/'vendor/php-src'/name)
hashes={n:digest(p) for n,p in files.items()};modes={n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()};seen={};out=R/'originals.tar.xz'
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'modes':modes,'tools':tools},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(data);t.addfile(z,io.BytesIO(data))
 for name,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=name);h=hashes[name]
  if (h,modes[name]) in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[h,modes[name]];z.size=0;t.addfile(z)
  else:
   seen[h,modes[name]]=name
   with p.open('rb') as stream:t.addfile(z,stream)
with tarfile.open(out,'r:xz') as t:
 for name,h in hashes.items():assert hashlib.sha256(t.extractfile(name).read()).hexdigest()==h and t.getmember(name).mode==modes[name],name
report={'scope':'Private strict declaration compiler preparation only; no runtime source admission, type activation or full-core acceptance.','archive':str(out),'sha256':digest(out),'paths':len(files),'bytes':out.stat().st_size,'candidate':json.loads((R/'final-inputs.json').read_text())['fingerprint'],'baseline':m['fingerprint'],'tools':tools,'bridge':'strict910/projection-bridge.json','handoff':'strict910/HANDOFF.md','gates':{'native_phase_exact':37,'other_directive_unsupported':2,'metadata_source_controls':10,'current909_fullcompiler_originals':39},'transport':'Subprocess byte streams/commands/status and decoded frontend responses retained; worker raw packets/stderr not captured by preparation, independent protocol review pending.','build':'Copied artifact hashes/modes retained; no runner rebuild.'};(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
