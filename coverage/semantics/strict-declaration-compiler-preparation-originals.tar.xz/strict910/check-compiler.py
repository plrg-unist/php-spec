from pathlib import Path
import json,sys,subprocess,tempfile
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import static_types as t,source_compiler as c,source_context as sc
O=Path(tempfile.mkdtemp(prefix='strict-compiler-',dir=R/'.tools'));print(O,flush=True);mods=[str(R/p) for p in json.loads((R/'spec/semantics/modules.json').read_text())];assertions=[];rows=[];pending=['other-directive','mixed-directive']
for name,src in json.loads((R/'cases.json').read_text()).items():
 d=Path('/home/user/workspace/php-spec/.tools/compiler6-strict-compiler/.tools/originals')/name;k=json.loads((d/'checked.json').read_text());p=d/'source.php';r=subprocess.CompletedProcess([],json.loads((d/'lint.status.json').read_text())['exit_status'],(d/'lint.stdout').read_bytes(),(d/'lint.stderr').read_bytes());body=f'  -- if P = $ppstart(91, {k["fixture"]}, {t.byte_expr(str(p))})\n'
 if name in pending:body+='  -- if P.COMPLETION = PPCABRUPT (UNSUPPORTED "other declare directive compilation")\n'
 else:
  body+='  -- if $pptrace(P) = '+sc.expected_events(sc.events(r),p)+'\n'
  if r.returncode==0:
   strict='false' if name=='zero' else 'true';body+=f'  -- if P.COMPLETION = PPCNORMAL\n  -- if P.ENV.STRICT = {strict}\n  -- if $ppfunction_code(P).STRICT = {strict}\n'
   if 'function f' in src:body+=f'  -- if P.FUNCTIONS = [pfunction]\n  -- if pfunction.ENV.STRICT = {strict}\n  -- if pfunction.CODE.STRICT = {strict}\n'
 n=len(assertions);assertions.append(f'dec $case{n}() : bool\ndef $case{n}() = true\n'+body);rows.append({'id':name,'checks':body})
f=O/'cases.watsup';f.write_text(c.PREFIX+'\n'.join(assertions)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(assertions))));cmd=[str(R/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(f)];z=subprocess.run(cmd,capture_output=True,timeout=120);(O/'command.json').write_text(json.dumps(cmd));(O/'stdout').write_bytes(z.stdout);(O/'stderr').write_bytes(z.stderr);(O/'status.json').write_text(json.dumps({'exit_status':z.returncode}));print(z.returncode,z.stdout.decode(),z.stderr.decode());assert z.returncode==0 and z.stdout==b'true\n' and not z.stderr;(O/'report.json').write_text(json.dumps({'result':'pass','scope':'Private strict_types compiler prerequisite, runtime work admission and type execution unpaired.','compared':len(rows)-len(pending),'pending':pending,'cases':rows},indent=2)+'\n')
