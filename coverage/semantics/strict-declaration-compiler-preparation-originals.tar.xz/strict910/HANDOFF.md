# Strict declaration prerequisite

This private compiler prerequisite follows accepted defaults909/e25eb2b9. It
admits compilation of `declare(strict_types=0|1);` and projects lexical strictness
into unit/function CODE. Runtime declaration work, code integrity and execution
remain unpaired. Typed calls and returns remain Unsupported.

The minimal candidate is910/e7227852 (`final-inputs.json`), exactly five changed
paths against909:92, its registry entry, `pcode.STRICT bool` in30, unit projection
in33 and function projection in78. All other909 bytes/modes are preserved.
There is no ENDLINE or return-root addition in this candidate.92 is byte-identical
to the prior private903/b5f306c7 source compiler. That older prototype builds on
902/605b70b2 metadata, which also proposed ENDLINE and return roots for later
typed returns. Those identities and their earlier failures are retained separately.

## Compiler and runtime interface

92 handles checked `NStmtDeclare` using existing `ppstate.ENV.STRICT` and existing
`parser_literal`; it introduces no type-normalization or constant-evaluator copy.
One only sets STRICT; zero leaves the accumulated flag unchanged. Namespace
compilation and function declaration contexts use the existing lexical environment
thread. Both unit code and function code emit `STRICT P.ENV.STRICT`.

A successful declaration remains in `P.WORK` as its checked NStmtDeclare source
occurrence. Runtime must admit only actual valid strict-only declarations and
execute their work as a no-op. It must also check each stored code STRICT against
the source-derived compiler projection. Editing strictness must not produce an
accepted runtime state. Shared source/class/default owners and91 receive caches
must remain unchanged. No caller ARGSTRICT field or typed receive consumer has
been agreed; this prerequisite supplies their future lexical input only.

The source compiler recognizes directive names case-insensitively. It first
requires a parser literal, then checks strict placement, no block body, and the
integer0/1 value. Unary signs, constant fetches including true/false/null, arrays
and arithmetic are not parser literals; string concatenation is a parser literal
but fails strict value validation. Placement is membership of the original top
file statement list, allowing only preceding Nop or Declare statements. Nested
strict declarations fail. Declaration error location is the first item's line,
even for a later item or a multiline value.

Other declare directives are explicit later core work. Their literal requirement
is checked before the Unsupported boundary; ticks, encoding and their block effects
are not admitted. PHP allows earlier Declare nodes in its first-statement check,
including blocks of other directives; this can eventually produce functions with
different strictness in one file. Do not infer that mixed strictness always
requires multiple source units.

## Evidence and review scope

39 exact source/native lint originals cover literal classes, placement, multiple
and sticky declarations, namespaces, BOM/shebang, block forms and multiline error
order/locations. The original36-record metadata605 baseline manifest and later
three-record supplement remain distinct. The new current909 replay retains all39
full-compiler Unsupported states using identical source files/fixtures and native
records. No native rerun or runtime agreement is asserted by that replay.

The unchanged37 exact native phase/line expectations plus two explicit other-
directive boundaries pass on910, raw `.tools/strict-compiler-pi16sdcv`. Ten retained
source projections pass in `.tools/source-projection`: eight exact phase controls
and two still Unsupported type declarations, with weak/strict/namespace/nested
function flags. Synthetic strictness, ENDLINE and return-root assertions from the
older prototype are excluded. Copied native/adapter/semantic runner hashes are
retained; no rebuild is claimed. Subprocess stdout/stderr/status/commands and
checked frontend responses are retained. These preparation scripts do not record
exact worker wire frames or separately capture worker stderr; independent protocol
review must supply that evidence before source admission.

Initial attempts remain visible: synthetic metadata harness incorrectly expected
strict source admission; a return emission-line fixture expected4 instead of5;
92 initially used an int subtraction where a nat was required. The current909
capture initially searched for a quoted Unsupported rendering while ppstate emits
unquoted text; its raw one-case run remains separate from the corrected39 capture.
None of these tool/assertion failures counts as agreement.

PHP8.5.10 authority is pinned `vendor/php-src/Zend/zend_compile.c`, particularly
`zend_is_first_statement` and `zend_compile_declare`; the exact source is included
with the archive. Baseline909 and candidate910 full input hashes/modes, prior
metadata/strict prototypes and gates, matching native originals and raw failures
are retained. Runtime6 owns paired execution/guards; the independent reviewer owns
source/phase/state/protocol acceptance. No canonical strict activation is claimed.
