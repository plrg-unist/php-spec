<?php
function f(){
 return
 1 +
 2;
}
f();