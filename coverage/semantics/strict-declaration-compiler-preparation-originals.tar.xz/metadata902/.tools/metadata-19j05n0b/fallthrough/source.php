<?php
function f($x){
 echo $x;
}
f(1);