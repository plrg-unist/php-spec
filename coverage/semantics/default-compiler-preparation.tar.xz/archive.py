from pathlib import Path
import hashlib,io,json,tarfile
D=Path(__file__).resolve().parent;W=D.parent;S=W/'compiler5-default-parameters';P=W/'compiler5-default-compiler';O=W/'compiler5-default-originals';G=W/'compiler5-default-stage-design';C=W/'compiler5-constant-classes'
h=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();m=json.loads((S/'signature-step-inputs.json').read_text());assert all(h(S/p)==v for p,v in m['files'].items())
files={'signature877/'+p:S/p for p in m['files']}
for name in ['archive.py']:files[name]=D/name
files['CONSTANTS-COMPILER-HANDOFF.md']=C/'CONSTANTS-COMPILER-HANDOFF.md'
for name in ['signature-step-inputs.json','baseline-inputs.json','default-step-preparation.json','DEFAULT-MILESTONE.md','prepare-signature-step.py','default-step-check.py','signature-regression.py','semantics-reference-inputs.json','coverage/semantics/signatures.json']:files['signature877/'+name]=S/name
for root,prefix in [(S/'.tools','signature877/.tools'),(S/'before-compiler','signature877/before-compiler'),(P/'.tools/default-first-load','paused/default-first-load'),(P/'before-compiler','paused/before-compiler'),(O,'original39'),(G,'design12')]:
 for p in root.rglob('*'):
  if p.is_file() and '__pycache__' not in p.parts:files[str(Path(prefix)/p.relative_to(root))]=p
files['paused/PAUSED.json']=P/'PAUSED.json'
for rel,v in json.loads((S/'semantics-reference-inputs.json').read_text())['references'].items():assert h(S/rel)==v;files['signature877/'+rel]=S/rel
# Bind exact module payloads named by the paused failed module-load attempt.
needed=json.loads((P/'.tools/default-first-load/module-inputs.json').read_text());available={}
for root in [S,P,W/'runtime6-reference',W/'compiler5-reference-parameters',W/'compiler5-user-constants']:
 for p in (root/'spec').rglob('*.watsup'):available.setdefault(h(p),p)
 for p in (root/'before-compiler').glob('*.watsup'):available.setdefault(h(p),p)
for p in (P/'.tools/default-first-load').glob('*.watsup'):available.setdefault(h(p),p)
bindings={}
def bind(x):
 if isinstance(x,dict):
  for name,v in x.items():
   if isinstance(v,str) and len(v)==64 and name.endswith('.watsup'):
    assert v in available,(name,v);rel='paused/exact-modules/'+v+'.watsup';files[rel]=available[v];bindings[name]={'sha256':v,'payload':rel}
   else:bind(v)
 elif isinstance(x,list):
  for v in x:bind(v)
bind(needed);(D/'paused-module-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n');files['paused-module-bindings.json']=D/'paused-module-bindings.json'
tools={p:h(f) for p,f in files.items() if p.endswith(('/numeric_runner.exe','/bin/php','/main.exe','php-file.so','request-clock.so'))}
for p in tools:files.pop(p)
for p,f in files.items():assert f.is_file(),p
hashes={p:h(f) for p,f in files.items()};out=D/'default-compiler-preparation.tar.xz';seen={}
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'tools':tools,'signature_source_inputs':m},indent=2)+'\n').encode();info=tarfile.TarInfo('SHA256.json');info.size=len(data);t.addfile(info,io.BytesIO(data))
 for name,p in sorted(files.items()):
  v=hashes[name];info=t.gettarinfo(str(p),arcname=name)
  if v in seen:info.type=tarfile.LNKTYPE;info.linkname=seen[v];info.size=0;t.addfile(info)
  else:
   seen[v]=name
   with p.open('rb') as f:t.addfile(info,f)
# Verify every regular payload and hardlink in one streaming pass.
verified={}
with tarfile.open(out,'r|xz') as t:
 for member in t:
  if member.name=='SHA256.json':assert json.loads(t.extractfile(member).read())['files']==hashes;continue
  v=verified[member.linkname] if member.islnk() else hashlib.sha256(t.extractfile(member).read()).hexdigest();assert v==hashes[member.name],member.name;verified[member.name]=v
assert verified==hashes
report={'scope':'Historical untyped-default compiler preparation and successor continuity only; no constant/default source admission, no new semantics run, no independent acceptance inferred.','archive':out.name,'sha256':h(out),'bytes':out.stat().st_size,'paths':len(files),'unique_contents':len(seen),'tools':tools,'signature_prototype':{'files':len(m['files']),'fingerprint':m['fingerprint'],'17_sha256':h(S/'spec/semantics/17-signatures.watsup'),'legacy_cases':357,'descriptors':28,'return_reference_flags':174,'suspension_probes':8},'paused_prototype':'First module-load syntax failure, all named module bytes retained; invalid prototype not working semantics.','paused_module_count':len(bindings),'original39':'Original lint/checked/old882 compiler states; not runtime receive observations.','design12':'Existing original archive3ecb2a50 retained unchanged with external source866 binding. Current DESIGN.md was later corrected to untyped-only staging and is not relabelled as the archived original design.','handoff_sha256':h(C/'CONSTANTS-COMPILER-HANDOFF.md'),'transport':'Decoded Worker JSON; native/SpecTec subprocess bytes/status and captured timeout partials. No new exact-wire claim.'}
(D/'default-compiler-preparation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2));assert all(h(S/p)==v for p,v in m['files'].items())
