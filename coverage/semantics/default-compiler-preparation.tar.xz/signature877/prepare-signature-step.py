from pathlib import Path
import re
D=Path(__file__).resolve().parent;p=D/'spec/semantics/17-signatures.watsup';s=p.read_text()
s=s.replace('syntax psoneresult = PSONE psparam psdiagnostic* | PSONEERROR psdiagnostic* | PSONEUNSUPPORTED text','''syntax psoneresult = PSONE psparam psdiagnostic* | PSONEERROR psdiagnostic* | PSONEUNSUPPORTED text
syntax psoneprogress = PSGUARDED psoneresult | PSNEEDDEFAULT
syntax pscontinuation = { CONTEXT ptcontext, PARAMETER psraw, REST psinput*,
  SIGNATURE pssignature, DIAGNOSTICS psdiagnostic* }
syntax psprogress = PSSDONE psresult | PSSDEFAULTREQUEST pscontinuation''')
# Split the existing guards without copying their conditions or changing order.
def guard(m):
 line=m.group(0);left,right=line.split(' = ',1);left=left.replace('$psone(', '$psguard(').replace('$psdefaultstage(', '$psdefaultguard(')
 if right.startswith('$psdefaultstage('):right=right.replace('$psdefaultstage(', '$psdefaultguard(',1)
 elif right.startswith('$psdefaultready('):right='PSNEEDDEFAULT'
 else:right='PSGUARDED ('+right+')'
 return left+' = '+right
s=re.sub(r'^def \$(?:psone|psdefaultstage)\([^\n]+',guard,s,flags=re.M)
# Existing result APIs remain literal-resolving wrappers.
start=s.index('def $psfold(ptcontext, eps,');end=s.index('\ndef $psseenvariadic(',start)
s=s[:start]+'''def $psfold(ptcontext, psinput*, pssignature, psdiagnostic*) = $psstep_finish($psfold_start(ptcontext, psinput*, pssignature, psdiagnostic*))

'''+s[end:]
start=s.index('def $psafterone(ptcontext,');end=s.index('\ndef $pscompile(',start)
s=s[:start]+'''def $psafterone(ptcontext, psinput*, pssignature, psdiagnostic*, psoneresult) = $psstep_finish($psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, psoneresult))

'''+s[end:]
start=s.index('def $pscompile(SEQUENCE');end=s.index('\ndef $psfallbackreturn(',start)
s=s[:start]+'''def $pscompile(phpType16, phpType18, bool, ptcontext) = $psstep_finish($psstep_start(phpType16, phpType18, bool, ptcontext))
def $psreturnstage(ptcontext, psinput*, bool, ptresult) = $psstep_finish($psreturn_start(ptcontext, psinput*, bool, ptresult))

'''+s[end:]
s+='''
;; Suspend after parameter guards and before default/type normalization. The
;; source compiler supplies its shared constant-expression result at this point;
;; historical structural consumers retain the literal-resolving wrappers.
dec $psguard(ptcontext, psraw, psinput*, ptbytes*, bool) : psoneprogress
dec $psdefaultguard(ptcontext, psraw, psinput*) : psoneprogress
dec $psguard_resolve(ptcontext, psraw, psinput*, psoneprogress) : psoneresult
dec $psstep_start(phpType16, phpType18, bool, ptcontext) : psprogress
dec $psreturn_start(ptcontext, psinput*, bool, ptresult) : psprogress
dec $psfold_start(ptcontext, psinput*, pssignature, psdiagnostic*) : psprogress
dec $psfold_guarded(ptcontext, psraw, psinput*, pssignature, psdiagnostic*, psoneprogress) : psprogress
dec $psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, psoneresult) : psprogress
dec $psstep_resume(pscontinuation, psdefault) : psprogress
dec $psstep_finish(psprogress) : psresult

def $psone(ptcontext, psraw, psinput*, ptbytes*, bool) = $psguard_resolve(ptcontext, psraw, psinput*, $psguard(ptcontext, psraw, psinput*, ptbytes*, bool))
def $psdefaultstage(ptcontext, psraw, psinput*) = $psguard_resolve(ptcontext, psraw, psinput*, $psdefaultguard(ptcontext, psraw, psinput*))
def $psguard_resolve(ptcontext, psraw, psinput*, PSGUARDED psoneresult) = psoneresult
def $psguard_resolve(ptcontext, psraw, psinput*, PSNEEDDEFAULT) = $psdefaultready(ptcontext, psraw, psinput*, $psdefault(psraw.DEFAULT, ptcontext))

def $psstep_start(SEQUENCE phpType17*, phpType18, bool, ptcontext) = $psreturn_start(ptcontext, ($pslower(phpType17))*, bool, $ptype_normalize(phpType18, ptcontext[.POSITION = PTRETURN]))
  -- if ptcontext.MEMBER =/= eps
def $psstep_start(phpType16, phpType18, bool, ptcontext) = PSSDONE (PSUNSUPPORTED "missing declaration display name")
  -- if ptcontext.MEMBER = eps

def $psreturn_start(ptcontext, psinput*, bool, PTERROR ptdiagnostic*) = PSSDONE (PSERROR (PSTYPEDIAGNOSTIC ptdiagnostic)*)
def $psreturn_start(ptcontext, psinput*, bool, PTUNSUPPORTED text) = PSSDONE (PSUNSUPPORTED text)
def $psreturn_start(ptcontext, psinput*, bool, PTOK ptbranch* ptdiagnostic*) = $psfold_start(ptcontext, psinput*, { PARAMETERS eps, RETURNS $psfallbackreturn(ptcontext, ptbranch*), BYREF bool }, (PSTYPEDIAGNOSTIC ptdiagnostic)* ++ $psreturnnotice(ptcontext, ptbranch*, bool))

def $psfold_start(ptcontext, eps, pssignature, psdiagnostic*) = PSSDONE (PSOK pssignature psdiagnostic*)
def $psfold_start(ptcontext, (PSINPUTUNSUPPORTED text) :: psinput*, pssignature, psdiagnostic*) = PSSDONE (PSUNSUPPORTED text)
def $psfold_start(ptcontext, (PSINPUT psraw) :: psinput*, pssignature, psdiagnostic*) = $psfold_guarded(ptcontext, psraw, psinput*, pssignature, psdiagnostic*, $psguard(ptcontext[.LINE = psraw.LINE][.POSITION = PTPARAMETER], psraw, psinput*, (psparam.NAME)*, $psseenvariadic(pssignature.PARAMETERS)))
  -- if psparam* = pssignature.PARAMETERS

def $psfold_guarded(ptcontext, psraw, psinput*, pssignature, psdiagnostic*, PSGUARDED psoneresult) = $psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, psoneresult)
def $psfold_guarded(ptcontext, psraw, psinput*, pssignature, psdiagnostic*, PSNEEDDEFAULT) = PSSDEFAULTREQUEST { CONTEXT ptcontext, PARAMETER psraw, REST psinput*, SIGNATURE pssignature, DIAGNOSTICS psdiagnostic* }

def $psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, PSONE psparam psdiagnostic_new*) = $psfold_start(ptcontext, psinput*, pssignature[.PARAMETERS = pssignature.PARAMETERS ++ [psparam]], psdiagnostic* ++ psdiagnostic_new*)
def $psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, PSONEERROR psdiagnostic_new*) = PSSDONE (PSERROR (psdiagnostic* ++ psdiagnostic_new*))
def $psafterone_start(ptcontext, psinput*, pssignature, psdiagnostic*, PSONEUNSUPPORTED text) = PSSDONE (PSUNSUPPORTED text)

def $psstep_resume(pscontinuation, psdefault) = $psafterone_start(pscontinuation.CONTEXT, pscontinuation.REST, pscontinuation.SIGNATURE, pscontinuation.DIAGNOSTICS, $psdefaultready(pscontinuation.CONTEXT[.LINE = pscontinuation.PARAMETER.LINE][.POSITION = PTPARAMETER], pscontinuation.PARAMETER, pscontinuation.REST, psdefault))
def $psstep_finish(PSSDONE psresult) = psresult
def $psstep_finish(PSSDEFAULTREQUEST pscontinuation) = $psstep_finish($psstep_resume(pscontinuation, $psdefault(pscontinuation.PARAMETER.DEFAULT, pscontinuation.CONTEXT[.LINE = pscontinuation.PARAMETER.LINE][.POSITION = PTPARAMETER])))
'''
p.write_text(s)
