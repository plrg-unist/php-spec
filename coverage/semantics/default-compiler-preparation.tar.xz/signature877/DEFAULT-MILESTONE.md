# Untyped positional defaults: private paired milestone

Preparation only. The accepted reference implementation remains canonical884;
this module17 prototype uses historical877. Pairing must start from a fresh copy
of accepted884 and preserve the current reference module87 behavior. Compiler88
and runtime89 are reserved. No default source admission has occurred.

## Shared compiler interface

`psstep_start(params, return_type, byref, context)` returns `PSSDONE psresult` or
`PSSDEFAULTREQUEST pscontinuation`. The continuation carries CONTEXT, the current
PARAMETER (`psraw`), REST, accumulated SIGNATURE, and DIAGNOSTICS. It occurs after
existing parameter name, duplicate, this, variadic, and unsupported header guards.
`psstep_resume(continuation, psdefault)` uses the existing default/type/optional
normalization and continues to the next parameter. `psstep_finish` resolves the
requests using the historical literal helper; existing signature APIs are wrappers.
ABSENT defaults are represented by a request resumed with PSNONE. Return-type
normalization still precedes the parameter traversal, preserving compiler priority.

Module17 contains no heap values or second constant-expression traversal. Compiler88
will invoke existing45 at the actual checked parameter default path:
`declaration ++ [PCFIELD 3, PCINDEX i, PCFIELD 6]`. It supplies `PSDEFAULT original_AST
kind` to17 and retains the actual value or deferred compilation through existing
source facts. Declaration function magic context must be set before default folding.

Proposed runtime interface, agreed in principle with runtime6:
`pfunction.DEFAULTS` is an ordered list of `(parameter_index, original_origin,
STORED|DEFERRED)`. STORED borrows the existing unit PCONSTANT at that origin;
no descriptor owns a duplicate pvalue. DEFERRED uses the original source and existing per-unit CODE, including constant-
fold redirects and explicit default roots. Per-function compiled CODE projection also
retains these roots; runtime frame entry creates no additional code-owner stack.
Only retained defaults receive descriptors. A default before a later required
parameter is compiled and diagnosed, but its normalized parameter remains required.

## Required compiler obligations before source admission

- Add a parameter-default policy to existing45 name folding. The pinned compiler
  disables both ordinary and persistent constant substitution for defaults; preserve
  true/false/null and do not reuse ordinary builtin-constant substitution by accident.
- Fold before validating remaining constant-expression operations. Selected and
  skipped invalid arms have different native outcomes. Do not reject the original
  full tree before following existing fold redirects.
- Distinguish invalid constant expressions from valid but unimplemented forms
  (objects/closures/callables). Neither may masquerade as a runtime agreement.
- Preserve original source, namespace/imports, magic function name, diagnostic line,
  pool ownership, and default-root code filtering. Check mixed header/default/body
  failures in actual native order. Typed headers still receive shared compiler checks
  but successful typed source declarations remain explicitly unsupported.
- Source-derived integrity must reject missing/duplicate/wrong default descriptors,
  invalid indices, altered kind, inconsistent pool entries, and code roots outside
  the actual declaration. Public resume checks must reach these guards.

## Required runtime obligations before source admission

Runtime89 enters the actual callee, binds provided positional operands, then receives
omitted defaults in parameter order before body execution. It must preserve too-few
argument diagnostics, actual argument count and traces, per-call array/reference
storage, COW and aliases, recursion, deferred error timing, and cleanup after failure.
Default evaluation never runs for a supplied operand. Deferred execution uses existing
runtime tasks and declaration context, not a host evaluator. Source-paired state tests
must check ownership at cuts, adjacent resumes, full resumes, and final cleanup.

No parameter/return types, variadics, named/unpacked arguments, reference returns, or
new callable forms are admitted by this increment. Those remain subsequent milestones.

## Evidence and open assumptions

`default-step-preparation.json` binds module17 before/after hashes and historical877.
The existing signature gate passes357 native cases,28 descriptors,174 return-reference
checks. Eight new checked-source tests bind17 suspension to existing45 folding and
compare native diagnostics, including duplicate/autoglobal ordering and optional
normalization. They are fixture preparation, not actual declaration/default execution.
The first declaration-order module-load failure remains `.tools/step-first-load`.

Earlier selected/skipped illegal-expression originals live under
`../compiler5-default-stage-design/.tools/default-originals-_su6nvmv`; selected
calls/variables/bad keys reject, skipped arms compile, and selected division by zero
is deferred when the default is unused. The earlier114 protocol originals and this
12-case expansion remain historical evidence. General deferred-expression descriptor
coverage and receive-cache observability are open until source/state pairing tests.

Authority: pinned vendor/php-src commit34308a6666b2d489c509541ea9befea9e2b42348.
Anchors: Zend/zend_compile.c zend_compile_params, zend_eval_const_expr,
zend_const_expr_to_zval, zend_is_allowed_in_const_expr, zend_compile_const_expr;
Zend/zend_vm_def.h ZEND_RECV_INIT. The sibling development PHP source is not the pin.
