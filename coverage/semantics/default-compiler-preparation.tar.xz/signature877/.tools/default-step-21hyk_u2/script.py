from pathlib import Path
import base64,hashlib,json,subprocess,sys,tempfile,traceback
D=Path(__file__).resolve().parent;sys.path.insert(0,str(D/'tests/semantics'))
import static_types as T
import source_context as C
O=Path(tempfile.mkdtemp(prefix='default-step-',dir=D/'.tools'));print(O,flush=True)
manifest=json.loads((D/'signature-step-inputs.json').read_text())
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(digest(D/p)==h for p,h in manifest['files'].items())
(O/'inputs.json').write_text(json.dumps(manifest,indent=2));(O/'script.py').write_bytes(Path(__file__).read_bytes())
cases={'plain':'$x=1+2','typed-int':'int $x=1+2','typed-float':'float $x=1+2','typed-error':'string $x=1+2','duplicate':'$x=1+2,$x=0','autoglobal':'$_ENV=1+2','required-later':'$x=1+2,$y','reference':'&$x=1+2'}
(O/'cases.json').write_text(json.dumps(cases,indent=2))
def run(cmd,label):
 (O/(label+'.command.json')).write_text(json.dumps(cmd))
 try:r=subprocess.run(cmd,capture_output=True,env=T.ENV,timeout=60)
 except subprocess.TimeoutExpired as e:
  (O/(label+'.stdout')).write_bytes(e.stdout or b'');(O/(label+'.stderr')).write_bytes(e.stderr or b'');(O/(label+'.status.json')).write_text(json.dumps({'status':'timeout'}));raise
 (O/(label+'.stdout')).write_bytes(r.stdout);(O/(label+'.stderr')).write_bytes(r.stderr);(O/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}));return r
workers=[];serial=0
class Worker(T.Worker):
 def request(self,p):
  global serial
  i=serial;serial+=1;(O/f'worker-{i}-input.json').write_text(json.dumps({'command':self.p.args,'request':p}))
  try:r=super().request(p)
  except BaseException:
   (O/f'worker-{i}-failure.txt').write_text(traceback.format_exc());raise
  (O/f'worker-{i}-decoded-output.json').write_text(json.dumps(r));return r
prefix='''
dec $dsbegin(program, ptcontext) : psprogress
dec $dsclose(psprogress) : psresult
dec $dsevents(psresult) : (text, ptbytes, ptbytes, nat)*
dec $dsevent(psdiagnostic) : (text, ptbytes, ptbytes, nat)
def $dsbegin(PROGRAM ([(NStmtFunction phpType14 (BOOLEAN bool) phpType11 phpType16 phpType18 phpType23 metadata)]), ptcontext) = $psstep_start(phpType16, phpType18, bool, ptcontext)
def $dsclose(PSSDONE psresult) = psresult
def $dsclose(PSSDEFAULTREQUEST pscontinuation) = $dsclose($psstep_resume(pscontinuation, PSNONE))
  -- if pscontinuation.PARAMETER.DEFAULT = ABSENT
def $dsevents(PSOK pssignature psdiagnostic*) = ($dsevent(psdiagnostic))*
def $dsevents(PSERROR psdiagnostic*) = ($dsevent(psdiagnostic))*
def $dsevent(PSTYPEDIAGNOSTIC (PTDIAGNOSTIC text_level text_code ptbranch* ptcontext)) = (text_level, $ptmessage(PTDIAGNOSTIC text_level text_code ptbranch* ptcontext), ptcontext.FILE, ptcontext.LINE)
def $dsevent(PSDIAGNOSTIC text_level text_code ptbytes* ptcontext) = (text_level, $psmessage(PSDIAGNOSTIC text_level text_code ptbytes* ptcontext), ptcontext.FILE, ptcontext.LINE)
'''
status='failure'
try:
 frontend=Worker([str(T.PHP),'-n',*T.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')]);workers.append(frontend)
 adapter=Worker([str(D/'_build/default/adapter/main.exe'),str(D)]);workers.append(adapter)
 assertions=[];records=[]
 for i,(name,params) in enumerate(cases.items()):
  source='<?php function f('+params+') {}';f=O/(name+'.php');f.write_text(source)
  parsed=frontend.request({'op':'parse','source':base64.b64encode(source.encode()).decode()});assert parsed['accepted'],parsed
  checked=adapter.request({'op':'check','ast':parsed['ast'],'fixture':True});assert checked['ok'],checked
  native=run([str(T.PHP),'-n',*T.FLAGS,'-l',str(f)],name+'-native');assert native.returncode in (0,255)
  events=C.events(native);program=checked['fixture'];ctx='{ NAMESPACE eps, IMPORTS eps, SCOPE PTGLOBAL, POSITION PTRETURN, OWNER eps, MEMBER ([102]), FILE ('+T.byte_expr(str(f))+'), LINE 1 }'
  body=f'dec $case{i}() : bool\ndef $case{i}() = true\n  -- if program = {program}\n  -- if ptcontext = {ctx}\n'
  if name=='autoglobal':body+='  -- if $dsbegin(program, ptcontext) = PSSDONE psresult\n'
  else:
   body+='  -- if $dsbegin(program, ptcontext) = PSSDEFAULTREQUEST pscontinuation\n  -- if pscontinuation.SIGNATURE.PARAMETERS = eps\n  -- if pscontinuation.PARAMETER.DEFAULT = (expression)\n  -- if pcpath = [PCINDEX 0, PCFIELD 3, PCINDEX 0, PCFIELD 6]\n  -- if F = $pfbegin(91, program)\n  -- if $origin_node([F.SOURCE], PORIGIN 91 pcpath) = (expression)\n  -- if F_ready = $pfprepare(F, pcpath, expression, F.ENV, 1)\n  -- if F_ready.VALUE = (PINT 3)\n  -- if psresult = $dsclose($psstep_resume(pscontinuation, PSDEFAULT expression "int"))\n'
  body+='  -- if $dsevents(psresult) = '+C.expected_events(events,f)+'\n'
  if native.returncode==0:
   body+='  -- if psresult = PSOK pssignature psdiagnostic*\n'
   if name=='required-later':body+='  -- if pssignature.PARAMETERS = [psparam, psparam_second]\n  -- if psparam.REQUIRED /\\ psparam_second.REQUIRED\n  -- if psparam.DEFAULT = PSNONE /\\ psparam_second.DEFAULT = PSNONE\n'
   else:
    body+='  -- if pssignature.PARAMETERS = [psparam]\n  -- if ~psparam.REQUIRED\n  -- if psparam.DEFAULT = PSDEFAULT expression "'+('float' if name=='typed-float' else 'int')+'"\n  -- if psparam.BYREF = '+str(name=='reference').lower()+'\n'
  else:body+='  -- if psresult = PSERROR psdiagnostic*\n'
  assertions.append(body);records.append({'id':name,'source':source,'checked':checked,'native_events':events,'native_status':native.returncode})
  (O/'records.json').write_text(json.dumps(records,indent=2))
 fixture=O/'step.watsup';fixture.write_text(prefix+'\n'.join(assertions)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(cases))))
 modules=[str(D/p) for p in json.loads((D/'spec/semantics/modules.json').read_text())]
 r=run([str(D/'tests/semantics/_build/default/numeric_runner.exe'),*modules,str(fixture)],'spectec');assert r.returncode==0 and r.stdout.strip()==b'true' and not r.stderr,(r.stdout,r.stderr)
 status='pass'
finally:
 for w in workers:w.close()
 stable=all(digest(D/p)==h for p,h in manifest['files'].items())
 (O/'result.json').write_text(json.dumps({'status':status,'inputs_stable':stable,'cases':len(cases),'scope':'Private signature suspension and existing constant-folder integration fixture only; no source declaration/default receive admission. Worker records are decoded JSON responses, not exact wire.'},indent=2));assert stable
print('8 source/native signature-step checks',status,flush=True)
