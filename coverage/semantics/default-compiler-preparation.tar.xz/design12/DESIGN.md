# Shared parameter-default compilation interface

Design only; no code, helper acceptance or source activation. Firstcall and
reference-parameter candidates remain frozen. Existing114 observations in archive
52d02a43 include default/header/type priorities and deferred constants.

The next untyped positional-default stage uses a suspension point in the
existing module17 signature fold, after its name/duplicate/this/variadic checks
and before `$psdefaultready`. The suspended record carries existing `ptcontext`,
`psraw`, remaining inputs, accumulated `pssignature` and diagnostics. A resume
operation accepts the existing `psdefault` abstraction and continues through
`$psdefaultready`, `$pstypestage`, `$pspositionstage` and `$psafterone`.

Keep `$pscompile` as a wrapper that resolves this suspension with the existing
literal default helper, preserving structural-helper tests and consumers. The
actual source compiler instead resolves it with the shared module45 constant
compiler. This avoids copying the signature guards, nullable/type/default checks
or required-after-optional normalization. Module17 need not depend on runtime
`pvalue`/heap types declared later. Exact constructor names remain implementation
choices and require module-load/regression review.

For a named declaration at path D, parameter i's actual default source path is
D ++ [PCFIELD 3, PCINDEX i, PCFIELD 6], using the checked schema. Store source
origin and actual compiled/deferred default representation in a function-side
descriptor; keep `psdefault`'s checked AST and materialization kind for shared
type/default checking. Do not create replacement literal source occurrences.
The actual constant value belongs to the existing unit's constant pool, with
fresh array containers during each receive. A deferred constant expression keeps
its original source, namespace/imports, declaration magic context and diagnostics.

Two source facts constrain this adapter. `zend_compile_params` sets both
NO_CONSTANT_SUBSTITUTION flags while compiling defaults, including persistent
constants such as PHP_VERSION. Module45 currently calls module23 `$pnfold`, which
can substitute builtin constants: a parameter-default policy must affect that
same shared lookup, while preserving true/false/null. Do not implement a second
constant evaluator.

Second, `zend_const_expr_to_zval` invokes `zend_eval_const_expr` before
`zend_compile_const_expr` validates the remaining AST. An up-front scan rejecting
every invalid operation in the original tree can therefore be wrong after
constant folding selects a branch. Reuse module45 folding/redirect facts, then
validate the remaining expression under the actual constant-expression policy.
Twelve additional originals now retain selected/skipped invalid operations in
`.tools/default-originals-_su6nvmv`. Skipped call/variable/invalid-array-key arms
compile successfully; selecting them produces the native static error. A selected
division by zero still compiles and an unused default does not evaluate it. These
are original observations, not agreement with a new default implementation. Allowed object,
closure and first-class callable constant forms remain explicit dependencies,
not silently invalid operations.

The next admission is untyped positional defaults, paired with actual omitted-
argument receive/materialization, references for defaulted reference parameters,
fresh array containers, deferred constant errors only when used, and return/error
ownership. It does not admit parameter or return types, variadics, named/unpacked
arguments, or additional callable forms. Existing module17 type checks remain
shared compile-phase machinery so mixed invalid headers retain their native
priority, but successful typed declarations remain explicitly unsupported by the
source runtime until the later type milestone.

The later type milestone adds argument and return enforcement, caller strictness
for arguments, declaration body strictness for returns, and reference coercion /
alias effects. Return-expression compilation precedes void/never/bare typed-return
static checks. Preserve originals and test mixed invalid headers so type/default/
body diagnostic priority stays visible across that future admission.

Primary source pin:34308a6666b2d489c509541ea9befea9e2b42348. Anchors in
Zend/zend_compile.c: zend_compile_params, zend_is_allowed_in_const_expr,
zend_compile_const_expr, zend_const_expr_to_zval, zend_eval_const_expr.
