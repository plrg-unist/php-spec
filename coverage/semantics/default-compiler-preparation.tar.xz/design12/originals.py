from pathlib import Path
import base64,hashlib,json,os,subprocess,sys,tempfile,signal
O=Path(__file__).resolve().parent;D=O.parent/'compiler5-broad-compiler';sys.path.insert(0,str(D/'tests/semantics'));import static_types as t
CASES=json.loads((O/'cases.json').read_text())

def invoke(command,out,label):
 (out/(label+'.command.json')).write_text(json.dumps(command))
 try:r=subprocess.run(command,capture_output=True,env=t.ENV,timeout=20)
 except subprocess.TimeoutExpired as e:
  (out/(label+'.stdout')).write_bytes(e.stdout or b'');(out/(label+'.stderr')).write_bytes(e.stderr or b'');(out/(label+'.status.json')).write_text(json.dumps({'status':'timeout','seconds':20}));raise
 (out/(label+'.stdout')).write_bytes(r.stdout);(out/(label+'.stderr')).write_bytes(r.stderr);(out/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':r.returncode}))
 return {'stdout':base64.b64encode(r.stdout).decode(),'stderr':base64.b64encode(r.stderr).decode(),'exit_status':r.returncode,'command':command}

out=Path(tempfile.mkdtemp(prefix='default-originals-',dir=O/'.tools'));rows=[];manifest=json.loads((D/'copied-inputs.json').read_text())
for rel,h in manifest['files'].items():assert hashlib.sha256((D/rel).read_bytes()).hexdigest()==h,rel
f=t.Worker([str(t.PHP),'-n',*t.FLAGS,'-d','extension='+str(D/'.tools/php-file.so'),str(D/'frontend/worker.php')]);a=t.Worker([str(D/'_build/default/adapter/main.exe'),str(D)])
print(out,flush=True)
try:
 for name,body in CASES.items():
  case=out/name;case.mkdir();source=body.encode();path=case/'source.php';path.write_bytes(source)
  row={'id':name,'source_base64':base64.b64encode(source).decode(),'file':str(path),'lint':invoke([str(t.PHP),'-n',*t.FLAGS,'-l',str(path)],case,'lint'),'native':invoke([str(t.PHP),'-n',*t.FLAGS,str(path)],case,'native')}
  parsed=f.request({'op':'parse','source':row['source_base64']});(case/'parsed.json').write_text(json.dumps(parsed));row['parsed']=parsed.get('accepted',False)
  if parsed.get('accepted'):
   checked=a.request({'op':'check','ast':parsed['ast'],'fixture':True});(case/'checked.json').write_text(json.dumps(checked));assert checked['ok'],checked
   fixture=case/'compiler-state.watsup';fixture.write_text('dec $main() : ppstate\ndef $main() = $ppstart(91, '+checked['fixture']+', '+t.byte_expr(str(path))+')\n')
   row['compiler']=invoke([str(D/'tests/semantics/_build/default/numeric_runner.exe'),*[str(D/r) for r in json.loads((D/'spec/semantics/modules.json').read_text())],str(fixture)],case,'compiler')
   request={'op':'execute','ast':parsed['ast'],'steps':10000,'filename':base64.b64encode(str(path).encode()).decode()};(case/'execute-input.json').write_text(json.dumps(request));result=a.request(request);(case/'runtime-state.json').write_text(json.dumps(result));row['runtime_state']=str(case/'runtime-state.json')
  rows.append(row);(out/'records.json').write_text(json.dumps({'scope':'Original source/compile/runtime states before next call-protocol implementation; Unsupported and tool failures are not agreements.','baseline':manifest,'records':rows},indent=2));print(name,'lint',row['lint']['exit_status'],'native',row['native']['exit_status'],flush=True)
finally:f.close();a.close()
assert all(hashlib.sha256((D/rel).read_bytes()).hexdigest()==h for rel,h in manifest['files'].items())
