from pathlib import Path
import json,hashlib,tarfile,io,stat
R=Path(__file__).resolve().parent;files={}
for n in ['baseline-inputs.json','final-inputs.json','test-bridge.json','archive-tests.py','tests/semantics/strict_declaration_cases.json','tests/semantics/strict_declaration_compiler.py','coverage/semantics/strict-declaration-compiler.json']:files[n]=R/n
for p in (R/'.tools/strict-declaration-compiler-14_rwzgy').rglob('*'):
 if p.is_file():files[str(p.relative_to(R))]=p
hashes={n:hashlib.sha256(p.read_bytes()).hexdigest() for n,p in files.items()};modes={n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()};seen={};out=R/'tests-originals.tar.xz'
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'modes':modes},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(data);t.addfile(z,io.BytesIO(data))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);h=hashes[n]
  if (h,modes[n]) in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[h,modes[n]];z.size=0;t.addfile(z)
  else:
   seen[h,modes[n]]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(out,'r:xz') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
j=json.loads((R/'test-bridge.json').read_text());report={'scope':j['scope'],'archive':str(out),'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'paths':len(files),'bytes':out.stat().st_size,'candidate':j['candidate'],'baseline':j['baseline'],'dependency':'Immutable strict-preparation8e7f6e1e archive supplies exact910 source inputs and excluded tool hashes; this supplement supplies two new tests, full912 manifests and complete new portable gate.','gates':{'exact_phase_comparisons':37,'pending_other_directives':2,'context_assertions':47},'transport':j['transport'],'build':j['build']};(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
