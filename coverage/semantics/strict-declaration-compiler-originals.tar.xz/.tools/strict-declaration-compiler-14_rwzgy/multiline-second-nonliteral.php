<?php
declare(
strict_types=1,
strict_types=1+0
);