#!/usr/bin/php
<?php declare(strict_types=1);