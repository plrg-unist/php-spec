from pathlib import Path
import hashlib,json,stat,tarfile,io
R=Path(__file__).resolve().parent;P=R.parent.parent;D=R/'publication/coverage/semantics';D.mkdir(parents=True,exist_ok=True);files={}
def add(path,name):
 assert path.is_file(),path
 assert name not in files or files[name]==path,(name,path)
 files[name]=path
snapshots=[('baseline933',P/'.tools/runtime7-acquire-candidate',P/'.tools/runtime7-acquire-candidate/final-inputs.json'),('first935',P/'.tools/runtime7-return-first',P/'.tools/runtime7-return-first/inputs.json'),('guarded935',P/'.tools/runtime7-return-guarded',P/'.tools/runtime7-return-guarded/inputs.json'),('integration942',P/'.tools/runtime7-return-integration',P/'.tools/runtime7-return-integration/inputs.json'),('statefix942',P/'.tools/runtime7-return-statefix',P/'.tools/runtime7-return-statefix/inputs.json'),('statefix2_942',P/'.tools/runtime7-return-statefix2',P/'.tools/runtime7-return-statefix2/inputs.json'),('final942',R,R/'final-inputs.json')]
for label,root,mp in snapshots:
 j=json.loads(mp.read_text());assert len(j['files'])==j['fingerprint']['files'];add(mp,'snapshots/'+label+'/INPUTS.json')
 for n,h in j['files'].items():
  p=root/n;assert hashlib.sha256(p.read_bytes()).hexdigest()==h,(label,n);assert stat.S_IMODE(p.stat().st_mode)==j['modes'][n],(label,n);add(p,'snapshots/'+label+'/'+n)
roots=[]
for root in [R]:
 roots += [d for d in (root/'.tools').iterdir() if d.is_dir()]
 roots += [root/'final-gates'] if (root/'final-gates').exists() else []
 for p in root.iterdir():
  if p.is_file() and p.suffix in ('.py','.json','.md','.watsup','.stdout','.stderr'):add(p,'preparation/'+str(p.relative_to(P)))
 for p in (root/'coverage/semantics').glob('*.json'):add(p,'reports/'+str(p.relative_to(P)))
for root in roots:
 for p in root.rglob('*'):
  if p.is_file():add(p,'raw/'+str(p.relative_to(P)))
for n in ['Zend/zend_compile.c','Zend/zend_vm_def.h','Zend/zend_execute.c','Zend/zend_exceptions.c','Zend/zend_operators.c','Zend/zend_execute_API.c','Zend/zend_hash.c']:add(P/'vendor/php-src'/n,'pinned-source/'+n)
manifest={n:{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'mode':stat.S_IMODE(p.stat().st_mode)} for n,p in sorted(files.items())};meta={'scope':'Complete exact933 baseline, early935 and guarded935, integration942, two failed state-test generator942 revisions and final942 snapshots. Author original/full-request/source/demand/phase/state/regression history is retained. Compiler and reviewer archives separately preserve their original observations and mutations. Setup failures and Unsupported never count as agreement.','files':manifest};payload=(json.dumps(meta,indent=2)+'\n').encode();target=D/'reference-return-runtime-originals.tar.xz';assert not target.exists()
seen={}
with tarfile.open(target,'w:xz',preset=6) as t:
 info=tarfile.TarInfo('MANIFEST.json');info.size=len(payload);info.mode=0o644;t.addfile(info,io.BytesIO(payload))
 for name,p in sorted(files.items()):
  entry=manifest[name];info=tarfile.TarInfo(name);info.mode=entry['mode'];key=(entry['sha256'],entry['mode'])
  if key in seen:
   info.type=tarfile.LNKTYPE;info.linkname=seen[key];t.addfile(info)
  else:
   raw=p.read_bytes();info.size=len(raw);t.addfile(info,io.BytesIO(raw));seen[key]=name
a={'archive':'coverage/semantics/'+target.name,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'bytes':target.stat().st_size,'payload_files':len(files),'members':len(files)+1,'manifest_sha256':hashlib.sha256(payload).hexdigest(),'snapshots':{label:json.loads(mp.read_text())['fingerprint'] for label,root,mp in snapshots},'scope':meta['scope'],'compiler_archive':'coverage/semantics/reference-return-compiler-originals.tar.xz'};(D/'reference-return-runtime-originals.json').write_text(json.dumps(a,indent=2)+'\n');print(a,flush=True)
