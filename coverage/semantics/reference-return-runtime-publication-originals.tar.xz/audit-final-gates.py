from pathlib import Path
import base64,hashlib,json,stat,sys
R=Path(__file__).resolve().parent;sys.path.insert(0,str(R/'tests/semantics'));import function_scope as fs
expected=json.loads((R/'final-inputs.json').read_text());assert fs.q.t.syntax_validation.implementation_fingerprint()==expected['fingerprint'];assert all(hashlib.sha256((R/n).read_bytes()).hexdigest()==h and stat.S_IMODE((R/n).stat().st_mode)==expected['modes'][n] for n,h in expected['files'].items())
reports={n:json.loads((R/'coverage/semantics'/f'{n}.json').read_text()) for n in ['reference-return-compiler','reference-returns','reference-return-demand','reference-return-state','typed-functions','call-reference-acquisition']};roots=[];audit=[]
for name,j in reports.items():
 assert j['result']=='pass',name
 if 'fingerprint' in j:
  candidates=[json.loads((R/n).read_text()) for n in ['integration-inputs.json','statefix2-inputs.json','final-inputs.json']]
  old=next(m for m in candidates if m['fingerprint']==j['fingerprint'])
  changed=[n for n in old['files'] if old['files'][n]!=expected['files'][n] or old['modes'][n]!=expected['modes'][n]]
  assert changed in [[],['tests/semantics/reference_return_state.py']],(name,changed)
 d=Path(j['raw']);d=d if d.is_absolute() else R/d;roots.append(d)
 for n,h in j.get('inputs',{}).items():assert hashlib.sha256((R/n).read_bytes()).hexdigest()==h,(name,n)
 for row in j.get('records',[]):
  if 'native' not in row or 'request' not in row:continue
  if 'source_base64' in row:
   src=base64.b64decode(row['source_base64']);path=Path(row.get('context',base64.b64decode(row['request']['file']).decode()));assert path.read_bytes()==src
   directory=path.parent;assert base64.b64decode(row['native']['stdout'])==(directory/'native.stdout').read_bytes();assert base64.b64decode(row['native']['stderr'])==(directory/'native.stderr').read_bytes();status=json.loads((directory/'native.status.json').read_text());assert status=={'status':'exit','exit_status':row['native']['exit_status']}
   entries=[base64.b64decode(k)+b'='+base64.b64decode(v) for k,v in row['request']['env']];assert (directory/'request.input').read_bytes()==fs.q.packet(int(row['request']['seconds']),row['request']['microseconds'],entries)
 workers=[];runners=[]
 for close in sorted(d.rglob('close.json')):
  w=close.parent;s=json.loads(close.read_text());assert s=={'status':'exit','exit_status':0,'final_exit_status':0};assert not (w/'stderr').read_bytes() and not (w/'trailing.stdout').read_bytes();req=sorted(w.glob('*.request'),key=lambda p:int(p.stem));res=sorted(w.glob('*.response'),key=lambda p:int(p.stem));assert [p.stem for p in req]==[str(i) for i in range(len(req))];assert [p.stem for p in req]==[p.stem for p in res]
  for p in res:assert p.read_bytes().endswith(b'\n') and fs.q.t.wire.loads(p.read_text())['ok']
  workers.append({'path':str(w.relative_to(R)),'responses':len(res),'closure':s})
 for cp in sorted(d.rglob('*.command.json')):
  cmd=json.loads(cp.read_text())
  if Path(cmd[0]).name!='numeric_runner.exe':continue
  prefix=cp.name.removesuffix('.command.json');out=cp.with_name(prefix+'.stdout');err=cp.with_name(prefix+'.stderr');status=cp.with_name(prefix+'.status.json');s=json.loads(status.read_text());assert s.get('status')=='exit' and s['exit_status']==0 and out.read_bytes()==b'true\n' and not err.read_bytes();runners.append(str(cp.relative_to(R)))
 audit.append({'gate':name,'raw':str(d),'workers':workers,'runners':runners})
result={'result':'pass','fingerprint':expected['fingerprint'],'gates':audit,'worker_closures':sum(len(x['workers']) for x in audit),'responses':sum(w['responses'] for x in audit for w in x['workers']),'standalone_runner_closures':sum(len(x['runners']) for x in audit)};(R/'final-gate-audit.json').write_text(json.dumps(result,indent=2)+'\n');print({k:v for k,v in result.items() if k!='gates'})
