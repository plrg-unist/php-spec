<?php
$x=&strlen(
 "a"
);