from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'compiler6-reference-calls';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
CASES={
'array-call-ref-line':b'<?php\nfunction g(){return 1;}\n$a=[\n &g(\n )\n];',
'array-call-ref-key-line':b'<?php\nfunction k(){return 0;}\nfunction g(){return 1;}\n$a=[\n k(\n ) =>\n &g()\n];',
'array-call-ref-argument-priority':b'<?php function g(){return 1;}$a=[&g(1/0)];',
'array-call-ref-key-priority':b'<?php function g(){return 1;}$a=[1/0=>&g()];',
}
(R/'array-phase-gap-cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
scope.main(CASES,'reference-array-phase-gaps',Path(scope.__file__))
