from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'compiler6-reference-calls';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
CASES={
'acquire-cv-existing-alias':b'<?php function g(){return 1;}$x=7;$alias=&$x;$x=&g();echo $x,$alias;$x=2;echo $alias;',
'acquire-computed-existing-alias':b'<?php function g(){return 1;}$x=7;$alias=&$x;$n="x";$$n=&g();echo $x,$alias;$x=2;echo $alias;',
'acquire-dim-existing-alias':b'<?php function g(){return 1;}$a=[7];$alias=&$a[0];$a[0]=&g();echo $a[0],$alias;$a[0]=2;echo $alias;',
'acquire-array-reference-item':b'<?php function g(){return 1;}$a=[&g()];echo $a[0];$alias=&$a[0];$a[0]=2;echo $alias;',
'acquire-multiline-cv':b'<?php\nfunction g(){return 1;}\n$x\n = &g(\n );\necho $x;',
'acquire-multiline-computed':b'<?php\nfunction g(){return 1;}\n$n="x";\n$$n\n = &g(\n );\necho $x;',
'acquire-array-key-order':b'<?php function k(){echo "K";return 0;}function g(){echo "G";return 1;}$a=[k()=>&g()];echo $a[0];',
}
(R/'acquire-gap-cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
scope.main(CASES,'reference-acquire-gaps',Path(scope.__file__))
