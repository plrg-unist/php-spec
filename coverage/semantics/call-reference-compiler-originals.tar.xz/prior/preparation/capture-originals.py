from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-strict-directive';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
cases={
'ref-return-bare':b'<?php function &f(){return;} $x=&f();echo $x===null;',
'ref-return-implicit':b'<?php function &f(){} $x=&f();echo $x===null;',
'ref-return-unused-constant':b'<?php function &f(){return 1;}f();echo "E";',
'ref-return-unused-local':b'<?php function &f(){$x=1;return $x;}f();echo "E";',
'ref-return-forward-reference':b'<?php $x=1;function &g(){global $x;return $x;}function &f(){return g();}$r=&f();$r=2;echo $x;',
'ref-return-forward-value':b'<?php function g(){return 1;}function &f(){return g();}$r=&f();echo $r;',
'ref-return-forward-unused':b'<?php function g(){return 1;}function &f(){return g();}f();echo "E";',
'ref-return-typed-alias-coercion':b'<?php $x="2";$alias=&$x;function &f():int{global $x;return $x;}$r=&f();echo $x===2,$alias===2;$r=3;echo $x,$alias;',
'ref-return-void-bare':b'<?php function &f():void{return;}f();echo "E";'}
(R/'cases.json').write_text(json.dumps({n:s.decode() for n,s in cases.items()},indent=2)+'\n');scope.main(cases,'reference-return-originals',Path(scope.__file__))
