from pathlib import Path
import json,hashlib,stat,tarfile,io
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-strict-directive';C=R.parent.parent;m=json.loads((B/'final-inputs.json').read_text());files={};tools={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.md'] and p.name!='archive.json':add('preparation/'+p.name,p)
for label,name in [('return9','originals.json'),('valuecall1','valuecall-original.json')]:
 O=Path(json.loads((R/name).read_text())['raw'])
 for p in O.rglob('*'):
  if p.is_file():add(label+'/'+str(p.relative_to(O)),p)
for n,h in m['files'].items():
 p=B/n;assert digest(p)==h and stat.S_IMODE(p.stat().st_mode)==m['modes'][n],n;add('baseline917/'+n,p)
for n in ['Zend/zend_compile.c','Zend/zend_execute.c','Zend/zend_vm_def.h']:add('vendor/php-src/'+n,C/'vendor/php-src'/n)
hashes={n:digest(p) for n,p in files.items()};modes={n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()};seen={};out=R/'originals.tar.xz'
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'modes':modes,'tools':tools,'baseline':m},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(data);t.addfile(z,io.BytesIO(data))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);h=hashes[n]
  if (h,modes[n]) in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[h,modes[n]];z.size=0;t.addfile(z)
  else:
   seen[h,modes[n]]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(out,'r:xz') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
report={'scope':'Reference-return/call-reference preparation only:9+1new native/current917 compiler/runtime originals and7historical114 identities. All runtimeUnsupported, no source activation or reference-return implementation.','archive':str(out),'sha256':digest(out),'paths':len(files),'bytes':out.stat().st_size,'baseline':m['fingerprint'],'tools':tools,'transport':'Raw recorded worker frames/stderr/closure, native full primitive request, separate lint/compiler subprocess bytes/commands/exit status.','build':'No rebuild; full917 source hashes/modes and excluded executed tool hashes/modes retained.','plan':'preparation/PLAN.md'};(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
