from pathlib import Path
import sys,json,hashlib,stat,base64,subprocess,signal
R=Path(__file__).resolve().parent;C=R.parent.parent;B=C/'.tools/compiler6-reference-calls';m=json.loads((B/'baseline-inputs.json').read_text());sys.path.insert(0,str(B/'tests/semantics'));import static_types as t;import function_scope as scope;from recorded_worker import Worker
O=R/'current926-originals';O.mkdir();(O/'baseline-inputs.json').write_text(json.dumps(m,indent=2)+'\n')
selection=[]
for f in ['originals.json','valuecall-original.json']:
 old=Path(json.loads((R/f).read_text())['raw'])
 for row in json.loads((old/'originals.json').read_text()):selection.append((old,row))
assert len(selection)==10
mods=[str(B/p) for p in json.loads((B/'spec/semantics/modules.json').read_text())]
def verify():
 for p,h in m['files'].items():
  assert hashlib.sha256((B/p).read_bytes()).hexdigest()==h,p
  assert stat.S_IMODE((B/p).stat().st_mode)==m['modes'][p],p
verify();a=Worker([str(B/'_build/default/adapter/main.exe'),str(B)],O/'adapter-wire');rows=[]
def expired(signum,frame):raise TimeoutError('reference baseline worker exceeded60seconds')
previous=signal.signal(signal.SIGALRM,expired)
try:
 for old,x in selection:
  d=O/x['id'];d.mkdir();p=Path(x['context']);prior=old/x['id'];assert p.read_bytes()==base64.b64decode(x['source_base64']);parsed=json.loads((prior/'parsed.json').read_text());request=json.loads((prior/'execute.json').read_text());assert request['ast']==parsed['ast'];assert request['request']==x['request'];assert base64.b64decode(request['filename']).decode()==str(p)
  signal.alarm(60);k=a.request({'op':'check','ast':parsed['ast'],'fixture':True});signal.alarm(0);assert k['ok'];(d/'checked.json').write_text(json.dumps(k));w=d/'compiler-state.watsup';w.write_text(f'dec $main() : ppstate\ndef $main() = $ppstart(91, {k["fixture"]}, {t.byte_expr(str(p))})\n');cmd=[str(B/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(w)];(d/'compiler.command.json').write_text(json.dumps(cmd));z=subprocess.run(cmd,capture_output=True,env=t.ENV,timeout=60);(d/'compiler.stdout').write_bytes(z.stdout);(d/'compiler.stderr').write_bytes(z.stderr);(d/'compiler.status.json').write_text(json.dumps({'status':'exit','exit_status':z.returncode}));assert z.returncode==0 and not z.stderr
  (d/'execute.json').write_text(json.dumps(request));signal.alarm(60);result=a.request(request);signal.alarm(0);(d/'state.json').write_text(json.dumps(result));actual=scope.q.cli.observe(result['state'],str(p));(d/'observation.json').write_text(json.dumps(actual));row={'id':x['id'],'original_raw':str(prior),'source_file':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'native':x['native'],'request':request,'compiler_classification':'unsupported' if b'COMPLETION PPCABRUPT UNSUPPORTED ' in z.stdout else 'static_rejection' if b'COMPLETION PPCABRUPT STATICBYTES ' in z.stdout else 'normal' if b'COMPLETION PPCNORMAL' in z.stdout else 'other','runtime_classification':actual['status'],'actual':actual,'raw':str(d)};rows.append(row);(O/'records.json').write_text(json.dumps(rows,indent=2)+'\n');print(x['id'],row['compiler_classification'],row['runtime_classification'],flush=True)
finally:
 signal.alarm(0);signal.signal(signal.SIGALRM,previous);a.close()
verify();report={'scope':'Exact accepted926 replay of ten retained917 reference-return/call-acquisition originals. Original native filename/source/profile/bytes retained; no native rerun and no source admission or runtime agreement claimed.','baseline':m['fingerprint'],'records':rows,'transport':'Recorded adapter packets/stderr/closure and raw full compiler commands/bytes/status. Verbatim original full primitive execution requests. Native compilation phase and native execution remain separate.','counts':{s:sum(x['compiler_classification']==s for x in rows) for s in ['unsupported','static_rejection','normal','other']}};(O/'report.json').write_text(json.dumps(report,indent=2)+'\n');print(report['counts'])
