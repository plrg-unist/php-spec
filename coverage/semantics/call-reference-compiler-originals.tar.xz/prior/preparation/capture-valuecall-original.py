from pathlib import Path
import sys
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-strict-directive';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
scope.main({'reference-assignment-value-call':b'<?php function g(){return 1;}$x=&g();echo $x;'},'reference-valuecall-original',Path(scope.__file__))
