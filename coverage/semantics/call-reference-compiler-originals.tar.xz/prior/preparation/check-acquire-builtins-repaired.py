from pathlib import Path
import sys,json,hashlib,stat,subprocess,tempfile,signal
R=Path(__file__).resolve().parent;C=R.parent.parent;B=C/'.tools/compiler6-reference-calls';OLD=C/'.tools/runtime6-typed-calls';sys.path.insert(0,str(B/'tests/semantics'));import static_types as t,source_context as sc,source_compiler as c;from recorded_worker import Worker
m=json.loads((B/'baseline-inputs.json').read_text());paths=set(m['files'])|{'spec/semantics/96-call-reference-compiler.watsup'};f={'fingerprint':t.syntax_validation.implementation_fingerprint(),'files':{p:hashlib.sha256((B/p).read_bytes()).hexdigest() for p in sorted(paths)},'modes':{p:stat.S_IMODE((B/p).stat().st_mode) for p in sorted(paths)}};(B/'repaired-inputs.json').write_text(json.dumps(f,indent=2)+'\n')
O=Path(tempfile.mkdtemp(prefix='acquire-compiler-phases-',dir=B/'.tools'));print(O,flush=True);(O/'inputs.json').write_text(json.dumps(f,indent=2)+'\n')
roots=[C/'.tools/runtime6-typed-calls/.tools/reference-acquire-builtin-gaps-2qf7mr5t'];rows=[(old,x) for old in roots for x in json.loads((old/'originals.json').read_text())];assert len(rows)==4
mods={tag:[str(root/p) for p in json.loads((root/'spec/semantics/modules.json').read_text())] for tag,root in [('old',OLD),('candidate',B)]}
def run(cmd,d,label):
 (d/(label+'.command.json')).write_text(json.dumps(cmd));z=subprocess.run(cmd,capture_output=True,env=t.ENV,timeout=60);(d/(label+'.stdout')).write_bytes(z.stdout);(d/(label+'.stderr')).write_bytes(z.stderr);(d/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':z.returncode}));return z
w=Worker([str(OLD/'_build/default/adapter/main.exe'),str(OLD)],O/'adapter-wire');assertions=[];records=[]
try:
 for i,(old,x) in enumerate(rows):
  p=Path(x['context']);d=O/x['id'];d.mkdir();parsed=json.loads((old/x['id']/'parsed.json').read_text());k=w.request({'op':'check','ast':parsed['ast'],'fixture':True});assert k['ok'];(d/'checked.json').write_text(json.dumps(k));fixture=d/'state.watsup';fixture.write_text(f'dec $main() : ppstate\ndef $main() = $ppstart(91, {k["fixture"]}, {t.byte_expr(str(p))})\n');native=run([str(OLD/'.tools/php/bin/php'),'-n',*t.FLAGS,'-l',str(p)],d,'lint');assert native.returncode in [0,255]
  z=run([str(OLD/'tests/semantics/_build/default/numeric_runner.exe'),*mods['old'],str(fixture)],d,'old-compiler');assert z.returncode==0 and not z.stderr
  body=f'  -- if P = $ppstart(91, {k["fixture"]}, {t.byte_expr(str(p))})\n  -- if $pptrace(P) = '+sc.expected_events(sc.events(native),p)+'\n'
  if native.returncode==0:body+='  -- if P.COMPLETION = PPCNORMAL\n'
  assertions.append(f'dec $case{i}() : bool\ndef $case{i}() = true\n'+body);records.append({'id':x['id'],'source_file':str(p),'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'original_native':x['native'],'checks':body,'old_compiler_unsupported':b'COMPLETION PPCABRUPT UNSUPPORTED ' in z.stdout,'lint_exit':native.returncode})
finally:w.close()
(O/'records.json').write_text(json.dumps(records,indent=2)+'\n');fixture=O/'phases.watsup';fixture.write_text(c.PREFIX+'\n'.join(assertions)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(len(rows))));z=run([str(B/'tests/semantics/_build/default/numeric_runner.exe'),*mods['candidate'],str(fixture)],O,'candidate');print(z.returncode,z.stdout.decode(),z.stderr.decode(),flush=True);assert z.returncode==0 and z.stdout==b'true\n' and not z.stderr
assert f['fingerprint']==t.syntax_validation.implementation_fingerprint();(O/'report.json').write_text(json.dumps({'result':'pass','scope':'Four native compiler phases; exact old926 full compiler Unsupported retained before candidate test, no runtime agreement claim.','compared':4,'inputs':f['fingerprint'],'records':records},indent=2)+'\n')
