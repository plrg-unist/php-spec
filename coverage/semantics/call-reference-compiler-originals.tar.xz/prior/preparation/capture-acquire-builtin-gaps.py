from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-typed-calls';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
CASES={
'acquire-builtin-strlen':b'<?php $x=&strlen("a");',
'acquire-builtin-strlen-line':b'<?php\n$x=&strlen(\n "a"\n);',
'acquire-builtin-in-array':b'<?php $x=&in_array(1,[1]);',
'acquire-builtin-chr-boundary':b'<?php $x=&chr(65);echo $x;',
}
(R/'acquire-builtin-gap-cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
scope.main(CASES,'reference-acquire-builtin-gaps',Path(scope.__file__))
