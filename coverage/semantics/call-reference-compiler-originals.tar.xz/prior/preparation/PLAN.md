# Reference-return and call-reference preparation

Preparation only, after the typed94/95 checkpoint. Keep compiler920/495fd39b
immutable. No reference-return compiler/runtime implementation or canonical source
admission is made here. The source/runtime interface must be independently reviewed
before a compatible prerequisite or the complete reference-return increment lands.

Reuse17's normalized `pssignature.BYREF`, return-type/default ordering and existing
void-reference deprecation. Reuse94's scoped return types, static checks, ENDLINE
and return-root lines. A body-local reference-return bool may be needed alongside
RETURNS, set from the normalized signature and restored across nested functions;
no duplicate signature normalization or general call-context abstraction is needed.

Pinned `zend_compile_return` treats variables and calls differently. Its local
`zend_is_variable` includes CV/dimension/property forms, but excludes calls. A
by-reference variable return compiles through BP_VAR_W; a call return still compiles
as an expression and gets ZEND_RETURNS_FUNCTION. Other expressions get the value
classification. Nullsafe/short-circuit reference restrictions remain source checks;
class/object/method protocols stay explicit dependent core work. The existing114
originals already include missing-variable, literal, value-consumer, append-return,
nullsafe, and parameter-send-from-reference-call cases; retain those identities.

There is a separate required call-reference acquisition prerequisite. An ordinary
`$x =& g()` where g returns a value is currently rejected during compiler PPW call
handling, and runtime ACQUIRE-call support is also absent. Native emits `Only
variables should be assigned by reference` and binds a fresh reference to the
returned value. Do not confuse that notice with the return-specific or parameter-
send-specific notices. Source admission should target reference-source contexts,
not make every function call an arbitrary writable expression. Existing compiler
PPW handling of a call used as a dimension base deliberately lowers its base as a
read; accepted temporary-call DIM/reference-parameter behavior must remain intact.
A small reference-source compiler helper can select read mode for calls and the
existing write mode for variable/dimension sources where needed by assignment or
array reference operands. Its exact callers and source guards require review.

Runtime needs an owning returned REFERENCE cell that survives callee table/frame
cleanup. Existing79 assumes RESULT owns the returned operand before releasing the
callee; existing86 already preserves REFERENCE operands for reference sends and
uses explicit temporary slots for value-returned writable dimensions. Extend those
protocols without turning an unnamed value slot into a source alias. ACQUIRE on an
actual call result must preserve its reference when present and apply the proper
assignment notice/fresh-cell behavior to a value result. Value consumers resolve
the reference; reference consumers preserve its cell and COW ownership.

Return verification from95 must run before reference-return frame cleanup. A
native weak typed reference return can coerce the actual shared source cell: the
new alias-coercion original prints1133 after converting both aliases to int, then
mutating through the returned reference. Copying a value first would lose this
behavior. Typed-property reference constraints, finally rechecks, generators and
object effects remain required dependent increments. Pinned return compilation
verifies types before unwind/finally and may repeat verification for reference
returns after finally; do not claim those controls supported by the plain-call
increment.

Nine new exact native/current917 runtime and compiler originals cover explicit
bare versus implicit return, unused literal/local results, forwarding reference
versus value-returning calls, unused forwarded values, typed alias coercion and
void-reference deprecation. Both bare and implicit returns emit the native return-
reference notice. Unused literal/value-call results still notice; an unused local
variable return does not. A separate tenth original captures value-call reference
assignment and its distinct source/compiler boundary. These fill concrete gaps
in114; they do not rerun its broad corpus or claim runtime agreement. All current
runtime outcomes are Unsupported. Lint phases remain separate from full primitive
request runtime observations; packet/stderr/closure evidence is retained.

Authority: pinned PHP8.5.10 Zend/zend_compile.c `zend_compile_return`,
`zend_emit_final_return`, `zend_is_variable`, `zend_is_call` and reference-assignment
compilation; zend_vm_def.h `ZEND_RETURN_BY_REF`; existing17,79,86 and94/95 interfaces.
Before implementation, freeze the accepted typed successor and replay these exact
source profiles to that baseline, preserving this917 preparation identity. Agree
result demand, source-bound acquisition/return classifications and ownership gates
with the runtime implementer and independent reviewer.
