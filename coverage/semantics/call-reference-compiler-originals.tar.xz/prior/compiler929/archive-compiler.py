from pathlib import Path
import json,hashlib,stat,tarfile,io
R=Path(__file__).resolve().parent;C=R.parent.parent;I=C/'.tools/compiler6-reference-returns';B=C/'.tools/runtime6-typed-calls';m=json.loads((R/'final-inputs.json').read_text());b=json.loads((R/'baseline-inputs.json').read_text());files={};tools={};aliases={}
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(n,p):
 if p.name in ['php','main.exe','numeric_runner.exe','php-file.so','request-clock.so']:tools[n]={'sha256':digest(p),'mode':stat.S_IMODE(p.stat().st_mode)}
 else:files[n]=p
def tree(label,root):
 for p in root.rglob('*'):
  if p.is_file() and p.suffix!='.pyc' and '__pycache__' not in p.parts:add(label+'/'+str(p.relative_to(root)),p)
for label,root,manifest in [('compiler929',R,m),('baseline926',B,b)]:
 for n,h in manifest['files'].items():
  p=root/n;assert digest(p)==h and stat.S_IMODE(p.stat().st_mode)==manifest['modes'][n],n;add(label+'/'+n,p)
for p in R.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.md'] and p.name!='archive.json':add('compiler929/'+p.name,p)
tree('compiler929/.tools',R/'.tools')
add('compiler929/coverage/semantics/call-reference-compiler.json',R/'coverage/semantics/call-reference-compiler.json')
for p in I.iterdir():
 if p.is_file() and p.suffix in ['.json','.py','.md']:add('preparation/'+p.name,p)
tree('preparation/current926-originals',I/'current926-originals')
for label,name in [('retained917-return','originals.json'),('retained917-valuecall','valuecall-original.json')]:
 root=Path(json.loads((I/name).read_text())['raw']);tree(label,root)
 for row in json.loads((root/'originals.json').read_text()):
  tool=Path(row['native']['command'][0]);assert digest(tool)==b['files']['.tools/php/bin/php'];aliases[str(tool)]={'sha256':digest(tool),'mode':stat.S_IMODE(tool.stat().st_mode),'current_binding':'baseline926/.tools/php/bin/php'}
tree('builtin-originals926',B/'.tools/reference-acquire-builtin-gaps-2qf7mr5t')
for name in ['Zend/zend_compile.c','Zend/zend_execute.c','Zend/zend_vm_def.h']:add('vendor/php-src/'+name,C/'vendor/php-src'/name)
hashes={n:digest(p) for n,p in files.items()};modes={n:stat.S_IMODE(p.stat().st_mode) for n,p in files.items()};seen={};out=R/'originals.tar.xz'
with tarfile.open(out,'w:xz',preset=6) as t:
 data=(json.dumps({'files':hashes,'modes':modes,'tools':tools,'historical_native_tool_aliases':aliases},indent=2)+'\n').encode();z=tarfile.TarInfo('SHA256.json');z.size=len(data);t.addfile(z,io.BytesIO(data))
 for n,p in sorted(files.items()):
  z=t.gettarinfo(str(p),arcname=n);h=hashes[n]
  if (h,modes[n]) in seen:z.type=tarfile.LNKTYPE;z.linkname=seen[h,modes[n]];z.size=0;t.addfile(z)
  else:
   seen[h,modes[n]]=n
   with p.open('rb') as f:t.addfile(z,f)
with tarfile.open(out,'r:xz') as t:
 for n,h in hashes.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h and t.getmember(n).mode==modes[n],n
report={'scope':'Frozen call-reference assignment compiler96 prerequisite evidence only. Reference-return activation, runtime97 ownership/source/error pairing and independent acceptance separate. No full reference family or core closure.','archive':str(out),'sha256':digest(out),'bytes':out.stat().st_size,'paths':len(files),'candidate':m['fingerprint'],'baseline':b['fingerprint'],'tools':tools,'historical_native_tool_aliases':aliases,'originals':{'retained917_native_exact926_replay':10,'new926_native_runtime_ordinary_array':11,'new926_native_runtime_builtin':4},'gates':{'retained_source_phases':{'compared':12,'raw':'.tools/acquire-compiler-phases-mqstdmge','fingerprint':'a76462eae17ad3bc1e9284ed093140273232d7b2133e6085fb17f40bfbf1a34f'},'builtin_phases_repaired':{'compared':4,'raw':'.tools/acquire-compiler-phases-bo1xffe2','fingerprint':'bb04e825e66401277f5ea75624df219ddee11349419e1d9e7af8a06f878e4614'},'maintained':{'exact_native_phases':19,'pending':3,'projections':11,'raw':'.tools/call-reference-compiler-ehaibnv5','fingerprint':m['fingerprint']['sha256']}},'failures':['.tools/acquire-compiler-phases-e_c0myob: first927 optimized builtin write-context diagnostic missing; exact3source files, native phase and full compiler state preserved before ppwrite_call reuse.'],'transport':'Recorded adapter/frontend wire packets, stderr and clean closures; raw native/full compiler commands, streams and exit statuses. Exact old native filenames and full primitive requests retained; no Unsupported/runtime failure counted as agreement.','build':'No rebuild; exact accepted926 tool hashes and modes retained.'};(R/'archive.json').write_text(json.dumps(report,indent=2)+'\n');print(report['sha256'],report['paths'],report['bytes'])
