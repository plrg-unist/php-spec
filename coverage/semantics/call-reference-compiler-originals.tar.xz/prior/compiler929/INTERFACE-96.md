# Call reference acquisition prerequisite

Compiler 96 pairs with runtime 97 after accepted typed 926/599f3963. It admits a
named positional call only as the source of reference assignment. Generic PPW
call compilation, reference-return declarations, dynamic/named/unpacked calls and
registered builtin execution retain their existing boundaries.

`ppassignsource` lowers a direct call source through PPR, then reuses module 87's
`ppwrite_call` to preserve special builtin write-context diagnostics. Every other
source uses the existing value/write mode. Array reference items reject direct
calls after compiling their key and before compiling arguments, reusing the
existing writable-source diagnostic. Temporary-call dimension bases are unchanged.
No compiler schema or second call/type/signature evaluator is introduced.

The checked call origin identifies the acquisition source. Its CODEEXPR and its
parent assignment retain the emitted call line; the two multiline controls check
both exact line and source/target access modes. Runtime must bind ACQUIRE_CALL to
an actual reference-assignment source, retain an actual returned reference, and
preserve a plain returned value until the target consumer. The assignment notice
is `Only variables should be assigned by reference`, distinct from parameter-send
and reference-return notices.

Native controls correct the earlier preparation plan's fresh-cell assumption:
ordinary value-call assignment preserves existing target aliases for direct CV,
computed variable and dimension targets. `ZEND_MAKE_REF` wraps CV/indirect operands,
but copies a plain call VAR unchanged. The target therefore performs the ordinary
value write after the notice. Array reference items containing calls are compile
errors, including when a prior key or an argument competes for diagnostic priority.

Frozen compiler 929/4633dc5c changes five paths: modules 46 and 96, registry, and
two maintained tests. Its code matches repaired 927/bb04e825. The maintained gate
checks 19 exact native compilation phases, three explicit pending boundaries and
11 source mode/line projections. Runtime ownership, observation, error/resumption
and source guards require independent paired acceptance.

Evidence retains ten exact old-917 originals replayed on accepted 926, eleven
new ordinary/array acquisition originals and four builtin originals. All original
926 runtime classifications are Unsupported. Native compilation and execution
remain separate. The initial 927/a76462ea compiler missed optimized builtin
rejection; the exact first source, native phase and full compiler failure are
retained before repair through the existing module 87 helper.
