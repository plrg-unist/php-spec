<?php
function g(){return 1;}
$a=[
 &g(
 )
];