<?php
function g(){return 1;}
$n="x";
$$n
 = &g(
 );
echo $x;