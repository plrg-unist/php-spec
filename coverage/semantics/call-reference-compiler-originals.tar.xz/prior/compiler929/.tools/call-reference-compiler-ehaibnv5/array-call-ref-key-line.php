<?php
function k(){return 0;}
function g(){return 1;}
$a=[
 k(
 ) =>
 &g()
];