from pathlib import Path
import json,sys,subprocess,tempfile
R=Path(__file__).resolve().parent;C=R.parent.parent;B=C/'.tools/compiler6-reference-calls';OLD=C/'.tools/runtime6-typed-calls';sys.path.insert(0,str(B/'tests/semantics'));import static_types as t;from recorded_worker import Worker
O=Path(tempfile.mkdtemp(prefix='assignment-line-before-',dir=R));print(O,flush=True);(O/'inputs.json').write_text((B/'final-inputs.json').read_text());(O/'old-inputs.json').write_text((OLD/'final-inputs.json').read_text());raw=OLD/'.tools/reference-assignment-line-gaps-aggussji';rows=json.loads((raw/'originals.json').read_text());w=Worker([str(OLD/'_build/default/adapter/main.exe'),str(OLD)],O/'adapter-wire');records=[];assertions=[]
def run(cmd,d,label):
 (d/(label+'.command.json')).write_text(json.dumps(cmd));z=subprocess.run(cmd,capture_output=True,env=t.ENV,timeout=60);(d/(label+'.stdout')).write_bytes(z.stdout);(d/(label+'.stderr')).write_bytes(z.stderr);(d/(label+'.status.json')).write_text(json.dumps({'status':'exit','exit_status':z.returncode}));return z
try:
 for i,(row,idx,line) in enumerate(zip(rows,[1,2,2,2],[4,5,7,6])):
  d=O/row['id'];d.mkdir();p=Path(row['context']);k=w.request({'op':'check','ast':json.loads((p.parent/'parsed.json').read_text())['ast'],'fixture':True});assert k['ok'];(d/'checked.json').write_text(json.dumps(k));body=f'$ppstart(91, {k["fixture"]}, {t.byte_expr(str(p))})';f=d/'state.watsup';f.write_text('dec $main() : ppstate\ndef $main() = '+body+'\n')
  for tag,root in [('old926',OLD),('before929',B)]:
   mods=[str(root/n) for n in json.loads((root/'spec/semantics/modules.json').read_text())];z=run([str(root/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(f)],d,tag);assert z.returncode==0 and not z.stderr
  cond=f'$code_expression($compiled_operands(P,P.EXPRESSIONS), [PCINDEX {idx},PCFIELD 0]) = (({line},false))';assertions.append(f'dec $case{i}() : bool\ndef $case{i}() = true\n  -- if P = '+body+'\n  -- if '+cond+'\n');records.append({'id':row['id'],'source_file':str(p),'native':row['native'],'source_index':idx,'native_assignment_line':line,'condition':cond})
finally:w.close()
(O/'records.json').write_text(json.dumps(records,indent=2)+'\n');f=O/'projection.watsup';f.write_text('\n'.join(assertions)+'\ndec $main() : bool\ndef $main() = true\n'+''.join(f'  -- if $case{i}()\n' for i in range(4)));mods=[str(B/n) for n in json.loads((B/'spec/semantics/modules.json').read_text())];z=run([str(B/'tests/semantics/_build/default/numeric_runner.exe'),*mods,str(f)],O,'before-projection');assert z.returncode==1 and b'was not met' in z.stderr;print('Preserved four native/old926/before929 states and failing line projection',flush=True)
