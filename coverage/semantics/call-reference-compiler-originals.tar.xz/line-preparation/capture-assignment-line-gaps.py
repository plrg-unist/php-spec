from pathlib import Path
import sys,json
R=Path(__file__).resolve().parent;B=R.parent/'runtime6-typed-calls';sys.path.insert(0,str(B/'tests/semantics'));import function_scope as scope
CASES={
'acquire-argument-line-cv':b'<?php\nfunction g($x){return $x;}\n$x=&g(\n 1\n);\necho $x;',
'acquire-argument-line-computed':b'<?php\nfunction g($x){return $x;}\n$n="x";\n$$n=&g(\n 1\n);\necho $x;',
'acquire-argument-line-dim':b'<?php\nfunction g($x){return $x;}\n$a=[];\n$a[\n 0\n]=&g(\n 1\n);\necho $a[0];',
'acquire-argument-line-nested':b'<?php\nfunction g($x){return $x;}\nfunction h($x){return $x;}\n$x=&g(\n h(\n  1\n )\n);\necho $x;',
}
(R/'assignment-line-gap-cases.json').write_text(json.dumps({k:v.decode() for k,v in CASES.items()},indent=2)+'\n')
scope.main(CASES,'reference-assignment-line-gaps',Path(scope.__file__))
