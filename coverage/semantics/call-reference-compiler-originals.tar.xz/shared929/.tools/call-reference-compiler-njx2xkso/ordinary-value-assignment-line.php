<?php
function g($x){return $x;}
$x
=g(
 1
);
echo $x;