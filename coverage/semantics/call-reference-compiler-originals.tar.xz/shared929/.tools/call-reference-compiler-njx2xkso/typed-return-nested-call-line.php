<?php
function g($x){return [];}
function h($x){return $x;}
function f():int{
return g(
 h(
  1
 )
);
}
f();