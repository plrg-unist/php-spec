<?php
function g($x){return $x;}
$a=[];
$a[
 0
]=&g(
 1
);
echo $a[0];