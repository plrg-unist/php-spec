<?php
function g($x){return $x;}
$n="x";
$$n=&g(
 1
);
echo $x;