<?php
function g($x){return $x;}
function h($x){return $x;}
$x=&g(
 h(
  1
 )
);
echo $x;